import 'dart:convert';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import '../apptheme/app_strings.dart';
import '../controllers/adcontroller/ad_controller.dart';
import '../controllers/iapcontroller/iap_controller.dart';
import '../model/ad_model.dart';

class RemoteConfigService {
  RemoteConfigService._() : _remoteConfig = FirebaseRemoteConfig.instance;

  static RemoteConfigService? _instance; // NEW
  factory RemoteConfigService() => _instance ??= RemoteConfigService._();

  final AdController adController = Get.put(AdController());

  final FirebaseRemoteConfig _remoteConfig;
  final IapController iapController = Get.put(IapController());

  String getString(String key) => _remoteConfig.getString(key);

  Future<void> setConfigSettings() async => _remoteConfig.setConfigSettings(
    RemoteConfigSettings(
        fetchTimeout: const Duration(minutes: 1),
        minimumFetchInterval: const Duration(minutes: 0)),
  );

  Future<void> fetchAndActivate() async {
    bool updated = false;
    bool isNetAvailable = await InternetConnectionChecker().hasConnection;
    if (isNetAvailable) {
      updated = await _remoteConfig.fetchAndActivate();
    }

    if (updated) {
      debugPrint('The config has been updated.');
    } else {
      debugPrint('The config is not updated..');
    }
  }

  Future<void> initialize() async {
    try {
      await setConfigSettings();
      await fetchAndActivate();
      getAdsData();
    } catch (e) {
      debugPrint('Remote Config Error ${e.toString()}');
    }
    // getIapPlanData();
  }

  AdModel? getAdsData() {
    try {
      String jsonDataString = getString(isTestMode ? testAdsData : liveAdsData);

      adController.adData = AdModel.fromJson(jsonDecode(jsonDataString));

      return adController.adData;
    } catch (error) {
      return null;
    }
  }

  // IapPlan? getIapPlanData() {
  //   try {
  //     String jsonDataString = getString(iapPlan);
  //
  //     iapController.iapPlan = IapPlan.fromJson(jsonDecode(jsonDataString));
  //     // SubscriptionModel subData =
  //     //     SubscriptionModel.fromJson(jsonDecode(jsonDataString));
  //     if (iapController.iapPlan != IapPlan() &&
  //         iapController.iapPlan.iapPlans != null &&
  //         iapController.iapPlan.iapPlans!.isNotEmpty) {
  //       iapController.iapList = iapController.iapPlan.iapPlans!;
  //
  //       iapController.selectedPlanId.value =
  //       iapController.iapList[1].planId == null ||
  //           iapController.iapList[1].planId!.isEmpty
  //           ? monthlySubKey
  //           : iapController.iapList[1].planId ?? monthlySubKey;
  //
  //       iapController.update();
  //
  //       debugPrint(
  //           "iap list data === ${iapController.iapList.map((e) => e.toJson())}");
  //     }
  //
  //     return iapController.iapPlan;
  //   } catch (error) {
  //     iapController.iapList = localIapList;
  //     iapController.update();
  //     return null;
  //   }
  // }
}
