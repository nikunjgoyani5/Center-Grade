import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../apptheme/app_strings.dart';
import '../controllers/adcontroller/ad_controller.dart';
import '../firebaseservice/remote_config_service.dart';

class AdsHelper {
  static final remoteConfig = RemoteConfigService();
  static final AdController adController = Get.find<AdController>();

  static String interAdsId(String adsLabel) {
    try {
      if (adController.adData.adsData![adsLabel]!.idAds!.isEmpty) {
        return isTestMode ? testInterstitialAdKey : liveInterstitialAdKey;
      } else {
        return adController.adData.adsData![adsLabel]!.idAds!;
      }
    } catch (e) {
      return isTestMode ? testInterstitialAdKey : liveInterstitialAdKey;
    }
  }

  static String bannerAdsId(String adsLabel) {
    try {
      if (adController.adData.adsData![adsLabel]!.idAds!.isEmpty) {
        return isTestMode ? testHomeBannerAdKey : liveHomeBannerAdKey;
      } else {
        return adController.adData.adsData?[adsLabel]?.idAds ??
            (isTestMode ? testHomeBannerAdKey : liveHomeBannerAdKey);
      }
    } catch (e) {
      return isTestMode ? testHomeBannerAdKey : liveHomeBannerAdKey;
    }
  }

  static String nativeAdsId(String adsLabel) {
    try {
      if (adController.adData.adsData![adsLabel]!.idAds!.isEmpty) {
        return isTestMode ? testNativeAdKey : liveNativeAdKey;
      } else {
        return adController.adData.adsData?[adsLabel]?.idAds ?? liveNativeAdKey;
      }
    } catch (e) {
      return isTestMode ? testNativeAdKey : liveNativeAdKey;
    }
  }

  static String openAdsId(String adsLabel) {
    try {
      if (adController.adData.adsData![adsLabel]!.idAds!.isEmpty) {
        return isTestMode ? testOpenAdKey : liveOpenAdKey;
      } else {
        return adController.adData.adsData?[adsLabel]?.idAds ?? liveOpenAdKey;
      }
    } catch (e) {
      return isTestMode ? testOpenAdKey : liveOpenAdKey;
    }
  }

  static bool isInFrequency(String adLabel) {
    return (adController.adData.adsData![adLabel]!.frequency ?? 0) > 0;
  }

  static bool isAdMob(String adLabel) {
    try {
      return adController.adData.adsData?[adLabel]?.publishers == "ad_unit";
    } on Exception catch (e) {
      debugPrint('$e');
      return false;
    }
  }

  static bool isAdsEnable(String adLabel) {
    try {
      if (adController.adData.adsData?[adLabel]?.enableAds != null) {
        return (adController.adData.adsData?[adLabel]?.enableAds as bool);
      } else {
        return false;
      }
    } on Exception catch (e) {
      debugPrint('Ad Enable Error === $e');
      return false;
    }
  }

  static void decreaseFreq(String adLabel) {
    int x = adController.adData.adsData![adLabel]!.frequency ?? 0;
    x--;
    adController.adData.adsData![adLabel]!.frequency = x;
  }
}
