import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../apptheme/app_strings.dart';
import '../controllers/adcontroller/ad_controller.dart';
import '../firebaseservice/remote_config_service.dart';
import '../networkservice/network_service.dart';
import '../prefmanage/pref_manage.dart';
import 'ad_helper.dart';

class AdService {
  static final remoteConfig = RemoteConfigService();
  static final AdController adController = Get.find<AdController>();

  // IAP Interstitial Ad
  static InterstitialAd? _interstitialAd;
  static bool isInterLoaded = false;
  static bool isInterShowing = false;
  static PrefManager prefManage = PrefManager();
  static int adsCounter = 0;

  static Future<void> loadInterstitialAds(String adLabel) async {
    if (!NetworkConnectionService.isNetworkConnected &&
        (await prefManage.getBoolData(key: iapStatusKey)) == true ||
        (adController.adData.showAds != null &&
            !(adController.adData.showAds!)) ||
        isInterLoaded) {
      return;
    }
    await InterstitialAd.load(
      adUnitId: AdsHelper.interAdsId(adLabel),
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (currentAd) {
        isInterLoaded = true;
        _interstitialAd = currentAd;
        _interstitialAd!.setImmersiveMode(true);
        // debugPrint("Interstitial Ad loaded");
      }, onAdFailedToLoad: (error) {
        debugPrint(
            "Failed to load : Flutter AdMob Interstitial Ad ${error.message.toString()}");

        isInterLoaded = false;
        _interstitialAd = null;
      }),
    );
  }

  static Future<void> showInterstitialAd(
      {required VoidCallback afterAd,
        bool? counterAd,
        required String adLabel}) async {
    if (NetworkConnectionService.isNetworkConnected &&
        (await prefManage.getBoolData(key: iapStatusKey)) == false &&
        (adController.adData.showAds != null && adController.adData.showAds!) &&
        isInterLoaded) {
      if ((adsCounter % (adController.adData.userClickCounter ?? 2) != 0)
      /*||
          (adController.adData.homeScreenAds == false &&
              adsCounter == 0)*/
      ) {
        afterAd();
        adsCounter++;
        // debugPrint('adsCounter Data === $adsCounter');
        return;
      }
      adsCounter++;
      if (AdsHelper.isAdsEnable(adLabel) && AdsHelper.isInFrequency(adLabel)) {
        if (AdsHelper.isAdMob(adLabel)) {
          _interstitialAd?.fullScreenContentCallback =
              FullScreenContentCallback(
                onAdShowedFullScreenContent: (ad) {
                  isInterShowing = true;
                },
                onAdDismissedFullScreenContent: (ad) {
                  isInterLoaded = false;
                  isInterShowing = false;
                  AdsHelper.decreaseFreq(adLabel);
                  afterAd();

                  ad.dispose();
                  _interstitialAd = null;
                  loadInterstitialAds(adLabel);
                },
                onAdFailedToShowFullScreenContent: (ad, error) {
                  afterAd();
                  isInterLoaded = false;
                  isInterShowing = false;
                  ad.dispose();
                  _interstitialAd = null;
                  loadInterstitialAds(adLabel);
                  // debugPrint('error showing inter :$error');
                },
              );
          isInterShowing = true;
          await _interstitialAd?.show();
        } else {
          debugPrint("======= AD MOB DISABLED =====");
          // if (AdsHelper.isInFrequency(adLabel)) {
          //   isInterShowing = true;
          //   Get.dialog(const CustomInterAdWidget()).then((value) {
          //     isInterShowing = false;
          //     afterAd();
          //   });
          // } else {
          //   return;
          // }
        }
      } else {
        afterAd();
      }
    } else {
      afterAd();
    }
  }

  // Splash Ad
  static AppOpenAd? openAd;
  static bool isOpenAdLoaded = false;
  static bool isOpenAdShowing = false;

  static loadSplashOpenAd(String adsLabel, VoidCallback afterAd) {
    if (!NetworkConnectionService.isNetworkConnected &&
        (adController.adData.showAds != null &&
            !(adController.adData.showAds!)) ||
        !(AdsHelper.isAdsEnable(adsLabel)) ||
        isOpenAdShowing ||
        isOpenAdLoaded ||
        isInterShowing ) {
      openAd = null;

      // debugPrint('splash ads IF Condition');
      return;
    }
    AppOpenAd.load(
      adUnitId: AdsHelper.openAdsId(adsLabel), //Your ad Id from admob
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(onAdLoaded: (ad) {
        isOpenAdLoaded = true;
        openAd = ad;
        showSplashOpenAd(
            afterAd: () {
              afterAd();
            },
            adsLabel: adsLabel);
      }, onAdFailedToLoad: (error) {
        isOpenAdLoaded = false;
        openAd = null;
        Timer(const Duration(seconds: 2), () {
          afterAd();
        });
      }),
    );
  }

  static Future<void> showSplashOpenAd(
      {required VoidCallback afterAd, required String adsLabel}) async {
    if (NetworkConnectionService.isNetworkConnected &&
        (await prefManage.getBoolData(key: iapStatusKey)) == true ||
        (adController.adData.showAds != null &&
            !adController.adData.showAds!)) {
      Timer(const Duration(seconds: 2), () {
        afterAd();
      });
    } else {
      if (AdsHelper.isAdMob(adsLabel)) {
        openAd!.fullScreenContentCallback = FullScreenContentCallback(
          onAdShowedFullScreenContent: (ad) {
            isOpenAdShowing = true;
          },
          onAdDismissedFullScreenContent: (ad) {
            ad.dispose();
            openAd = null;
            isOpenAdShowing = false;
            isOpenAdLoaded = false;
            afterAd();
          },
          onAdFailedToShowFullScreenContent: (ad, error) {
            afterAd();
            ad.dispose();
            openAd = null;
            isOpenAdShowing = false;
            isOpenAdLoaded = false;
          },
        );
        openAd?.show();
      } else {
        debugPrint("====== Splash Ad Admob disabled ======");
        // isOpenAdShowing = true;
        // Get.dialog(const CustomOpenAdWidget()).then((value) {
        //   isOpenAdShowing = false;
        //   afterAd();
        //   // debugPrint('Open Ad: Closed $isOpenAdShowing');
        // });
        //custom
      }
    }
  }

  // Home Banner Ad
  static BannerAd? homeBannerAds;
  static bool isDetailBannerAdLoaded = false;
  static bool isDetailBannerAdShowing = false;

  static loadDetailBannerAd(
      String adsLabel,
      ) async {
    if (!NetworkConnectionService.isNetworkConnected &&
        (adController.adData.showAds != null &&
            !(adController.adData.showAds!)) &&
        !(AdsHelper.isAdsEnable(adsLabel))) {
      homeBannerAds = null;
      return;
    }
    homeBannerAds = BannerAd(
      size: AdSize.fullBanner,
      adUnitId: AdsHelper.bannerAdsId(adsLabel),
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          isDetailBannerAdLoaded = true;
          homeBannerAds = ad as BannerAd;

          debugPrint("Banner Ad Loaded === $homeBannerAds");
        },
        onAdWillDismissScreen: (ad) {
          isDetailBannerAdLoaded = false;
          isDetailBannerAdShowing = false;
          AdsHelper.decreaseFreq(adsLabel);
          homeBannerAds = null;
          ad.dispose();
          loadDetailBannerAd(adsLabel);
        },
        onAdFailedToLoad: (ad, error) {
          isDetailBannerAdLoaded = false;
          homeBannerAds = null;

          debugPrint('Banner ad load failed ${error.message.toString()}');
        },
      ),
    );
    homeBannerAds?.load();
  }

  // Native ad
  static NativeAd? nativeAd;
  static bool isNativeAdLoaded = false;
  static bool isNativeAdShowing = false;

  static loadNativeAd(String adsLabel) {
    if (!NetworkConnectionService.isNetworkConnected &&
        (adController.adData.showAds != null &&
            !(adController.adData.showAds!)) ||
        !(AdsHelper.isAdsEnable(adsLabel))) {
      nativeAd = null;
      return;
    }
    nativeAd = NativeAd(
      factoryId: 'nativeAd',
      adUnitId: AdsHelper.nativeAdsId(adsLabel),
      listener: NativeAdListener(
        onAdLoaded: (ad) {
          // debugPrint('$ad NativeAd loaded.');
          isNativeAdLoaded = true;
          // nativeAd = ad as NativeAd;

          // debugPrint("Native Ad Loaded === $nativeAd");
        },
        onAdWillDismissScreen: (ad) {
          isNativeAdLoaded = false;
          isNativeAdShowing = false;
          AdsHelper.decreaseFreq(adsLabel);

          ad.dispose();
          nativeAd = null;
          loadNativeAd(adsLabel);
        },
        onAdFailedToLoad: (ad, error) {
          isNativeAdLoaded = false;
          // debugPrint("Native Ad Failed === ${error.message.toString()}");
        },
      ),
      request: const AdRequest(),
    );
    nativeAd!.load();
  }

  static Future<bool> showNativeAds(String adLabel) async {
    if (await (prefManage.getBoolData(key: iapStatusKey)) ||
        !AdsHelper.isAdsEnable(adLabel)) {
      isNativeAdShowing = false;

      return false;
    }
    if ((adController.adData.showAds != null && adController.adData.showAds!) &&
        isNativeAdLoaded &&
        !isNativeAdShowing) {
      isNativeAdShowing = true;
      return true;
    } else {
      if (AdsHelper.isInFrequency(adLabel) &&
          adController.adData.showAds == true) {
        isNativeAdShowing = true;
        return true;
      } else {
        isNativeAdShowing = false;
        return false;
      }
    }
  }
}
