import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shimmer/shimmer.dart';

import '../../apptheme/app_colors.dart';
import '../../apptheme/app_constants.dart';
import '../../controllers/adcontroller/ad_controller.dart';
import '../../networkservice/network_service.dart';
import '../ad_helper.dart';

class BannerAdsWidget extends StatefulWidget {
  final String adLbl;

  const BannerAdsWidget({super.key, required this.adLbl});

  @override
  State<BannerAdsWidget> createState() => _BannerAdsWidgetState();
}

class _BannerAdsWidgetState extends State<BannerAdsWidget> {
  BannerAd? bannerAd;
  bool isBannerLoaded = false;
  bool isFailedBanner = false;
  bool isBannerLoad = false;

  final adController = Get.put(AdController());

  loadAd() async {
    isBannerLoad = true;
    setState(() {});
    final AnchoredAdaptiveBannerAdSize? size =
        await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
          Get.width.truncate(),
        );
    if (size == null) {
      Get.log("Banner Ad Size Doesn't Get");
      return;
    }
    bannerAd = BannerAd(
      adUnitId: AdsHelper.bannerAdsId(widget.adLbl),
      // adUnitId: widget.adLbl,
      size: size,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          isBannerLoaded = true;
          isBannerLoad = false;
          isFailedBanner = false;
          setState(() {});
        },
        onAdFailedToLoad: (ad, err) {
          isBannerLoaded = false;
          isBannerLoad = false;
          isFailedBanner = true;
          setState(() {});
        },
      ),
    )..load();
  }

  @override
  void initState() {
    if (NetworkConnectionService.isNetworkConnected &&
        adController.adData.showAds == true &&
        AdsHelper.isAdsEnable(widget.adLbl) &&
        AdsHelper.isInFrequency(widget.adLbl) &&
        AdsHelper.isAdMob(widget.adLbl)) {
      loadAd();
    }
    super.initState();
  }

  @override
  void dispose() {
    if (bannerAd != null) {
      bannerAd!.dispose();
      bannerAd = null;
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!NetworkConnectionService.isNetworkConnected ||
        !AdsHelper.isAdsEnable(widget.adLbl) ||
        !AdsHelper.isInFrequency(widget.adLbl) ||
        isFailedBanner) {
      return const SizedBox.shrink();
    }
    if (isBannerLoad) {
      return shimmerWidget();
      // return const SizedBox.shrink();
    }

    if (isBannerLoaded) {
      return Container(
        padding: const EdgeInsets.all(0),
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        decoration: BoxDecoration(
          color: isDarkMode() ? AppColors.black0D0C0C : AppColors.whiteColor,
          border: Border(
            top: BorderSide(
              color:
                  isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
            ),
            bottom: BorderSide(
              color:
                  isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
            ),
          ),
        ),
        height: bannerAd!.size.height.toDouble(),
        width: bannerAd!.size.width.toDouble(),
        child: AdWidget(ad: bannerAd!),
      );
    }

    // if (!AdsHelper.isAdMob(widget.adLbl) &&
    //     AdsHelper.isInFrequency(widget.adLbl)) {
    //   AdsHelper.decreaseFreq(widget.adLbl);
    //   return Stack(
    //     alignment: Alignment.topCenter,
    //     children: [
    //       GestureDetector(
    //         onTap: () async {
    //           appFunctions.urlLaunch(firebaseRemoteConfigService
    //                   .getFirebaseAdsData()
    //                   .banner!
    //                   .adCallToActionUrl ??
    //               "");
    //         },
    //         child: SizedBox(
    //           height: 60,
    //           width: Get.width,
    //           child: Image(
    //               image: NetworkImage(firebaseRemoteConfigService
    //                       .getFirebaseAdsData()
    //                       .banner!
    //                       .adMedia ??
    //                   "")),
    //         ),
    //       ),
    //       Container(
    //         decoration: BoxDecoration(
    //           color: Colors.white24,
    //           borderRadius: BorderRadius.circular(8),
    //         ),
    //         child: Text(firebaseRemoteConfigService
    //                 .getFirebaseAdsData()
    //                 .banner!
    //                 .adHeadline ??
    //             ""),
    //       ),
    //       Align(
    //         alignment: Alignment.topLeft,
    //         child: GestureDetector(
    //             onTap: () {
    //               appFunctions.urlLaunch(firebaseRemoteConfigService
    //                       .getFirebaseAdsData()
    //                       .banner!
    //                       .infoUrl ??
    //                   "");
    //             },
    //             child: const Icon(Icons.info)),
    //       )
    //     ],
    //   );
    // }

    return const SizedBox.shrink();
  }

  Widget shimmerWidget() {
    return Container(
      height: 65,
      padding: const EdgeInsets.symmetric(horizontal: 15),
      color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      // width: double.infinity,
      child: Shimmer.fromColors(
        baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
        highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
        child: const Row(
          children: [
            SkeletonUI(height: 50, width: 50),
            SizedBox(width: 5),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SkeletonUI(height: 12, width: 150),
                SizedBox(height: 7),
                SkeletonUI(height: 12, width: 100),
              ],
            ),
            SizedBox(width: 5),
            SkeletonUI(width: 110, height: 40),
          ],
        ),
      ),
    );
  }
}

class SkeletonUI extends StatelessWidget {
  final double? height;
  final double? width;

  const SkeletonUI({super.key, this.height, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.grey.withValues(alpha: 0.1)),
    );
  }
}
