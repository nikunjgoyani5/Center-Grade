import 'dart:developer';
import 'dart:io';
import 'package:card_centering/pages/dashboard/dashboard_screen.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import '../../../main.dart';
import '../apptheme/app_strings.dart';
import '../controllers/iapcontroller/iap_controller.dart';
import '../prefmanage/pref_manage.dart';
import 'app_purchase_data.dart';

class RevenueCatService {
  static StoreProduct? monthlyBasePlan;
  static StoreProduct? monthlyProPlan;
  static StoreProduct? monthlyElitePlan;
  static String? planName;
  static String? identifire;
  static DateTime? lastDate;
  static CustomerInfo? customerInfoo;
  static PrefManager prefManager = PrefManager();
  static final iapController = Get.find<IapController>();

  /// ABANDONEED PURCHASE MEANS USER OPEN BOTTOMSHEET FOR PURCHASE BUT HE IS NOT PURCHASE SUBSCRIPTION.
  static bool isAbandonedPurchase = false;

  static Future<void> initRevenueCat() async {
    await _configureSDK();
    await initPlatformState();
    await getOfferings();
    try {
      CustomerInfo customerInfo = await Purchases.getCustomerInfo();
      customerInfoo = customerInfo;

      if (customerInfo.entitlements.active.isEmpty) {
        subActive = false;
        prefManager.setBoolData(key: iapStatusKey, value: false);
        iapController.getIAPStatus();
      } else {
        subActive = true;
        prefManager.setBoolData(key: iapStatusKey, value: true);
        iapController.getIAPStatus();

        String key =
            customerInfo.entitlements.active.entries.first.key.toString();
        planName = customerInfo.entitlements.active[key]!.identifier;
        identifire = customerInfo.entitlements.active[key]!.productIdentifier;
        lastDate = DateTime.parse(
          customerInfo.entitlements.active[key]!.expirationDate.toString(),
        );
      }
    } catch (e) {
      debugPrint('INIT REVENUE CAT ## ERROR ## $e');
    }
  }

  static Future<void> _configureSDK() async {
    await Purchases.setLogLevel(LogLevel.debug);
    PurchasesConfiguration configuration;

    configuration = PurchasesConfiguration(
      Platform.isIOS ? revenueCatAppleKey : revenueCatAndroidKey,
    );

    await Purchases.configure(configuration);
  }

  static Future<void> initPlatformState() async {
    appData.appUserID = await Purchases.appUserID;
    Purchases.addCustomerInfoUpdateListener((customerInfo) async {
      appData.appUserID = await Purchases.appUserID;

      CustomerInfo customerInfo = await Purchases.getCustomerInfo();
      EntitlementInfo? planActive =
          customerInfo.entitlements.all[Platform.isIOS
              ? entitlementIdentifierIos
              : entitlementIdentifierAndroid];

      if (planActive != null && planActive.isActive) {
        appData.entitlementIsActive = planActive.isActive;
        return;
      }
    });
  }

  static Future<void> getOfferings() async {
    // if (NetworkConnectionService.isNetworkConnected == false) return;
    try {
      var offerings = await Purchases.getProducts([
        monthlyBaseKey,
        monthlyProKey,
        monthlyEliteKey,
      ]);
      log("Offers ==== ${offerings.map((e) => e.toJson())}");
      if (offerings.isNotEmpty) {
        if (Platform.isIOS) {
          for (var element in offerings) {
            if (element.identifier == monthlyBaseKey) {
              monthlyBasePlan = element;
            } else if (element.identifier == monthlyProKey) {
              monthlyProPlan = element;
            } else if (element.identifier == monthlyEliteKey) {
              monthlyElitePlan = element;
            }
          }
        }
      } else {
        debugPrint('=== offerings Empty ====');
      }
    } catch (e) {
      debugPrint('=== ERRORS ====${e.toString()}');
    }
  }

  static Future<void> purchaseMonthElitePlan() async {
    Get.dialog(const Center(child: CircularProgressIndicator()));
    try {
      if (monthlyElitePlan == null) {
        Get.back();
        return;
      }
      CustomerInfo customerInfo = await Purchases.purchaseStoreProduct(
        monthlyElitePlan!,
      );
      if (customerInfo
              .entitlements
              .all[Platform.isIOS
                  ? entitlementIdentifierIos
                  : entitlementIdentifierAndroid]
              ?.isActive ==
          true) {
        subActive = true;
        if ((subActive ?? false)) {
          prefManager.setBoolData(key: iapStatusKey, value: true);
          iapController.getIAPStatus();
        } else {
          prefManager.setBoolData(key: iapStatusKey, value: false);
          iapController.getIAPStatus();
        }

        debugPrint(
          '<<<<< API CALL = START = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );

        // Response? res = await SubscriptionRepository.updateSubscription(
        //     originalAppUserId: customerInfo.originalAppUserId);

        debugPrint(
          '##### ORIGINAL APP USER ID ##### ${customerInfo.originalAppUserId}',
        );
        debugPrint(
          '<<<<< API CALL = END = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );

        await getDataAfterPurchase();
        Get.back();
        isAbandonedPurchase = false;

        showToast(message: purchaseCompleted.tr);
      } else {
        Get.back();
        debugPrint("=========== entitlements not active =========== ");
      }
    } on PlatformException catch (e) {
      debugPrint(
        "=========== PlatformException Error ${e.toString()} =========== ",
      );
      Get.back();
      if (e.code ==
          PurchasesErrorCode.purchaseCancelledError.index.toString()) {
        isAbandonedPurchase = true;
      }
    } catch (e) {
      Get.back();
      debugPrint("=========== Catch Error ${e.toString()} =========== ");
    }
  }

  static Future<void> purchaseMonthlyProPlan() async {
    Get.dialog(const Center(child: CircularProgressIndicator()));
    try {
      if (monthlyProPlan == null) {
        Get.back();
        return;
      }
      CustomerInfo customerInfo = await Purchases.purchaseStoreProduct(
        monthlyProPlan!,
      );

      if (customerInfo
              .entitlements
              .all[Platform.isIOS
                  ? entitlementIdentifierIos
                  : entitlementIdentifierAndroid]
              ?.isActive ==
          true) {
        subActive = true;

        if ((subActive ?? false)) {
          prefManager.setBoolData(key: iapStatusKey, value: true);
          iapController.getIAPStatus();
        } else {
          prefManager.setBoolData(key: iapStatusKey, value: false);
          iapController.getIAPStatus();
        }
        debugPrint(
          '<<<<< API CALL = START = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );

        // Response? res = await SubscriptionRepository.updateSubscription(
        //     originalAppUserId: customerInfo.originalAppUserId);

        debugPrint(
          '##### ORIGINAL APP USER ID ##### ${customerInfo.originalAppUserId}',
        );
        debugPrint(
          '<<<<< API CALL = END = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );

        await getDataAfterPurchase();
        Get.back();

        isAbandonedPurchase = false;

        showToast(message: purchaseCompleted.tr);
      } else {
        Get.back();

        debugPrint("=========== entitlements not active =========== ");
      }
    } on PlatformException catch (e) {
      Get.back();

      debugPrint(
        "=========== PlatformException Error ${e.toString()} =========== ",
      );
      if (e.code ==
          PurchasesErrorCode.purchaseCancelledError.index.toString()) {
        isAbandonedPurchase = true;
      }
    } catch (e) {
      Get.back();

      debugPrint("=========== Catch Error ${e.toString()} =========== ");
    }
  }

  static Future<void> purchaseMonthlyBasePlan() async {
    Get.dialog(const Center(child: CircularProgressIndicator()));
    try {
      if (monthlyBasePlan == null) {
        Get.back();
        return;
      }
      CustomerInfo customerInfo = await Purchases.purchaseStoreProduct(
        monthlyBasePlan!,
      );

      if (customerInfo
              .entitlements
              .all[Platform.isIOS
                  ? entitlementIdentifierIos
                  : entitlementIdentifierAndroid]
              ?.isActive ==
          true) {
        subActive = true;

        if ((subActive ?? false)) {
          prefManager.setBoolData(key: iapStatusKey, value: true);
          iapController.getIAPStatus();
        } else {
          prefManager.setBoolData(key: iapStatusKey, value: false);
          iapController.getIAPStatus();
        }
        debugPrint(
          '<<<<< API CALL = START = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );
        // Response? res = await SubscriptionRepository.updateSubscription(
        //     originalAppUserId: customerInfo.originalAppUserId);
        debugPrint(
          '##### ORIGINAL APP USER ID ##### ${customerInfo.originalAppUserId}',
        );
        debugPrint(
          '<<<<< API CALL = END = AFTER SUBSCRIPTION >>>>> ${DateTime.now().hour}:${DateTime.now().minute}',
        );

        await getDataAfterPurchase();
        Get.back();

        isAbandonedPurchase = false;

        showToast(message: purchaseCompleted.tr);
      } else {
        Get.back();
        debugPrint("=========== entitlements not active =========== ");
      }
    } on PlatformException catch (e) {
      Get.back();
      debugPrint(
        "=========== PlatformException Error ${e.toString()} =========== ",
      );
      if (e.code ==
          PurchasesErrorCode.purchaseCancelledError.index.toString()) {
        isAbandonedPurchase = true;
      }
    } catch (e) {
      Get.back();
      debugPrint("=========== Catch Error ${e.toString()} =========== ");
    }
  }

  static Future<void> restorePurchase() async {
    try {
      CustomerInfo customerInfo = await Purchases.restorePurchases();
      customerInfoo = customerInfo;

      if (customerInfo.entitlements.active.isEmpty) {
        subActive = false;
        prefManager.setBoolData(key: iapStatusKey, value: false);
        iapController.getIAPStatus();

        showToast(message: 'You Have Not Any Purchase');
      } else {
        subActive = true;
        prefManager.setBoolData(key: iapStatusKey, value: true);
        iapController.getIAPStatus();

        String key =
            customerInfo.entitlements.active.entries.first.key.toString();
        planName = customerInfo.entitlements.active[key]!.identifier;
        identifire = customerInfo.entitlements.active[key]!.productIdentifier;
        lastDate = DateTime.parse(
          customerInfo.entitlements.active[key]!.expirationDate.toString(),
        );

        await Get.offAll(() => const DashboardScreen());
      }
      // if (Platform.isIOS) {
      //   if (customerInfo.entitlements.all[AppKeys.yearlySubApple] != null &&
      //       customerInfo.entitlements.all[AppKeys.yearlySubApple]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     }
      //     Get.offAllNamed(Routes.HOME_PAGE);
      //   } else if (customerInfo.entitlements.all[AppKeys.monthlySubApple] !=
      //           null &&
      //       customerInfo.entitlements.all[AppKeys.monthlySubApple]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     } Get.offAllNamed(Routes.HOME_PAGE);
      //   } else if (customerInfo.entitlements.all[AppKeys.weeklySubApple] !=
      //       null &&
      //       customerInfo.entitlements.all[AppKeys.weeklySubApple]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     }
      //     Get.offAllNamed(Routes.HOME_PAGE);
      //   }else {
      //     appController.showToast('You have not any purchase');
      //     StorageService.saveSubStatus(false);
      //   }
      // } else {
      //   if (customerInfo.entitlements.all[AppKeys.yearlySubGoogle] != null &&
      //       customerInfo.entitlements.all[AppKeys.yearlySubGoogle]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     }
      //     Get.offAllNamed(Routes.HOME_PAGE);
      //   } else if (customerInfo.entitlements.all[AppKeys.monthlySubGoogle] !=
      //           null &&
      //       customerInfo.entitlements.all[AppKeys.monthlySubGoogle]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     }
      //     Get.offAllNamed(Routes.HOME_PAGE);
      //   } else if (customerInfo.entitlements.all[AppKeys.weeklySubGoogle] !=
      //       null &&
      //       customerInfo.entitlements.all[AppKeys.weeklySubGoogle]?.isActive ==
      //           true) {
      //     subActive = true; StorageService.saveSubStatus(true);
      //     if (Get.isRegistered<HomePageController>()) {
      //       HomePageController homeController = Get.find();
      //       homeController.update();
      //     }
      //     Get.offAllNamed(Routes.HOME_PAGE);
      //   } else{ appController.showToast('You have not any purchase');
      //     StorageService.saveSubStatus(false);
      //   }
      // }
    } catch (e) {
      subActive = false;
      prefManager.setBoolData(key: iapStatusKey, value: false);
      iapController.getIAPStatus();

      debugPrint("====== Catch Error ===== ${e.toString()} ==== ");
    }
  }

  static Future<void> getDataAfterPurchase() async {
    try {
      CustomerInfo customerInfo = await Purchases.getCustomerInfo();
      String key =
          customerInfo.entitlements.active.entries.first.key.toString();
      planName = customerInfo.entitlements.active[key]!.identifier;
      identifire = customerInfo.entitlements.active[key]!.productIdentifier;
      lastDate = DateTime.parse(
        customerInfo.entitlements.active[key]!.expirationDate.toString(),
      );
    } catch (e) {
      debugPrint('GET DATA AFTER PURCHASE ## ERROR ## $e');
    }
  }
}
