class IapModel {
  String planName;
  String planDesc;
  String planPrice;
  String planId;

  IapModel({
    required this.planName,
    required this.planId,
    required this.planDesc,
    required this.planPrice,
  });
}
