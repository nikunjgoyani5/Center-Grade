import 'dart:convert';

SearchCardModel searchCardModelFromJson(String str) => SearchCardModel.fromJson(json.decode(str));

String searchCardModelToJson(SearchCardModel data) => json.encode(data.toJson());

class SearchCardModel {
  List<Product>? products;
  String? status;

  SearchCardModel({
    this.products,
    this.status,
  });

  factory SearchCardModel.fromJson(Map<String, dynamic> json) => SearchCardModel(
    products: json["products"] == null ? [] : List<Product>.from(json["products"]!.map((x) => Product.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "products": products == null ? [] : List<dynamic>.from(products!.map((x) => x.toJson())),
    "status": status,
  };
}

class Product {
  String? consoleName;
  String? id;
  int? loosePrice;
  String? productName;

  Product({
    this.consoleName,
    this.id,
    this.loosePrice,
    this.productName,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    consoleName: json["console-name"],
    id: json["id"],
    loosePrice: json["loose-price"],
    productName: json["product-name"],
  );

  Map<String, dynamic> toJson() => {
    "console-name": consoleName,
    "id": id,
    "loose-price": loosePrice,
    "product-name": productName,
  };
}
