// To parse this JSON data, do
//
//     final favoriteCardModel = favoriteCardModelFromJson(jsonString);

import 'dart:convert';

FavoriteCardModel favoriteCardModelFromJson(String str) =>
    FavoriteCardModel.fromJson(json.decode(str));

String favoriteCardModelToJson(FavoriteCardModel data) =>
    json.encode(data.toJson());

class FavoriteCardModel {

  FavCardData? body;

  FavoriteCardModel({

    this.body,

  });

  factory FavoriteCardModel.fromJson(Map<String, dynamic> json) =>
      FavoriteCardModel(

        body: json["body"] == null ? null : FavCardData.fromJson(json["body"]),

      );

  Map<String, dynamic> toJson() =>
      {

        "body": body?.toJson(),

      };
}

class FavCardData {
  String? id;
  bool? isFavorite;

  FavCardData({
    this.id,
    this.isFavorite,
  });

  factory FavCardData.fromJson(Map<String, dynamic> json) =>
      FavCardData(
        id: json["id"],
        isFavorite: json["isFavorite"],
      );

  Map<String, dynamic> toJson() =>
      {
        "id": id,
        "isFavorite": isFavorite,
      };
}
