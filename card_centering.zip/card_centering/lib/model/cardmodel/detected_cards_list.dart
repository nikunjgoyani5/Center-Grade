// To parse this JSON data, do
//
//     final detectedCardsList = detectedCardsListFromJson(jsonString);

import 'dart:convert';

DetectedCardsList detectedCardsListFromJson(String str) =>
    DetectedCardsList.fromJson(json.decode(str));

String detectedCardsListToJson(DetectedCardsList data) =>
    json.encode(data.toJson());

class DetectedCardsList {
  DetectedCardsData? body;

  DetectedCardsList({this.body});

  factory DetectedCardsList.fromJson(Map<String, dynamic> json) =>
      DetectedCardsList(
        body:
            json["body"] == null
                ? null
                : DetectedCardsData.fromJson(json["body"]),
      );

  Map<String, dynamic> toJson() => {"body": body?.toJson()};
}

class DetectedCardsData {
  int? page;
  int? totalPages;
  int? totalItems;
  int? limit;
  List<DetectedCards>? data;

  DetectedCardsData({
    this.page,
    this.totalPages,
    this.totalItems,
    this.limit,
    this.data,
  });

  factory DetectedCardsData.fromJson(Map<String, dynamic> json) =>
      DetectedCardsData(
        page: json["page"],
        totalPages: json["totalPages"],
        totalItems: json["totalItems"],
        limit: json["limit"],
        data:
            json["data"] == null
                ? []
                : List<DetectedCards>.from(
                  json["data"]!.map((x) => DetectedCards.fromJson(x)),
                ),
      );

  Map<String, dynamic> toJson() => {
    "page": page,
    "totalPages": totalPages,
    "totalItems": totalItems,
    "limit": limit,
    "data":
        data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class DetectedCards {
  String? id;
  String? userId;
  dynamic cardName;
  String? frontImageUrl;
  dynamic backImageUrl;
  Details? frontDetails;
  Details? backDetails;
  PriceCheckerDetails? priceCheckerDetails;
  bool? isFavorite;
  List<dynamic>? storeCollection;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  DetectedCards({
    this.id,
    this.userId,
    this.cardName,
    this.frontImageUrl,
    this.backImageUrl,
    this.frontDetails,
    this.backDetails,
    this.priceCheckerDetails,
    this.isFavorite,
    this.storeCollection,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory DetectedCards.fromJson(Map<String, dynamic> json) => DetectedCards(
    id: json["_id"],
    userId: json["userId"],
    cardName: json["cardName"],
    frontImageUrl: json["frontImageUrl"],
    backImageUrl: json["backImageUrl"],
    frontDetails:
        json["frontDetails"] == null
            ? null
            : Details.fromJson(json["frontDetails"]),
    backDetails:
        json["backDetails"] == null
            ? null
            : Details.fromJson(json["backDetails"]),
    priceCheckerDetails:
        json["priceCheckerDetails"] == null
            ? null
            : PriceCheckerDetails.fromJson(json["priceCheckerDetails"]),
    isFavorite: json["isFavorite"],
    storeCollection:
        json["storeCollection"] == null
            ? []
            : List<dynamic>.from(json["storeCollection"]!.map((x) => x)),
    createdAt:
        json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt:
        json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "userId": userId,
    "cardName": cardName,
    "frontImageUrl": frontImageUrl,
    "backImageUrl": backImageUrl,
    "frontDetails": frontDetails?.toJson(),
    "backDetails": backDetails?.toJson(),
    "priceCheckerDetails": priceCheckerDetails?.toJson(),
    "isFavorite": isFavorite,
    "storeCollection":
        storeCollection == null
            ? []
            : List<dynamic>.from(storeCollection!.map((x) => x)),
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "__v": v,
  };
}

class Details {
  String? leftRight;
  String? bottomTop;
  String? centering;
  String? aiGrade;
  String? cardSide;
  String? category;

  Details({
    this.leftRight,
    this.bottomTop,
    this.centering,
    this.aiGrade,
    this.cardSide,
    this.category,
  });

  factory Details.fromJson(Map<String, dynamic> json) => Details(
    leftRight: json["left_right"],
    bottomTop: json["bottom_top"],
    centering: json["centering"],
    aiGrade: json["ai_Grade"],
    cardSide: json["card_side"],
    category: json["category"],
  );

  Map<String, dynamic> toJson() => {
    "left_right": leftRight,
    "bottom_top": bottomTop,
    "centering": centering,
    "ai_Grade": aiGrade,
    "card_side": cardSide,
    "category": category,
  };
}

class PriceCheckerDetails {
  String? name;
  String? ungradedPrice;
  String? grade7Price;
  String? grade8Price;
  String? grade9Price;
  String? grade95Price;
  String? psa10Price;

  PriceCheckerDetails({
    this.name,
    this.ungradedPrice,
    this.grade7Price,
    this.grade8Price,
    this.grade9Price,
    this.grade95Price,
    this.psa10Price,
  });

  factory PriceCheckerDetails.fromJson(Map<String, dynamic> json) =>
      PriceCheckerDetails(
        name: json["name"],
        ungradedPrice: json["ungraded_price"],
        grade7Price: json["grade7_price"],
        grade8Price: json["grade8_price"],
        grade9Price: json["grade9_price"],
        grade95Price: json["grade9.5_price"],
        psa10Price: json["psa10_price"],
      );

  Map<String, dynamic> toJson() => {
    "name": name,
    "ungraded_price": ungradedPrice,
    "grade7_price": grade7Price,
    "grade8_price": grade8Price,
    "grade9_price": grade9Price,
    "grade9.5_price": grade95Price,
    "psa10_price": psa10Price,
  };
}
