// To parse this JSON data, do
//
//     final createCardModel = createCardModelFromJson(jsonString);

import 'dart:convert';

CreateCardModel createCardModelFromJson(String str) =>
    CreateCardModel.fromJson(json.decode(str));

String createCardModelToJson(CreateCardModel data) =>
    json.encode(data.toJson());

class CreateCardModel {
  CreateCardData? body;

  CreateCardModel({this.body});

  factory CreateCardModel.fromJson(Map<String, dynamic> json) =>
      CreateCardModel(
        body:
            json["body"] == null ? null : CreateCardData.fromJson(json["body"]),
      );

  Map<String, dynamic> toJson() => {"body": body?.toJson()};
}

class CreateCardData {
  String? userId;
  dynamic cardName;
  dynamic frontImageUrl;
  dynamic backImageUrl;
  FrontDetails? frontDetails;
  BackDetails? backDetails;
  PriceCheckerDetails? priceCheckerDetails;
  bool? isFavorite;
  List<dynamic>? storeCollection;
  String? id;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  CreateCardData({
    this.userId,
    this.cardName,
    this.frontImageUrl,
    this.backImageUrl,
    this.frontDetails,
    this.backDetails,
    this.priceCheckerDetails,
    this.isFavorite,
    this.storeCollection,
    this.id,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory CreateCardData.fromJson(Map<String, dynamic> json) => CreateCardData(
    userId: json["userId"],
    cardName: json["cardName"],
    frontImageUrl: json["frontImageUrl"],
    backImageUrl: json["backImageUrl"],
    frontDetails:
        json["frontDetails"] == null
            ? null
            : FrontDetails.fromJson(json["frontDetails"]),
    backDetails:
        json["backDetails"] == null
            ? null
            : BackDetails.fromJson(json["backDetails"]),
    priceCheckerDetails:
        json["priceCheckerDetails"] == null
            ? null
            : PriceCheckerDetails.fromJson(json["priceCheckerDetails"]),
    isFavorite: json["isFavorite"],
    storeCollection:
        json["storeCollection"] == null
            ? []
            : List<dynamic>.from(json["storeCollection"]!.map((x) => x)),
    id: json["_id"],
    createdAt:
        json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt:
        json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "userId": userId,
    "cardName": cardName,
    "frontImageUrl": frontImageUrl,
    "backImageUrl": backImageUrl,
    "frontDetails": frontDetails?.toJson(),
    "backDetails": backDetails?.toJson(),
    "priceCheckerDetails": priceCheckerDetails?.toJson(),
    "isFavorite": isFavorite,
    "storeCollection":
        storeCollection == null
            ? []
            : List<dynamic>.from(storeCollection!.map((x) => x)),
    "_id": id,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "__v": v,
  };
}

class BackDetails {
  String? leftRight;
  String? bottomTop;
  String? centering;
  String? aiGrade;
  String? cardSide;
  String? category;

  BackDetails({
    this.leftRight,
    this.bottomTop,
    this.centering,
    this.aiGrade,
    this.cardSide,
    this.category,
  });

  factory BackDetails.fromJson(Map<String, dynamic> json) => BackDetails(
    leftRight: json["left_right"],
    bottomTop: json["bottom_top"],
    centering: json["centering"],
    aiGrade: json["ai_Grade"],
    cardSide: json["card_side"],
    category: json["category"],
  );

  Map<String, dynamic> toJson() => {
    "left_right": leftRight,
    "bottom_top": bottomTop,
    "centering": centering,
    "ai_Grade": aiGrade,
    "card_side": cardSide,
    "category": category,
  };
}

class FrontDetails {
  String? leftRight;
  String? bottomTop;
  var centering;
  String? aiGrade;
  String? cardSide;
  String? category;

  FrontDetails({
    this.leftRight,
    this.bottomTop,
    this.centering,
    this.aiGrade,
    this.cardSide,
    this.category,
  });

  factory FrontDetails.fromJson(Map<String, dynamic> json) => FrontDetails(
    leftRight: json["left_right"],
    bottomTop: json["bottom_top"],
    centering: json["centering"],
    aiGrade: json["ai_Grade"],
    cardSide: json["card_side"],
    category: json["category"],
  );

  Map<String, dynamic> toJson() => {
    "left_right": leftRight,
    "bottom_top": bottomTop,
    "centering": centering,
    "ai_Grade": aiGrade,
    "card_side": cardSide,
    "category": category,
  };
}

class PriceCheckerDetails {
  String? name;
  String? ungradedPrice;
  String? grade7Price;
  String? grade8Price;
  String? grade9Price;
  String? grade95Price;
  String? psa10Price;

  PriceCheckerDetails({
    this.name,
    this.ungradedPrice,
    this.grade7Price,
    this.grade8Price,
    this.grade9Price,
    this.grade95Price,
    this.psa10Price,
  });

  factory PriceCheckerDetails.fromJson(Map<String, dynamic> json) =>
      PriceCheckerDetails(
        name: json["name"],
        ungradedPrice: json["ungraded_price"] ?? "-",
        grade7Price: json["grade7_price"] ?? "-",
        grade8Price: json["grade8_price"] ?? "-",
        grade9Price: json["grade9_price"] ?? "-",
        grade95Price: json["grade9.5_price"] ?? "-",
        psa10Price: json["psa10_price"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
    "name": name,
    "ungraded_price": ungradedPrice,
    "grade7_price": grade7Price,
    "grade8_price": grade8Price,
    "grade9_price": grade9Price,
    "grade9.5_price": grade95Price,
    "psa10_price": psa10Price,
  };
}
