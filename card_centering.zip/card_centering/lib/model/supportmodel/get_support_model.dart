// To parse this JSON data, do
//
//     final getSupportModel = getSupportModelFromJson(jsonString);

import 'dart:convert';

GetSupportModel getSupportModelFromJson(String str) => GetSupportModel.fromJson(json.decode(str));

String getSupportModelToJson(GetSupportModel data) => json.encode(data.toJson());

class GetSupportModel {
  String? message;
  List<SupportData>? body;
  bool? status;

  GetSupportModel({
    this.message,
    this.body,
    this.status,
  });

  factory GetSupportModel.fromJson(Map<String, dynamic> json) => GetSupportModel(
    message: json["message"],
    body: json["body"] == null ? [] : List<SupportData>.from(json["body"]!.map((x) => SupportData.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "body": body == null ? [] : List<dynamic>.from(body!.map((x) => x.toJson())),
    "status": status,
  };
}

class SupportData {
  String? id;
  String? email;
  String? subject;
  String? description;
  String? status;
  String? attachment;
  String? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  SupportData({
    this.id,
    this.email,
    this.subject,
    this.description,
    this.status,
    this.attachment,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory SupportData.fromJson(Map<String, dynamic> json) => SupportData(
    id: json["_id"],
    email: json["email"],
    subject: json["subject"],
    description: json["description"],
    status: json["status"],
    attachment: json["attachment"],
    userId: json["userId"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "email": email,
    "subject": subject,
    "description": description,
    "status": status,
    "attachment": attachment,
    "userId": userId,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "__v": v,
  };
}
