// To parse this JSON data, do
//
//     final userProfileModel = userProfileModelFromJson(jsonString);

import 'dart:convert';

UserProfileModel userProfileModelFromJson(String str) =>
    UserProfileModel.fromJson(json.decode(str));

String userProfileModelToJson(UserProfileModel data) =>
    json.encode(data.toJson());

class UserProfileModel {
  UserProfile? body;

  UserProfileModel({this.body});

  factory UserProfileModel.fromJson(Map<String, dynamic> json) =>
      UserProfileModel(
        body: json["body"] == null ? null : UserProfile.fromJson(json["body"]),
      );

  Map<String, dynamic> toJson() => {"body": body?.toJson()};
}

class UserProfile {
  String? id;
  String? email;
  String? fullname;
  String? profileImage;
  DateTime? dateOfBirth;

  UserProfile({
    this.id,
    this.email,
    this.fullname,
    this.profileImage,
    this.dateOfBirth,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
    id: json["_id"],
    email: json["email"],
    fullname: json["fullname"],
    profileImage: json["profileImage"],
    dateOfBirth:
        json["dateOfBirth"] == null
            ? null
            : DateTime.parse(json["dateOfBirth"]),
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "email": email,
    "fullname": fullname,
    "profileImage": profileImage,
    "dateOfBirth": dateOfBirth?.toIso8601String(),
  };
}
