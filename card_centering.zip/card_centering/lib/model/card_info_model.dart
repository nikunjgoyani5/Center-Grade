// To parse this JSON data, do
//
//     final cardInfoModel = cardInfoModelFromJson(jsonString);

import 'dart:convert';

CardInfoModel cardInfoModelFromJson(String str) => CardInfoModel.fromJson(json.decode(str));

String cardInfoModelToJson(CardInfoModel data) => json.encode(data.toJson());

class CardInfoModel {
  int? bgs10Price;
  int? boxOnlyPrice;
  int? cibPrice;
  int? condition17Price;
  int? condition18Price;
  String? consoleName;
  int? gamestopPrice;
  int? gamestopTradePrice;
  String? genre;
  int? gradedPrice;
  String? id;
  int? loosePrice;
  int? manualOnlyPrice;
  int? newPrice;
  String? productName;
  DateTime? releaseDate;
  int? retailCibBuy;
  int? retailCibSell;
  int? retailLooseBuy;
  int? retailLooseSell;
  int? retailNewBuy;
  int? retailNewSell;
  String? salesVolume;
  String? status;

  CardInfoModel({
    this.bgs10Price,
    this.boxOnlyPrice,
    this.cibPrice,
    this.condition17Price,
    this.condition18Price,
    this.consoleName,
    this.gamestopPrice,
    this.gamestopTradePrice,
    this.genre,
    this.gradedPrice,
    this.id,
    this.loosePrice,
    this.manualOnlyPrice,
    this.newPrice,
    this.productName,
    this.releaseDate,
    this.retailCibBuy,
    this.retailCibSell,
    this.retailLooseBuy,
    this.retailLooseSell,
    this.retailNewBuy,
    this.retailNewSell,
    this.salesVolume,
    this.status,
  });

  factory CardInfoModel.fromJson(Map<String, dynamic> json) => CardInfoModel(
    bgs10Price: json["bgs-10-price"],
    boxOnlyPrice: json["box-only-price"],
    cibPrice: json["cib-price"],
    condition17Price: json["condition-17-price"],
    condition18Price: json["condition-18-price"],
    consoleName: json["console-name"],
    gamestopPrice: json["gamestop-price"],
    gamestopTradePrice: json["gamestop-trade-price"],
    genre: json["genre"],
    gradedPrice: json["graded-price"],
    id: json["id"],
    loosePrice: json["loose-price"],
    manualOnlyPrice: json["manual-only-price"],
    newPrice: json["new-price"],
    productName: json["product-name"],
    releaseDate: json["release-date"] == null ? null : DateTime.parse(json["release-date"]),
    retailCibBuy: json["retail-cib-buy"],
    retailCibSell: json["retail-cib-sell"],
    retailLooseBuy: json["retail-loose-buy"],
    retailLooseSell: json["retail-loose-sell"],
    retailNewBuy: json["retail-new-buy"],
    retailNewSell: json["retail-new-sell"],
    salesVolume: json["sales-volume"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "bgs-10-price": bgs10Price,
    "box-only-price": boxOnlyPrice,
    "cib-price": cibPrice,
    "condition-17-price": condition17Price,
    "condition-18-price": condition18Price,
    "console-name": consoleName,
    "gamestop-price": gamestopPrice,
    "gamestop-trade-price": gamestopTradePrice,
    "genre": genre,
    "graded-price": gradedPrice,
    "id": id,
    "loose-price": loosePrice,
    "manual-only-price": manualOnlyPrice,
    "new-price": newPrice,
    "product-name": productName,
    "release-date": "${releaseDate!.year.toString().padLeft(4, '0')}-${releaseDate!.month.toString().padLeft(2, '0')}-${releaseDate!.day.toString().padLeft(2, '0')}",
    "retail-cib-buy": retailCibBuy,
    "retail-cib-sell": retailCibSell,
    "retail-loose-buy": retailLooseBuy,
    "retail-loose-sell": retailLooseSell,
    "retail-new-buy": retailNewBuy,
    "retail-new-sell": retailNewSell,
    "sales-volume": salesVolume,
    "status": status,
  };
}
