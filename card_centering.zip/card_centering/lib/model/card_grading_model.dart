// To parse this JSON data, do
//
//     final cardGradingModel = cardGradingModelFromJson(jsonString);

import 'dart:convert';

CardGradingModel cardGradingModelFromJson(String str) =>
    CardGradingModel.fromJson(json.decode(str));

String cardGradingModelToJson(CardGradingModel data) =>
    json.encode(data.toJson());

class CardGradingModel {
  List<Record>? records;
  Status? status;
  Statistics? statistics;

  CardGradingModel({this.records, this.status, this.statistics});

  factory CardGradingModel.fromJson(Map<String, dynamic> json) =>
      CardGradingModel(
        records:
        json["records"] == null
            ? []
            : List<Record>.from(
          json["records"]!.map((x) => Record.fromJson(x)),
        ),
        status: json["status"] == null ? null : Status.fromJson(json["status"]),
        statistics:
        json["statistics"] == null
            ? null
            : Statistics.fromJson(json["statistics"]),
      );

  Map<String, dynamic> toJson() => {
    "records":
    records == null
        ? []
        : List<dynamic>.from(records!.map((x) => x.toJson())),
    "status": status?.toJson(),
    "statistics": statistics?.toJson(),
  };
}

class Record {
  String? url;
  Status? status;
  String? id;
  int? width;
  int? height;
  List<Object>? objects;
  List<Corner>? corners;
  List<Edge>? edges;
  List<Card>? card;
  Versions? versions;
  Grades? grades;
  String? fullUrlCard;
  String? exactUrlCard;

  Record({
    this.url,
    this.status,
    this.id,
    this.width,
    this.height,
    this.objects,
    this.corners,
    this.edges,
    this.card,
    this.versions,
    this.grades,
    this.fullUrlCard,
    this.exactUrlCard,
  });

  factory Record.fromJson(Map<String, dynamic> json) => Record(
    url: json["_url"],
    status: json["_status"] == null ? null : Status.fromJson(json["_status"]),
    id: json["_id"],
    width: json["_width"],
    height: json["_height"],
    objects:
    json["_objects"] == null
        ? []
        : List<Object>.from(
      json["_objects"]!.map((x) => Object.fromJson(x)),
    ),
    corners:
    json["corners"] == null
        ? []
        : List<Corner>.from(
      json["corners"]!.map((x) => Corner.fromJson(x)),
    ),
    edges:
    json["edges"] == null
        ? []
        : List<Edge>.from(json["edges"]!.map((x) => Edge.fromJson(x))),
    card:
    json["card"] == null
        ? []
        : List<Card>.from(json["card"]!.map((x) => Card.fromJson(x))),
    versions:
    json["versions"] == null ? null : Versions.fromJson(json["versions"]),
    grades: json["grades"] == null ? null : Grades.fromJson(json["grades"]),
    fullUrlCard: json["_full_url_card"],
    exactUrlCard: json["_exact_url_card"],
  );

  Map<String, dynamic> toJson() => {
    "_url": url,
    "_status": status?.toJson(),
    "_id": id,
    "_width": width,
    "_height": height,
    "_objects":
    objects == null
        ? []
        : List<dynamic>.from(objects!.map((x) => x.toJson())),
    "corners":
    corners == null
        ? []
        : List<dynamic>.from(corners!.map((x) => x.toJson())),
    "edges":
    edges == null ? [] : List<dynamic>.from(edges!.map((x) => x.toJson())),
    "card":
    card == null ? [] : List<dynamic>.from(card!.map((x) => x.toJson())),
    "versions": versions?.toJson(),
    "grades": grades?.toJson(),
    "_full_url_card": fullUrlCard,
    "_exact_url_card": exactUrlCard,
  };
}

class Card {
  String? name;
  List<List<num>>? polygon;
  List<num>? boundBox;
  Tags? tags;
  Surface? surface;
  Centering? centering;

  Card({
    this.name,
    this.polygon,
    this.boundBox,
    this.tags,
    this.surface,
    this.centering,
  });

  factory Card.fromJson(Map<String, dynamic> json) => Card(
    name: json["name"],
    polygon:
    json["polygon"] == null
        ? []
        : List<List<int>>.from(
      json["polygon"]!.map((x) => List<int>.from(x.map((x) => x))),
    ),
    boundBox:
    json["bound_box"] == null
        ? []
        : List<int>.from(json["bound_box"]!.map((x) => x)),
    tags: json["_tags"] == null ? null : Tags.fromJson(json["_tags"]),
    surface: json["surface"] == null ? null : Surface.fromJson(json["surface"]),
    centering:
    json["centering"] == null
        ? null
        : Centering.fromJson(json["centering"]),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "polygon":
    polygon == null
        ? []
        : List<dynamic>.from(
      polygon!.map((x) => List<dynamic>.from(x.map((x) => x))),
    ),
    "bound_box":
    boundBox == null ? [] : List<dynamic>.from(boundBox!.map((x) => x)),
    "_tags": tags?.toJson(),
    "surface": surface?.toJson(),
    "centering": centering?.toJson(),
  };
}

class Centering {
  String? leftRight;
  String? topBottom;
  List<double>? boundBox;
  num? grade;

  Centering({this.leftRight, this.topBottom, this.boundBox, this.grade});

  factory Centering.fromJson(Map<String, dynamic> json) => Centering(
    leftRight: json["left/right"],
    topBottom: json["top/bottom"],
    boundBox:
    json["bound_box"] == null
        ? []
        : List<double>.from(json["bound_box"]!.map((x) => x?.toDouble())),
    grade: json["grade"],
  );

  Map<String, dynamic> toJson() => {
    "left/right": leftRight,
    "top/bottom": topBottom,
    "bound_box":
    boundBox == null ? [] : List<dynamic>.from(boundBox!.map((x) => x)),
    "grade": grade,
  };
}

class Surface {
  num? grade;

  Surface({this.grade});

  factory Surface.fromJson(Map<String, dynamic> json) =>
      Surface(grade: json["grade"]);

  Map<String, dynamic> toJson() => {"grade": grade};
}

class Tags {
  List<Object>? category;
  List<Object>? damaged;
  List<Object>? autograph;
  List<Object>? side;

  Tags({this.category, this.damaged, this.autograph, this.side});

  factory Tags.fromJson(Map<String, dynamic> json) => Tags(
    category:
    json["Category"] == null
        ? []
        : List<Object>.from(
      json["Category"]!.map((x) => Object.fromJson(x)),
    ),
    damaged:
    json["Damaged"] == null
        ? []
        : List<Object>.from(
      json["Damaged"]!.map((x) => Object.fromJson(x)),
    ),
    autograph:
    json["Autograph"] == null
        ? []
        : List<Object>.from(
      json["Autograph"]!.map((x) => Object.fromJson(x)),
    ),
    side:
    json["Side"] == null
        ? []
        : List<Object>.from(json["Side"]!.map((x) => Object.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Category":
    category == null
        ? []
        : List<dynamic>.from(category!.map((x) => x.toJson())),
    "Damaged":
    damaged == null
        ? []
        : List<dynamic>.from(damaged!.map((x) => x.toJson())),
    "Autograph":
    autograph == null
        ? []
        : List<dynamic>.from(autograph!.map((x) => x.toJson())),
    "Side":
    side == null ? [] : List<dynamic>.from(side!.map((x) => x.toJson())),
  };
}

class Object {
  String? name;
  String? id;
  List<num>? boundBox;
  num? prob;

  Object({this.name, this.id, this.boundBox, this.prob});

  factory Object.fromJson(Map<String, dynamic> json) => Object(
    name: json["name"],
    id: json["id"],
    boundBox:
    json["bound_box"] == null
        ? []
        : List<int>.from(json["bound_box"]!.map((x) => x)),
    prob: json["prob"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "id": id,
    "bound_box":
    boundBox == null ? [] : List<dynamic>.from(boundBox!.map((x) => x)),
    "prob": prob,
  };
}

class Corner {
  String? name;
  List<num>? boundBox;
  List<num>? point;
  num? grade;

  Corner({this.name, this.boundBox, this.point, this.grade});

  factory Corner.fromJson(Map<String, dynamic> json) => Corner(
    name: json["name"],
    boundBox:
    json["bound_box"] == null
        ? []
        : List<int>.from(json["bound_box"]!.map((x) => x)),
    point:
    json["point"] == null
        ? []
        : List<int>.from(json["point"]!.map((x) => x)),
    grade: json["grade"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "bound_box":
    boundBox == null ? [] : List<dynamic>.from(boundBox!.map((x) => x)),
    "point": point == null ? [] : List<dynamic>.from(point!.map((x) => x)),
    "grade": grade,
  };
}

class Edge {
  String? name;
  List<List<int>>? polygon;
  double? grade;

  Edge({this.name, this.polygon, this.grade});

  factory Edge.fromJson(Map<String, dynamic> json) => Edge(
    name: json["name"],
    polygon:
    json["polygon"] == null
        ? []
        : List<List<int>>.from(
      json["polygon"]!.map((x) => List<int>.from(x.map((x) => x))),
    ),
    grade: json["grade"]?.toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "polygon":
    polygon == null
        ? []
        : List<dynamic>.from(
      polygon!.map((x) => List<dynamic>.from(x.map((x) => x))),
    ),
    "grade": grade,
  };
}

class Grades {
  num? corners;
  num? edges;
  num? surface;
  num? centering;
  num? gradesFinal;
  String? condition;

  Grades({
    this.corners,
    this.edges,
    this.surface,
    this.centering,
    this.gradesFinal,
    this.condition,
  });

  factory Grades.fromJson(Map<String, dynamic> json) => Grades(
    corners: json["corners"],
    edges: json["edges"]?.toDouble(),
    surface: json["surface"],
    centering: json["centering"],
    gradesFinal: json["final"]?.toDouble(),
    condition: json["condition"],
  );

  Map<String, dynamic> toJson() => {
    "corners": corners,
    "edges": edges,
    "surface": surface,
    "centering": centering,
    "final": gradesFinal,
    "condition": condition,
  };
}

class Status {
  int? code;
  String? text;
  String? requestId;
  String? procId;

  Status({this.code, this.text, this.requestId, this.procId});

  factory Status.fromJson(Map<String, dynamic> json) => Status(
    code: json["code"],
    text: json["text"],
    requestId: json["request_id"],
    procId: json["proc_id"],
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "text": text,
    "request_id": requestId,
    "proc_id": procId,
  };
}

class Versions {
  String? detection;
  String? points;
  String? corners;
  String? edges;
  String? surface;
  String? centering;
  String? versionsFinal;

  Versions({
    this.detection,
    this.points,
    this.corners,
    this.edges,
    this.surface,
    this.centering,
    this.versionsFinal,
  });

  factory Versions.fromJson(Map<String, dynamic> json) => Versions(
    detection: json["detection"],
    points: json["points"],
    corners: json["corners"],
    edges: json["edges"],
    surface: json["surface"],
    centering: json["centering"],
    versionsFinal: json["final"],
  );

  Map<String, dynamic> toJson() => {
    "detection": detection,
    "points": points,
    "corners": corners,
    "edges": edges,
    "surface": surface,
    "centering": centering,
    "final": versionsFinal,
  };
}

class Statistics {
  num? processingTime;

  Statistics({this.processingTime});

  factory Statistics.fromJson(Map<String, dynamic> json) =>
      Statistics(processingTime: json["processing time"]?.toDouble());

  Map<String, dynamic> toJson() => {"processing time": processingTime};
}
