import 'dart:convert';

AdModel adModelFromJson(String str) => AdModel.fromJson(json.decode(str));

String adModelToJson(AdModel data) => json.encode(data.toJson());

class AdModel {
  // bool? updatedStatus;
  // int? updatedType;
  bool? appLiveStatus;
  String? newPackage;
  bool? showAds;
  bool? isAccessStats;

  // String? monthlyKey;
  // String? weeklyKey;
  // String? monthlyPrice;
  // String? weeklyPrice;
  // bool? homeScreenAds;
  int? userClickCounter;
  int? addAppCount;
  int? templateCount;
  String? appId;

  // String? interstitialAdId;
  // CustomAdModel? banner;
  // CustomAdModel? interstitial;
  // CustomAdModel? native;
  // CustomAdModel? openApp;
  Map<String, AdsData>? adsData;

  AdModel({
    // this.updatedStatus,
    // this.updatedType,
    this.appLiveStatus,
    this.newPackage,
    this.showAds,
    this.isAccessStats,
    // this.monthlyKey,
    // this.weeklyKey,
    // this.monthlyPrice,
    // this.weeklyPrice,
    // this.homeScreenAds,
    this.userClickCounter,
    this.addAppCount,
    this.templateCount,
    this.appId,
    // this.interstitialAdId,
    // this.banner,
    // this.interstitial,
    // this.native,
    // this.openApp,
    this.adsData,
  });

  factory AdModel.fromJson(Map<String, dynamic> json) => AdModel(
    // updatedStatus: json["updated_status"] ?? true,
    // updatedType: json["updated_type"] ?? 0,
    appLiveStatus: json["app_live_status"] ?? false,
    newPackage: json["new_package"] ?? '',
    showAds: json["show_ads"] ?? false,
    isAccessStats: json["is_access_stats"] ?? true,
    // monthlyKey: json["monthly_key"] ?? '',
    // weeklyKey: json["weekly_key"] ?? '',
    // monthlyPrice: json["monthly_price"] ?? '',
    // weeklyPrice: json["weekly_price"] ?? '',
    // homeScreenAds: json["home_screen_ads"] ?? false,
    userClickCounter: json["user_click_counter"] ?? 2,
    addAppCount: json["add_app_count"] ?? 3,
    templateCount: json["template_count"] ?? 2,
    appId: json["app_id"] ?? '',
    // interstitialAdId: json["interstitial_ad_id"] ?? '',
    // banner: CustomAdModel.fromJson(json["banner"]),
    // interstitial: CustomAdModel.fromJson(json["interstitial"]),
    // native: CustomAdModel.fromJson(json["native"]),
    // openApp: CustomAdModel.fromJson(json["open_app"]),
    adsData: Map.from(json["ads_data"])
        .map((k, v) => MapEntry<String, AdsData>(k, AdsData.fromJson(v))),
  );

  Map<String, dynamic> toJson() => {
    // "updated_status": updatedStatus,
    // "updated_type": updatedType,
    "app_live_status": appLiveStatus,
    "new_package": newPackage,
    "show_ads": showAds,
    "is_access_stats": isAccessStats,
    // "monthly_key": monthlyKey,
    // "weekly_key": weeklyKey,
    // "monthly_price": monthlyPrice,
    // "weekly_price": weeklyPrice,
    // "home_screen_ads": homeScreenAds,
    "user_click_counter": userClickCounter,
    "add_app_count": addAppCount,
    "template_count": templateCount,
    "app_id": appId,
    // "interstitial_ad_id": interstitialAdId,
    // "banner": banner?.toJson(),
    // "interstitial": interstitial?.toJson(),
    // "native": native?.toJson(),
    // "open_app": openApp?.toJson(),
    "ads_data": Map.from(adsData!)
        .map((k, v) => MapEntry<String, dynamic>(k, v.toJson())),
  };
}

class CustomAdModel {
  String? adAppIcon;
  String? adCallToActionUrl;
  String? adCallToActionText;
  String? adHeadline;
  String? adBody;
  String? adMedia;
  String? infoUrl;

  CustomAdModel(
      {this.adAppIcon,
        this.adCallToActionUrl,
        this.adCallToActionText,
        this.adHeadline,
        this.adBody,
        this.adMedia,
        this.infoUrl});

  factory CustomAdModel.fromJson(Map<String, dynamic> map) => CustomAdModel(
    adAppIcon: map['ad_app_icon'] ?? '',
    adCallToActionUrl: map['ad_call_to_action_url'] ?? '',
    adCallToActionText: map['ad_call_to_action_text'] ?? '',
    adHeadline: map['ad_headline'] ?? '',
    adBody: map['ad_body'] ?? '',
    adMedia: map['ad_media'] ?? '',
    infoUrl: map['info_url'] ?? '',
  );

  Map<String, dynamic> toJson() => {
    "ad_app_icon": adAppIcon,
    "ad_call_to_action_url": adCallToActionUrl,
    "ad_call_to_action_text": adCallToActionText,
    "ad_headline": adHeadline,
    "ad_body": adBody,
    "ad_media": adMedia,
    "info_url": infoUrl,
  };
}

class AdsData {
  String? adsName;
  String? adsType;
  String? idAds;
  bool? enableAds;
  int? frequency;
  String? publishers;

  AdsData({
    this.adsName,
    this.adsType,
    this.idAds,
    this.enableAds,
    this.frequency,
    this.publishers,
  });

  factory AdsData.fromJson(Map<String, dynamic> json) => AdsData(
    adsName: json["adsName"],
    adsType: json["adsType"],
    idAds: json["idAds"] ?? '',
    enableAds: json["enableAds"],
    frequency: json["frequency"],
    publishers: json["publishers"],
  );

  Map<String, dynamic> toJson() => {
    "adsName": adsName,
    "adsType": adsType,
    "idAds": idAds,
    "enableAds": enableAds,
    "frequency": frequency,
    "publishers": publishers,
  };
}
