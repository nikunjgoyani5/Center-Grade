import 'dart:convert';

CollectionListModel collectionListModelFromJson(String str) =>
    CollectionListModel.fromJson(json.decode(str));

String collectionListModelToJson(CollectionListModel data) =>
    json.encode(data.toJson());

class CollectionListModel {
  List<CollectionListData>? body;

  CollectionListModel({this.body});

  factory CollectionListModel.fromJson(Map<String, dynamic> json) =>
      CollectionListModel(
        body:
            json["body"] == null
                ? []
                : List<CollectionListData>.from(
                  json["body"]!.map((x) => CollectionListData.fromJson(x)),
                ),
      );

  Map<String, dynamic> toJson() => {
    "body":
        body == null ? [] : List<dynamic>.from(body!.map((x) => x.toJson())),
  };
}

class CollectionListData {
  String? id;
  String? userId;
  String? name;
  bool? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? itemCount;

  CollectionListData({
    this.id,
    this.userId,
    this.name,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.itemCount,
  });

  factory CollectionListData.fromJson(
    Map<String, dynamic> json,
  ) => CollectionListData(
    id: json["_id"],
    userId: json["userId"],
    name: json["name"],
    isDefault: json["isDefault"],
    createdAt:
        json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt:
        json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    itemCount: json["itemCount"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "userId": userId,
    "name": name,
    "isDefault": isDefault,
    "createdAt": createdAt?.toIso8601String(),
    "updatedAt": updatedAt?.toIso8601String(),
    "__v": v,
    "itemCount": itemCount,
  };
}
