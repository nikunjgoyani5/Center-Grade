// To parse this JSON data, do
//
//     final loginModel = loginModelFromJson(jsonString);

import 'dart:convert';

LoginModel loginModelFromJson(String str) =>
    LoginModel.fromJson(json.decode(str));

String loginModelToJson(LoginModel data) => json.encode(data.toJson());

class LoginModel {
  String? message;
  LoginBody? body;
  bool? status;

  LoginModel({this.message, this.body, this.status});

  factory LoginModel.fromJson(Map<String, dynamic> json) => LoginModel(
    message: json["message"],
    body: json["body"] == null ? null : LoginBody.fromJson(json["body"]),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "body": body?.toJson(),
    "status": status,
  };
}

class LoginBody {
  String? token;
  User? user;

  LoginBody({this.token, this.user});

  factory LoginBody.fromJson(Map<String, dynamic> json) => LoginBody(
    token: json["token"],
    user: json["user"] == null ? null : User.fromJson(json["user"]),
  );

  Map<String, dynamic> toJson() => {"token": token, "user": user?.toJson()};
}

class User {
  DateTime? dateOfBirth;
  String? id;
  String? email;
  String? fullname;
  dynamic profileImage;

  User({
    this.dateOfBirth,
    this.id,
    this.email,
    this.fullname,
    this.profileImage,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    dateOfBirth:
    json["dateOfBirth"] == null
        ? null
        : DateTime.parse(json["dateOfBirth"]),
    id: json["_id"],
    email: json["email"],
    fullname: json["fullname"],
    profileImage: json["profileImage"],
  );

  Map<String, dynamic> toJson() => {
    "dateOfBirth": dateOfBirth?.toIso8601String(),
    "_id": id,
    "email": email,
    "fullname": fullname,
    "profileImage": profileImage,
  };
}
