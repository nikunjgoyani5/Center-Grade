import 'package:card_centering/apptheme/theme_data.dart';
import 'package:card_centering/localization/localization.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:logic_go_network/network/rest_client.dart';

import 'apptheme/app_constants.dart';
import 'apptheme/app_strings.dart';
import 'firebase_options.dart';
import 'firebaseservice/remote_config_service.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'networkservice/network_service.dart';
import 'pages/splash_screen.dart';

bool? subActive;
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  bool isNetworkConnected = await InternetConnectionChecker().hasConnection;
  if (isNetworkConnected) {
    await RemoteConfigService().initialize();
    await NetworkConnectionService().init();
  }
  MobileAds.instance.initialize();

  final isLightMode = await PrefManager().getBoolData(key: isLightModeKey);
  final isLogin = await PrefManager().getBoolData(key: isLoginKey);
  // await RevenueCatService.initRevenueCat();
  try {
    FlutterError.onError = (errorDetails) {
      FirebaseCrashlytics.instance.recordFlutterFatalError(errorDetails);
    };
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  } catch (e) {
    debugPrint('Crashlytics Error ${e.toString()}');
  }

  restClient = RestClient(
    baseUrl: baseUrl,
    token: token,
    connectionTO: 30000,
    receiveTO: 30000,
  );

  runApp(MyApp(isLightMode: isLightMode, isLogin: isLogin));
}

class MyApp extends StatefulWidget {
  final bool isLightMode;
  final bool isLogin;

  const MyApp({super.key, required this.isLightMode, required this.isLogin});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String langCode = "";
  String countryCode = "";

  @override
  void initState() {
    getLanguage();
    super.initState();
  }

  getLanguage() async {
    langCode = await PrefManager().getStringData(key: languageCode) ?? "en";
    countryCode = await PrefManager().getStringData(key: contCode) ?? "US";

    await Get.updateLocale(Locale(langCode, countryCode));
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 932),
      minTextAdapt: true,
      splitScreenMode: true,
      child: GetMaterialApp(
        title: appName,
        debugShowCheckedModeBanner: false,
        darkTheme: darkTheme,
        themeMode: widget.isLightMode ? ThemeMode.light : ThemeMode.dark,
        theme: lightTheme,
        translations: Localization(),
        locale: Locale(
          langCode.isNotEmpty ? langCode : "en",
          countryCode.isNotEmpty ? countryCode : 'US',
        ),
        home: SplashScreen(isLogin: widget.isLogin),
        // home: widget.isLogin ? const DashboardScreen() : const AuthScreen(),
      ),
    );
  }
}
