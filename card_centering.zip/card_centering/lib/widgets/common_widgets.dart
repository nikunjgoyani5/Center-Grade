import 'dart:developer';

import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../apptheme/app_colors.dart';

commonSnackbar({required BuildContext context, required String message}) {
  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.primaryPurple,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      content: Text(
        message,
        style: AppTextStyle.medium16(color: AppColors.whiteColor),
      ),
    ),
  );
}

showToast({required String message}) {
  return Fluttertoast.showToast(
    msg: message,
    backgroundColor: AppColors.primaryPurple,
    textColor: AppColors.whiteColor,
    gravity: ToastGravity.TOP,
  );
}

String getCatchFinalErrorMsg(Object e) {
  log("Unknown Error === ${e.toString()}");

  String errorMessage = someThingWentWrong.tr;
  if (e is Map && e.containsKey('error') && e['error'].containsKey('message')) {
    errorMessage = e['error']['message'];
  } else if (e.toString().contains('message:')) {
    final RegExp regex = RegExp(r'message:\s(.*?),');
    final match = regex.firstMatch(e.toString());
    if (match != null) {
      errorMessage = match.group(1)!;
    }
  } else {
    errorMessage = e.toString();
  }
  return errorMessage;
}

showLoader() {
  return Container(
    height: Get.height,
    width: Get.width,
    color: Colors.black38,
    alignment: Alignment.center,
    child: const Wrap(children: [CircularProgressIndicator.adaptive()]),
  );
}
