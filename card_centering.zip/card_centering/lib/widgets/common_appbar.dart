import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../apptheme/app_assets.dart';
import '../apptheme/app_colors.dart';
import '../apptheme/app_constants.dart';
import '../apptheme/app_textstyle.dart';

commonAppbar({
  required String title,
  List<Widget>? action,
  bool isShowBackButton = true,
  Function? leadingTap,
}) {
  return AppBar(
    elevation: 0,
    toolbarHeight: 80.h,
    leading:
        isShowBackButton == false
            ? null
            : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.back();
                    leadingTap;
                  },
                  child: Container(
                    height: 45.h,
                    width: 45.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          isDarkMode()
                              ? AppColors.black1E1E1E
                              : AppColors.whiteFAFAFA,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.greyEBEBEB,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          isDarkMode()
                              ? AppAssets.icArrowBackDark
                              : AppAssets.icArrowBack,
                          width: 18,
                          height: 18,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    actions: action,
    backgroundColor:
        isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
    scrolledUnderElevation: 0.0,
    automaticallyImplyLeading: false,
    centerTitle: true,
    title: Text(
      title,
      style: AppTextStyle.semiBold24(
        color: isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
      ),
    ),
  );
}
