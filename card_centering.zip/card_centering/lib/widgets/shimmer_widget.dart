import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';

import '../apptheme/app_colors.dart';
import '../apptheme/app_constants.dart';
import '../apptheme/app_textstyle.dart';

showSearchShimmer() {
  return Shimmer.fromColors(
    baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
    highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
    child: ListView.separated(
      itemCount: 6,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
              ),
            ),
          ),

          child: ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 15.w),

            dense: true,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 300.w,
                  height: 25.h,
                  color: Colors.grey,
                  child: Text(
                    "",
                    style: AppTextStyle.medium20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                ),
                SizedBox(height: 12.h),
                Container(
                  width: 100.w,
                  height: 16.h,
                  color: Colors.grey,
                  child: Text(
                    '',
                    style: AppTextStyle.medium17(
                      color:
                          isDarkMode()
                              ? AppColors.grey9B9B9B
                              : AppColors.primaryPurple,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      separatorBuilder: (context, index) {
        return SizedBox(height: 10.h);
      },
    ),
  );
}

showFavShimmer() {
  return Shimmer.fromColors(
    baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
    highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
    child: GridView.builder(
      itemCount: 6,
      padding: EdgeInsets.only(left: 20.w, right: 20.w, top: 10.h),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
        childAspectRatio: 5 / 4,
      ),
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.r),
            color: Colors.transparent, // allow shimmer to show
            border: Border.all(
              color: isDarkMode() ? AppColors.greyCCCCCC : AppColors.greyEBEBEB,
            ),
          ),
          padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  Container(
                    height: 30,
                    width: 30,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4.r),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15.h),
              Container(
                height: 20.h,
                width: 120.w,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(4.r),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}

showCollectionShimmer() {
  return Shimmer.fromColors(
    baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
    highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
    child: GridView.builder(
      padding: EdgeInsets.only(
        left: 20.w,
        right: 20.w,
        top: 20.h,
        bottom: 20.h,
      ),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        // childAspectRatio: 5 / 4,
      ),
      itemCount: 8,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.transparent,
            border: Border.all(
              color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
            ),
            borderRadius: BorderRadius.circular(15.r),
          ),
          padding: EdgeInsets.only(left: 15.w, top: 15.h, bottom: 15.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 15.w),
                    height: 40.h,
                    width: 15.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5.r),
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15.h),
              Container(
                height: 20.h,
                width: 100.w,
                decoration: BoxDecoration(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                  borderRadius: BorderRadius.circular(4.r),
                ),
              ),
              SizedBox(height: 12.h),
              Container(
                height: 20.h,
                width: 80.w,
                decoration: BoxDecoration(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                  borderRadius: BorderRadius.circular(4.r),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}

showCardsCollectionShimmer() {
  return Shimmer.fromColors(
    baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
    highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
    child: GridView.builder(
      padding: EdgeInsets.only(
        left: 20.w,
        right: 20.w,
        top: 20.h,
        bottom: 20.h,
      ),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        // childAspectRatio: 5 / 4,
      ),
      itemCount: 8,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.transparent,
            border: Border.all(
              color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
            ),
            borderRadius: BorderRadius.circular(15.r),
          ),
          padding: EdgeInsets.only(left: 15.w, top: 15.h, bottom: 15.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20.h),

              Center(
                child: Container(
                  height: 70.h,
                  width: 70.w,
                  decoration: BoxDecoration(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 20.h,
                    width: 100.w,
                    decoration: BoxDecoration(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                      borderRadius: BorderRadius.circular(4.r),
                    ),
                  ),
                  Container(
                    height: 35.h,
                    width: 16.w,
                    decoration: BoxDecoration(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                      borderRadius: BorderRadius.circular(4.r),
                    ),
                    margin: EdgeInsets.only(right: 15.w),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    ),
  );
}

showScanCardShimmer() {
  return Scaffold(
    body: Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Column(
            children: [
              SizedBox(height: 20.h),
              Shimmer.fromColors(
                baseColor:
                    isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
                highlightColor:
                    isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
                child: Container(
                  height: 400.h,
                  width: 250.w,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),

              SizedBox(height: 20.h),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Shimmer.fromColors(
                        baseColor:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : Colors.grey[300]!,
                        highlightColor:
                            isDarkMode()
                                ? AppColors.grey9B9B9B
                                : Colors.grey[100]!,
                        child: Container(
                          height: 20.h,
                          width: 200.w,

                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(8.r),
                          ),
                        ),
                      ),

                      SizedBox(height: 15.h),

                      // TabBar Placeholder
                      Shimmer.fromColors(
                        baseColor:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : Colors.grey[300]!,
                        highlightColor:
                            isDarkMode()
                                ? AppColors.grey9B9B9B
                                : Colors.grey[100]!,
                        child: Container(
                          height: 45.h,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(30.r),
                          ),
                        ),
                      ),

                      SizedBox(height: 12.h),

                      // Button Placeholder
                      Shimmer.fromColors(
                        baseColor:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : Colors.grey[300]!,
                        highlightColor:
                            isDarkMode()
                                ? AppColors.grey9B9B9B
                                : Colors.grey[100]!,
                        child: Container(
                          width: double.infinity,
                          height: 55.h,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(8.r),
                          ),
                        ),
                      ),

                      SizedBox(height: 12.h),

                      // TabBarView Content Placeholders
                      Shimmer.fromColors(
                        baseColor:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : Colors.grey[300]!,
                        highlightColor:
                            isDarkMode()
                                ? AppColors.grey9B9B9B
                                : Colors.grey[100]!,
                        child: gradingShimmerWidget(),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          // Bottom Buttons Placeholder
          Padding(
            padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 15.h),
            child: Row(
              children: [
                Expanded(
                  child: Shimmer.fromColors(
                    baseColor:
                        isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
                    highlightColor:
                        isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
                    child: Container(
                      height: 60.h,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 15.w),
                Expanded(
                  child: Shimmer.fromColors(
                    baseColor:
                        isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
                    highlightColor:
                        isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
                    child: Container(
                      height: 60.h,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget gradingShimmerWidget() {
  return Column(
    children: List.generate(6, (index) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 8.h),
        child: Container(
          height: 25.h,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.grey,
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
      );
    }),
  );
}

Widget showPriceCheckerShimmer() {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 20.w),
    child: Column(
      children: [
        SizedBox(height: 20.h),
        Center(
          child: Shimmer.fromColors(
            baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
            highlightColor:
                isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
            child: Container(
              height: 24.h,
              width: 150.w,
              decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.circular(6.r),
              ),
            ),
          ),
        ),
        SizedBox(height: 10.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            shimmerPriceBox(),
            SizedBox(width: 12.w),
            shimmerPriceBox(),
            SizedBox(width: 12.w),
            shimmerPriceBox(),
          ],
        ),
        SizedBox(height: 15.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            shimmerPriceBox(),
            SizedBox(width: 12.w),
            shimmerPriceBox(),
            SizedBox(width: 12.w),
            shimmerPriceBox(),
          ],
        ),
      ],
    ),
  );
}

Widget shimmerPriceBox() {
  return Expanded(
    child: Shimmer.fromColors(
      baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
      highlightColor: isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
      child: Container(
        height: 80.h,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius: BorderRadius.circular(10.r),
        ),
      ),
    ),
  );
}

Widget showTickerShimmer() {
  return ListView.separated(
    itemCount: 6,
    separatorBuilder: (_, __) => SizedBox(height: 10.h),
    padding: EdgeInsets.only(bottom: 80.h),
    itemBuilder:
        (context, index) => Shimmer.fromColors(
          baseColor: isDarkMode() ? AppColors.grey2A2A2A : Colors.grey[300]!,
          highlightColor:
              isDarkMode() ? AppColors.grey9B9B9B : Colors.grey[100]!,
          child: Container(
            padding: EdgeInsets.all(18.sp),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.r),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(width: 160.w, height: 18.h, color: Colors.white),
                SizedBox(height: 10.h),

                Container(
                  width: double.infinity,
                  height: 14.h,
                  color: Colors.white,
                ),
                SizedBox(height: 6.h),

                Container(
                  width: Get.width * 0.8,
                  height: 14.h,
                  color: Colors.white,
                ),
                SizedBox(height: 6.h),
              ],
            ),
          ),
        ),
  );
}
