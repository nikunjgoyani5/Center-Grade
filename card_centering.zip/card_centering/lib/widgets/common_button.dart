import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../apptheme/app_colors.dart';

class CommonButton extends StatelessWidget {
  final void Function() onPressed;
  final void Function(bool)? onHover;
  final Widget child;
  final Color? buttonColor;
  final double? buttonHeight;
  final double? buttonWidth;
  final Color? borderColor;
  final double? radius;

  const CommonButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.buttonColor,
    this.buttonHeight,
    this.buttonWidth,
    this.radius,
    this.borderColor,
    this.onHover,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        shadowColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius ?? 8),
          side:
              borderColor != null
                  ? BorderSide(color: borderColor ?? AppColors.primaryColor)
                  : BorderSide.none,
        ),
        backgroundColor: buttonColor ?? AppColors.primaryPurple,
        elevation: 0,
        padding:
            (buttonWidth != null || buttonHeight != null)
                ? EdgeInsets.zero
                : EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 2.3.h),
        minimumSize:
            (buttonWidth != null || buttonHeight != null)
                ? Size(buttonWidth ?? double.infinity, buttonHeight ?? 55.sp)
                : null,
        fixedSize:
            (buttonWidth != null || buttonHeight != null)
                ? Size(buttonWidth ?? double.infinity, buttonHeight ?? 55.sp)
                : null,
      ),
      onHover: onHover,
      onPressed: onPressed,
      child: child,
    );
  }
}
