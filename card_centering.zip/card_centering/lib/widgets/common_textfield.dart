import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../apptheme/app_colors.dart';
import '../apptheme/app_constants.dart';
import '../apptheme/app_textstyle.dart';

commonTextfield({
  required TextEditingController controller,
  required String hintText,
  ValueChanged<String?>? onChanged,
  FormFieldValidator<String?>? validator,
  VoidCallback? onTap,
  bool isObscure = false,
  Widget? suffixWidget,
  Widget? prefixWidget,
  FocusNode? focusNode,
  TextInputType? keyboardType,
  Function(String)? onSubmitted,
  FormFieldValidator<String?>? onSaved,
  List<TextInputFormatter>? textFormatter,
  final BorderSide? errorBorderSide,
  final BorderSide? focusedErrorBorderSide,
  final int? maxLines = 1,
  final int? minLines
}) {
  return TextFormField(
    focusNode: focusNode,
    controller: controller,
    onChanged: onChanged,
    validator: validator,
    maxLines: maxLines,
    onTap: onTap,
    obscureText: isObscure,
    onSaved: onSaved,
    inputFormatters: textFormatter,
    keyboardType: keyboardType ?? TextInputType.text,
    onFieldSubmitted: onSubmitted,
    cursorHeight: 20.h,
    style: AppTextStyle.regular20(
      color: isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
    ),
    decoration: InputDecoration(
      contentPadding: EdgeInsets.only(left: 15.w, right: 15.w),
      suffixIcon: suffixWidget,
      prefixIcon: prefixWidget,
      hintText: hintText,
      filled: true,
      fillColor: isDarkMode() ? AppColors.black1E1E1E : AppColors.transparent,
      hintStyle: AppTextStyle.regular20(
        color: isDarkMode() ? AppColors.blackB3B3B3 : AppColors.grey9B9B9B,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(
          color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(
          color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: BorderSide(color: AppColors.primaryPurple),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: errorBorderSide ?? BorderSide.none,
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.r),
        borderSide: focusedErrorBorderSide ?? BorderSide.none,
      ),
    ),
  );
}
