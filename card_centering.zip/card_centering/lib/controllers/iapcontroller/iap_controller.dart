import 'package:card_centering/model/iap_model.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../apptheme/app_strings.dart';

class IapController extends GetxController {
  List<IapModel> iapPlanList = [
    IapModel(
      planName: 'Basic Plan',
      planDesc: '20 scans/mo. Great for casual \ncollectors.',
      planPrice: '4',
      planId: monthlyBaseKey,
    ),
    IapModel(
      planName: 'Pro Plan',
      planDesc: '100 scans/mo. Best for regular \ngrading.',
      planPrice: '10',
      planId: monthlyProKey,
    ),
    IapModel(
      planName: 'Elite Plan',
      planDesc: '250 scans/mo. Built for power \nusers.',
      planPrice: '15',
      planId: monthlyEliteKey,
    ),
  ];

  PrefManager prefmanage = PrefManager();
  bool _isSubscribed = false;
  bool get isSubscribed => _isSubscribed;

  String selectedPlanName = "Pro Plan";
  String selectedPlanPrice = "10";

  onPlanSelect({required IapModel planData}) {
    selectedPlanName = planData.planName;
    selectedPlanPrice = planData.planPrice;
    update();
  }

  getIAPStatus() async {
    _isSubscribed = await PrefManager().getBoolData(key: iapStatusKey);
    debugPrint("isSubscribed ====== $_isSubscribed");
    update();
  }
}
