import 'dart:async';
import 'dart:convert';
import 'dart:developer' as dev;
import 'dart:io';
import 'dart:isolate';
import 'package:card_centering/adhelper/ad_service.dart';
import 'package:card_centering/apiservice/api_service.dart';
import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/dashboardcontrollers/dashboard_controller.dart';
import 'package:card_centering/model/cardmodel/create_card_model.dart';
import 'package:card_centering/model/collectionmodel/collection_list_model.dart';
import 'package:card_centering/model/response_model.dart';
import 'package:card_centering/pages/dashboard/pages/scan_card_details.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:cunning_document_scanner/cunning_document_scanner.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:logic_go_network/network.dart';
import '../../apptheme/app_constants.dart';
import '../../model/card_grading_model.dart';
import '../../model/card_info_model.dart';
import '../../model/cardmodel/fav_card_list_model.dart';
import '../../model/cardmodel/fav_card_model.dart';
import '../../model/search_card_model.dart';
import '../../pages/dashboard/pages/grade_calculate.dart';
import 'package:dio/dio.dart' as dio;

void createCardInIsolate(Map<String, dynamic> message) async {
  SendPort mainSendPort = message['sendPort'];
  RootIsolateToken isoToken = message['token'];

  // ✅ Needed to use Flutter plugins in isolate
  BackgroundIsolateBinaryMessenger.ensureInitialized(isoToken);

  ReceivePort isolateReceivePort = ReceivePort();
  mainSendPort.send(isolateReceivePort.sendPort); // Send back isolate's port

  isolateReceivePort.listen((message) async {
    if (message is Map<String, dynamic>) {
      try {
        // Setup restClient if needed
        restClient = RestClient(
          baseUrl: baseUrl,
          token: token,
          connectionTO: 30000,
          receiveTO: 30000,
        );

        // ✅ Call the actual API
        ResponseModel response = await ApiService.createNewCardApi(
          body: message['body'],
          sendPort: mainSendPort,
        );

        mainSendPort.send({'status': true, 'data': response});
      } catch (e) {
        mainSendPort.send({'status': false, 'error': e.toString()});
      }
    }
  });
}

void cardGradingInIsolate(Map<String, dynamic> message) async {
  SendPort mainSendPort = message['sendPort'];
  RootIsolateToken isoToken = message['token'];
  String base64Image = message['base64Image'];

  // ✅ Needed to use Flutter plugins in isolate
  BackgroundIsolateBinaryMessenger.ensureInitialized(isoToken);

  ReceivePort isolateReceivePort = ReceivePort();
  mainSendPort.send(isolateReceivePort.sendPort); // Send back isolate's port

  isolateReceivePort.listen((message) async {
    if (message is Map<String, dynamic>) {
      try {
        // Setup restClient if needed
        restClient = RestClient(
          baseUrl: baseUrl,
          token: token,
          connectionTO: 30000,
          receiveTO: 30000,
        );

        // ✅ Call the actual API
        // ResponseModel response = await ApiService.createNewCardApi(
        //   body: message['body'],
        //   sendPort: mainSendPort,
        // );
        final response = await http.post(
          Uri.parse(gradingUrl),
          headers: <String, String>{
            'Content-Type': 'application/json',
            "Authorization": "Token $apiKey",
          },
          body: json.encode({
            "records": [
              {"_base64": base64Image},
            ],
          }),
        );

        Map<String, dynamic> responseData = json.decode(response.body);
        mainSendPort.send({'status': true, 'data': responseData});
      } catch (e) {
        mainSendPort.send({'status': false, 'error': e.toString()});
      }
    }
  });
}
//
// void createCardInIsolate(SendPort mainSendPort) async {
//   ReceivePort isolateReceivePort = ReceivePort();
//   mainSendPort.send(isolateReceivePort.sendPort); // Send the new port back
//
//   isolateReceivePort.listen((message) async {
//     restClient = RestClient(
//       baseUrl: baseUrl,
//       token: token,
//       connectionTO: 30000,
//       receiveTO: 30000,
//     );
//     if (message is Map<String, dynamic>) {
//
//       try {
//         ResponseModel response = await ApiService.createNewCardApi(
//           body: message['body'],
//           sendPort: mainSendPort,
//         );
//
//         mainSendPort.send({'status': true, 'data': response});
//       } catch (e) {
//         mainSendPort.send({'status': false, 'error': e.toString()});
//       }
//     }
//   });
// }

class HomeController extends GetxController {
  final searchController = TextEditingController();
  RxBool isShowClosed = false.obs;

  String selectedCard = '';
  String selectedCardId = '';

  bool isFieldEmpty = true;

  SearchCardModel? searchCardData;
  CardInfoModel? cardInfoData;

  RxBool isFront = false.obs;
  RxBool isBack = false.obs;

  List<String> images = [];

  File? frontImage;
  File? backImage;
  String? frontBase64Image;
  String? backBase64Image;
  bool isLocalImage = false;

  CardGradingModel? cardGradingData;
  CardGradingModel? backCardGradingData;

  RxBool isShowLoader = false.obs;
  RxBool isPriceLoader = false.obs;
  RxBool isSearchLoader = false.obs;

  RxInt userAttempts = 0.obs;

  // Inner boundaries
  double left = 22, right = 22, top = 22, bottom = 22;

  // Outer boundaries
  double outerLeft = 10, outerRight = 10, outerTop = 10, outerBottom = 10;

  final double maxValue = 100.0;
  final double minValue = 0.0;
  String horizontalCentering = '';
  String verticalCentering = '';
  String grading = "";

  double centeringScore = 0.0;
  final double gap = 0;

  double lrRatio = 0.0;
  double tbRatio = 0.0;
  double outerLrRatio = 0.0;
  double outerTbRatio = 0.0;
  double gapLeft = 0.0;
  double gapRight = 0.0;
  double gapTop = 0.0;
  double gapBottom = 0.0;

  setImageStatus(bool value) {
    isLocalImage = value;
    update();
  }

  setLoader(bool value) {
    isShowLoader.value = value;
  }

  onFrontChange(bool isFrontSide) {
    isFront.value = isFrontSide;
    isBack.value = false;
  }

  onBackChange(bool isBackSide) {
    isBack.value = isBackSide;
    isFront.value = false;
  }

  // pickImage({required ImageSource source, required bool isFront}) async {
  //   final ImagePicker imagePicker = ImagePicker();
  //   final XFile? pickedFile = await imagePicker.pickImage(source: source);
  //   if (pickedFile != null) {
  //     if (isFront) {
  //       frontImage = File(pickedFile.path);
  //       frontBase64Image = await convertImageToBase64(frontImage!);
  //       if (frontBase64Image != null) {
  //         setImageStatus(true);
  //         onFrontChange(true);
  //         await cardGradingApi(frontBase64Image ?? '', true);
  //       }
  //     } else {
  //       backImage = File(pickedFile.path);
  //       backBase64Image = await convertImageToBase64(backImage!);
  //       if (backBase64Image != null) {
  //         setImageStatus(true);
  //         onBackChange(true);
  //
  //         await cardGradingApi(backBase64Image ?? '', false);
  //       }
  //     }
  //
  //     update();
  //   }
  // }

  String filePath = '';

  Future<void> getImageFromCamera(bool isFront) async {
    try {
      final pictures = await CunningDocumentScanner.getPictures(noOfPages: 1);

      debugPrint("Data ==== $pictures");
      if (pictures == null || pictures.isEmpty) {
        return;
      }

      images = pictures;
      update();

      if (images.isNotEmpty) {
        if (isFront) {
          frontImage = File(images[0]);
          frontBase64Image = await convertImageToBase64(frontImage!);
          if (frontBase64Image != null) {
            setImageStatus(true);
            onFrontChange(true);
            Get.find<DashboardController>().setScanStatus(true);
            Get.find<DashboardController>().currentIndex = 0;
            Get.find<DashboardController>().update();
            // Get.to(
            //       () => ScanCardDetails(),
            //   transition: Transition.rightToLeftWithFade,
            // );
            // isApiCompleted.value = true;

            await cardGradingApi(frontBase64Image ?? '', true);
            AdService.showInterstitialAd(
              afterAd: () {},
              adLabel: scanIntertitalAd,
            );
          }
        } else {
          backImage = File(images[0]);
          backBase64Image = await convertImageToBase64(backImage!);
          if (backBase64Image != null) {
            setImageStatus(true);
            onBackChange(true);
            Get.find<DashboardController>().setScanStatus(true);
            Get.find<DashboardController>().currentIndex = 0;
            Get.find<DashboardController>().update();

            // Get.off(
            //         () => ScanCardDetails()
            // );
            // isApiCompleted.value = true;
            // userAttempts.value++;
            // prefManager.setIntData(key: userScanAttempt, value: userAttempts.value);
            // getUserScanAttempt();
            await cardGradingApi(backBase64Image ?? '', false);
          }
        }
        update();
      }
    } catch (e, stack) {
      debugPrint("Stack Trace: $stack");
    }
  }

  Future<String> convertImageToBase64(File imageFile) async {
    List<int> imageBytes = await imageFile.readAsBytes();
    return base64Encode(imageBytes);
  }

  // Card Grading API Calling
  // Future<String> cardGradingApi(String base64Image, bool isFront) async {
  //   setLoader(true);
  //   final response = await http.post(
  //     Uri.parse(gradingUrl),
  //     headers: <String, String>{
  //       'Content-Type': 'application/json',
  //       "Authorization": "Token $apiKey",
  //     },
  //     body: json.encode({
  //       "records": [
  //         {"_base64": base64Image},
  //       ],
  //     }),
  //   );
  //
  //   // dev.log("Card Grading Response === ${response.body}");
  //   if (response.statusCode == 200 || response.statusCode == 201) {
  //     debugPrint("Card Grading API called successfully");
  //     if (isFront == true) {
  //       cardGradingData = cardGradingModelFromJson(response.body);
  //       if (cardGradingData != null) {
  //         // await createNewCardApi();
  //         await startCreateCardProcessInIsolate();
  //       }
  //     } else {
  //       backCardGradingData = cardGradingModelFromJson(response.body);
  //       if (backCardGradingData != null) {
  //         // await createNewCardApi();
  //         await startCreateCardProcessInIsolate();
  //       }
  //     }
  //
  //     userAttempts.value++;
  //
  //     return response.body;
  //   } else {
  //     setLoader(false);
  //
  //     debugPrint(
  //       "Card Grading API call failed with status code: ${response.statusCode}",
  //     );
  //     return '';
  //   }
  // }

  RxInt percentage = 0.obs;
  RxBool isApiCompleted = false.obs;

  Future<void> cardGradingApi(String base64Image, bool isFront) async {
    try {
      setLoader(true);
      percentage.value = 0;
      isApiCompleted.value = false;

      // Simulate progress manually before/after isolate call
      _startProgress();
      ReceivePort mainReceivePort = ReceivePort();

      // ✅ Get the root isolate token
      final RootIsolateToken rootToken = RootIsolateToken.instance!;

      // ✅ Create a message map with token and port
      final Map<String, dynamic> isolateParams = {
        'sendPort': mainReceivePort.sendPort,
        'token': rootToken,
        'base64Image': base64Image,
      };

      // ✅ Start the isolate
      await Isolate.spawn(cardGradingInIsolate, isolateParams);

      SendPort? isolateSendPort;

      // ✅ Listen for messages from the isolate
      mainReceivePort.listen((message) async {
        if (message is SendPort) {
          isolateSendPort = message;

          // Build the request body on the main thread
          final requestBody = {"body": await createCardRequestBody()};

          isolateSendPort?.send(requestBody);
        } else if (message is Map<String, dynamic>) {
          debugPrint("Card Grading API called successfully");

          if (isFront == true) {
            cardGradingData = cardGradingModelFromJson(
              jsonEncode(message['data']),
            );
            if (cardGradingData != null) {
              // await createNewCardApi();
              await startCreateCardProcessInIsolate();
            }
          } else {
            backCardGradingData = cardGradingModelFromJson(
              jsonEncode(message['data']),
            );
            if (backCardGradingData != null) {
              // await createNewCardApi();
              // await startCreateCardProcessInIsolate();
              await updateCardApi(isBackScan: true);
            }
          }
        }
      });
    } catch (e) {
      isApiCompleted.value = false;
      setLoader(false);
      debugPrint(e.toString());
    }
  }

  void _startProgress() async {
    while (percentage.value < 90 && !isApiCompleted.value) {
      await Future.delayed(Duration(milliseconds: 150));
      percentage.value++;
    }

    // When task is done, animate the rest to 100%
    if (isApiCompleted.value == true) {
      while (percentage.value < 100) {
        await Future.delayed(Duration(milliseconds: 150));
        percentage.value++;
      }
    }
  }

  //Create New Card API
  CreateCardData? createCardData;

  Future<void> createNewCardApi() async {
    ReceivePort receivePort = ReceivePort();
    final priceDetails = {
      "name": selectedCard,
      "ungraded_price": cardInfoData?.loosePrice?.formatPrice() ?? '',
      "grade7_price": cardInfoData?.cibPrice?.formatPrice() ?? '',
      "grade8_price": cardInfoData?.newPrice?.formatPrice() ?? '',
      "grade9_price": cardInfoData?.gradedPrice?.formatPrice() ?? '',
      "grade9.5_price": cardInfoData?.boxOnlyPrice?.formatPrice() ?? '',
      "psa10_price": cardInfoData?.manualOnlyPrice?.formatPrice() ?? '',
    };
    final backDetails = {
      "left_right":
          backCardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          backCardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          backCardGradingData?.records?.first.grades?.centering.toString() ??
          '',
      "ai_Grade":
          "${backCardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${backCardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.side
              ?.first
              .name ??
          '',
      "category":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };
    final frontDetails = {
      "left_right":
          cardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          cardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          cardGradingData?.records?.first.grades?.centering.toString() ?? '',
      "ai_Grade":
          "${cardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${cardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          cardGradingData?.records?.first.card?.first.tags?.side?.first.name ??
          '',
      "category":
          cardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };
    final createCardRequestBody = {
      "frontImageFile":
          frontImage != null
              ? await dio.MultipartFile.fromFile(frontImage!.path)
              : '',
      "backImageFile":
          backImage != null
              ? await dio.MultipartFile.fromFile(backImage!.path)
              : '',
      "frontDetails": jsonEncode(frontDetails),
      "backDetails": jsonEncode(backDetails),
      "priceCheckerDetails": jsonEncode(priceDetails),
    };
    dev.log("Create Card API Body === $createCardRequestBody");
    try {
      ResponseModel response = await ApiService.createNewCardApi(
        body: createCardRequestBody,
        sendPort: receivePort.sendPort,
      );

      dev.log("Create Card API Response === ${response.toJson()}");

      if (response.status == true) {
        setLoader(false);
        showToast(message: response.message);
        createCardData = CreateCardData.fromJson(response.body);
      } else {
        setLoader(false);
        showToast(message: response.message);
      }
    } catch (error) {
      debugPrint('Create Card Cache Error ${error.toString()}');
      setLoader(false);
      String errorMessage = getCatchFinalErrorMsg(error);
      showToast(message: errorMessage);
    }
  }

  // ================ Isolates Demo API =================== //

  // Future<void> startCreateCardProcessInIsolate() async {
  //   ReceivePort mainReceivePort = ReceivePort();
  //
  //   await Isolate.spawn(createCardInIsolate, mainReceivePort.sendPort);
  //
  //   SendPort? isolateSendPort;
  //
  //   mainReceivePort.listen((message) async {
  //     if (message is SendPort) {
  //       // Save the isolate's send port to communicate later
  //       isolateSendPort = message;
  //
  //       // Prepare request body like in your `createNewCardApi` method
  //       final requestBody = {
  //         "body": await createCardRequestBody(), // <- Your existing logic
  //       };
  //
  //       isolateSendPort?.send(requestBody);
  //     } else if (message is Map) {
  //       if (message['status'] == true) {
  //         ResponseModel response = message['data'];
  //         dev.log("Isolate Success: ${response.toJson()}");
  //         setLoader(false);
  //         showToast(message: response.message);
  //       } else {
  //         dev.log("Isolate Error: ${message['error']}");
  //         setLoader(false);
  //         showToast(message: "Error: ${message['error']}");
  //       }
  //     }
  //   });
  // }

  Future<void> startCreateCardProcessInIsolate() async {
    ReceivePort mainReceivePort = ReceivePort();

    // ✅ Get the root isolate token
    final RootIsolateToken rootToken = RootIsolateToken.instance!;

    // ✅ Create a message map with token and port
    final Map<String, dynamic> isolateParams = {
      'sendPort': mainReceivePort.sendPort,
      'token': rootToken,
    };

    // ✅ Start the isolate
    await Isolate.spawn(createCardInIsolate, isolateParams);

    SendPort? isolateSendPort;

    // ✅ Listen for messages from the isolate
    mainReceivePort.listen((message) async {
      if (message is SendPort) {
        isolateSendPort = message;

        // Build the request body on the main thread
        final requestBody = {"body": await createCardRequestBody()};

        isolateSendPort?.send(requestBody);
      } else if (message is Map<String, dynamic>) {
        if (message['status'] == true) {
          while (percentage.value < 100) {
            await Future.delayed(Duration(milliseconds: 50));
            percentage.value++;
          }
          ResponseModel response = ResponseModel.fromJson(message);
          if (response.body != null) {
            createCardData = CreateCardData.fromJson(response.body);
          }
          dev.log("Isolate Success: ${response.toJson()}");
          setLoader(false);
          if (response.message.isNotEmpty) {
            showToast(message: response.message);
          }

          isApiCompleted.value = true;
        } else {
          setLoader(false);
          isApiCompleted.value = true;

          dev.log("Isolate Error: ${message['error']}");
          showToast(message: "Error: ${message['error']}");
        }
      }
    });
  }

  Future<Map<String, dynamic>> createCardRequestBody() async {
    final priceDetails = {
      "name": selectedCard,
      "ungraded_price": cardInfoData?.loosePrice?.formatPrice() ?? '',
      "grade7_price": cardInfoData?.cibPrice?.formatPrice() ?? '',
      "grade8_price": cardInfoData?.newPrice?.formatPrice() ?? '',
      "grade9_price": cardInfoData?.gradedPrice?.formatPrice() ?? '',
      "grade9.5_price": cardInfoData?.boxOnlyPrice?.formatPrice() ?? '',
      "psa10_price": cardInfoData?.manualOnlyPrice?.formatPrice() ?? '',
    };

    final backDetails = {
      "left_right":
          backCardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          backCardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          backCardGradingData?.records?.first.grades?.centering.toString() ??
          '',
      "ai_Grade":
          "${backCardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${backCardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.side
              ?.first
              .name ??
          '',
      "category":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };
    final frontDetails = {
      "left_right":
          cardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          cardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          cardGradingData?.records?.first.grades?.centering.toString() ?? '',
      "ai_Grade":
          "${cardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${cardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          cardGradingData?.records?.first.card?.first.tags?.side?.first.name ??
          '',
      "category":
          cardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };

    return {
      "frontImageFile":
          frontImage != null
              ? await dio.MultipartFile.fromFile(frontImage!.path)
              : '',
      "backImageFile":
          backImage != null
              ? await dio.MultipartFile.fromFile(backImage!.path)
              : '',
      "frontDetails": jsonEncode(frontDetails),
      "backDetails": jsonEncode(backDetails),
      "priceCheckerDetails": jsonEncode(priceDetails),
    };
  }

  //Update Card API
  Future<void> updateCardApi({bool? isBackScan}) async {
    final priceDetails = {
      "name": selectedCard,
      "ungraded_price": cardInfoData?.loosePrice?.formatPrice() ?? '',
      "grade7_price": cardInfoData?.cibPrice?.formatPrice() ?? '',
      "grade8_price": cardInfoData?.newPrice?.formatPrice() ?? '',
      "grade9_price": cardInfoData?.gradedPrice?.formatPrice() ?? '',
      "grade9.5_price": cardInfoData?.boxOnlyPrice?.formatPrice() ?? '',
      "psa10_price": cardInfoData?.manualOnlyPrice?.formatPrice() ?? '',
    };
    final backDetails = {
      "left_right":
          backCardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          backCardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          backCardGradingData?.records?.first.grades?.centering.toString() ??
          '',
      "ai_Grade":
          "${backCardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${backCardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.side
              ?.first
              .name ??
          '',
      "category":
          backCardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };
    final frontDetails = {
      "left_right":
          cardGradingData?.records?.first.card?.first.centering?.leftRight
              .toString() ??
          '',
      "bottom_top":
          cardGradingData?.records?.first.card?.first.centering?.topBottom
              .toString() ??
          '',
      "centering":
          cardGradingData?.records?.first.grades?.centering.toString() ?? '',
      "ai_Grade":
          "${cardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${cardGradingData?.records?.first.grades?.condition ?? ''}",
      "card_side":
          cardGradingData?.records?.first.card?.first.tags?.side?.first.name ??
          '',
      "category":
          cardGradingData
              ?.records
              ?.first
              .card
              ?.first
              .tags
              ?.category
              ?.first
              .name ??
          '',
    };
    final updateCardRequestBody = {
      "frontImageFile":
          frontImage != null
              ? await dio.MultipartFile.fromFile(frontImage!.path)
              : '',
      "backImageFile":
          backImage != null
              ? await dio.MultipartFile.fromFile(backImage!.path)
              : '',
      "frontDetails": jsonEncode(frontDetails),
      "backDetails": jsonEncode(backDetails),
      "priceCheckerDetails": jsonEncode(priceDetails),
    };
    dev.log("Update Card API Body === $updateCardRequestBody");
    try {
      ResponseModel response = await ApiService.updateCardApi(
        body: updateCardRequestBody,
        cardId: createCardData?.id ?? '',
      );

      dev.log("Update Card API Response === ${response.toJson()}");

      if (response.status == true) {
        setLoader(false);
        while (percentage.value < 100) {
          await Future.delayed(Duration(milliseconds: 20));
          percentage.value++;
        }
        showToast(message: response.message);
        if (isBackScan == true) {
          userAttempts.value++;
        }

        prefManager.setIntData(key: userScanAttempt, value: userAttempts.value);
        getUserScanAttempt();

        isApiCompleted.value = true;
      } else {
        setLoader(false);
        isApiCompleted.value = true;

        showToast(message: response.message);
      }
    } catch (error) {
      isApiCompleted.value = true;

      debugPrint('Update Card Cache Error ${error.toString()}');
      setLoader(false);
      String errorMessage = getCatchFinalErrorMsg(error);
      showToast(message: errorMessage);
    }
  }

  // Favorite Card Api
  FavCardData? favCardData;
  RxBool isFavLoader = false.obs;

  Future<void> favoriteCardApi({String? cardId}) async {
    isFavLoader.value = true;
    try {
      ResponseModel response = await ApiService.favoriteToggleCardApi(
        cardId: cardId ?? createCardData?.id ?? '',
      );
      // debugPrint("Favorite Card Response: ${response.body}");
      if (response.status == true && response.body != null) {
        // debugPrint("Favorite Card Response: ${response.body}");
        favCardData = FavCardData.fromJson(response.body);
        update();
        if (cardId != null) {
          await favoriteCardListApi(cardID: cardId);
        }
        isFavLoader.value = false;
      } else {
        isFavLoader.value = false;
        debugPrint("Favorite Card Error: ${response.message}");
      }
    } catch (e) {
      isFavLoader.value = false;
      debugPrint("Catch Error: $e");
    }
  }

  // Favorite Card List Api
  List<FavCardList> favCardList = [];

  Future<void> favoriteCardListApi({String? cardID}) async {
    isFavLoader.value = true;

    try {
      ResponseModel response = await ApiService.favoriteCardListApi();
      // debugPrint("Favorite Card List Response: ${response.body}");

      if (response.status == true && response.body is List) {
        try {
          final List<Map<String, dynamic>> favList =
              List<Map<String, dynamic>>.from(response.body);

          favCardList = favList.map((e) => FavCardList.fromJson(e)).toList();

          // debugPrint(
          //   "Favorite Card List: ${favCardList.map((e) => e.toJson())}",
          // );
          update();
          isFavLoader.value = false;
        } catch (e) {
          debugPrint("Parsing Error: $e");
          isFavLoader.value = false;
        }
      } else {
        debugPrint("Favorite Card Error: ${response.message}");
        isFavLoader.value = false;
      }
    } catch (e) {
      isFavLoader.value = false;

      debugPrint("Catch Error: $e");
    } finally {
      isFavLoader.value = false;
    }
  }

  // Delete Card Api

  RxBool isDeleteLoader = false.obs;

  Future<void> deleteCardApi() async {
    isDeleteLoader.value = true;
    try {
      ResponseModel response = await ApiService.deleteCardApi(
        cardId: createCardData?.id ?? '',
      );
      debugPrint("Delete Card Response: ${response.body}");
      if (response.status == true) {
        isDeleteLoader.value = false;
        showToast(message: response.message);
        favCardData = null;
        update();
        // Get.back();
        // Get.back();
        Get.find<DashboardController>().setScanStatus(false);
        onFrontChange(false);
        onBackChange(false);
      } else {
        isDeleteLoader.value = false;
        debugPrint("Delete Card Error: ${response.message}");
        showToast(message: response.message);
      }
    } catch (e) {
      isDeleteLoader.value = false;
      showToast(message: someThingWentWrong.tr);
      debugPrint("Catch Error: $e");
    }
  }

  //Card Price Info API
  Future<void> cardInfoApi() async {
    isPriceLoader.value = true;
    try {
      final response = await http.get(Uri.parse(priceUrl(selectedCardId)));
      debugPrint("Info Card URL: ${priceUrl(searchController.text)}");
      if (response.statusCode == 200 || response.statusCode == 201) {
        isPriceLoader.value = false;
        cardInfoData = cardInfoModelFromJson(response.body);
        if (cardInfoData != null) {
          await updateCardApi();
        }
        debugPrint("Info Card Response: ${cardInfoData?.toJson()}");
        update();
      } else {
        isPriceLoader.value = false;
        debugPrint("Error: ${response.statusCode}");
      }
    } catch (e) {
      isPriceLoader.value = false;
      debugPrint("Catch Error: $e");
    } finally {
      isPriceLoader.value = false;
    }
  }

  double calculateCentering() {
    double horizontalRatio = left / (left + right);
    double verticalRatio = top / (top + bottom);
    return ((horizontalRatio + verticalRatio) / 2) * 100;
  }

  void adjustInnerBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        left = (left + delta).clamp(minValue, maxValue);
        if (outerLeft + gap > left) {
          outerLeft = left - gap;
        }
        break;
      case "right":
        right = (right - delta).clamp(minValue, maxValue);
        if (outerRight + gap > right) {
          outerRight = right - gap;
        }
        break;
      case "top":
        top = (top + delta).clamp(minValue, maxValue);
        if (outerTop + gap > top) {
          outerTop = top - gap;
        }
        break;
      case "bottom":
        bottom = (bottom - delta).clamp(minValue, maxValue);
        if (outerBottom + gap > bottom) {
          outerBottom = bottom - gap;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: left,
      innerRight: right,
      innerTop: top,
      innerBottom: bottom,
      outerLeft: outerLeft,
      outerRight: outerRight,
      outerTop: outerTop,
      outerBottom: outerBottom,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCentering = result['horizontalCentering'];
    verticalCentering = result['verticalCentering'];
    grading = result['grading'];
    realTimeBorderChange();
    centeringScore = calculateCentering();
    update();
  }

  void adjustOuterBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        outerLeft = (outerLeft + delta).clamp(minValue, maxValue);
        if (outerLeft + gap > left) {
          left = outerLeft + gap;
        }
        break;
      case "right":
        outerRight = (outerRight - delta).clamp(minValue, maxValue);
        if (outerRight + gap > right) {
          right = outerRight + gap;
        }
        break;
      case "top":
        outerTop = (outerTop + delta).clamp(minValue, maxValue);
        if (outerTop + gap > top) {
          top = outerTop + gap;
        }
        break;
      case "bottom":
        outerBottom = (outerBottom - delta).clamp(minValue, maxValue);
        if (outerBottom + gap > bottom) {
          bottom = outerBottom + gap;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: left,
      innerRight: right,
      innerTop: top,
      innerBottom: bottom,
      outerLeft: outerLeft,
      outerRight: outerRight,
      outerTop: outerTop,
      outerBottom: outerBottom,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCentering = result['horizontalCentering'];
    verticalCentering = result['verticalCentering'];
    grading = result['grading'];

    realTimeBorderChange();
    centeringScore = calculateCentering();

    update();
  }

  realTimeBorderChange() {
    lrRatio = left / (left + right);
    tbRatio = top / (top + bottom);

    outerLrRatio = outerLeft / (outerLeft + outerRight);
    outerTbRatio = outerTop / (outerTop + outerBottom);

    gapLeft = (left - outerLeft).clamp(0, double.infinity);
    gapRight = (right - outerRight).clamp(0, double.infinity);
    gapTop = (top - outerTop).clamp(0, double.infinity);
    gapBottom = (bottom - outerBottom).clamp(0, double.infinity);
  }

  // Search Card
  Future<void> searchCard() async {
    isSearchLoader.value = true;
    try {
      final response = await http.get(
        Uri.parse(searchUrl(searchController.text)),
      );
      debugPrint("Search Card URL: ${searchUrl(searchController.text)}");
      if (response.statusCode == 200 || response.statusCode == 201) {
        isSearchLoader.value = false;

        debugPrint("Search Card Response: ${response.body}");
        searchCardData = searchCardModelFromJson(response.body);
        update();
      } else {
        isSearchLoader.value = false;

        debugPrint("Error: ${response.statusCode}");
      }
    } catch (e) {
      isSearchLoader.value = false;

      debugPrint("Catch Error: $e");
    } finally {
      isSearchLoader.value = false;
    }
  }

  onCardSelect({required String value, required String cardID}) {
    selectedCard = value;
    selectedCardId = cardID;
    update();
  }

  getUserScanAttempt() async {
    userAttempts.value = await prefManager.getIntData(key: userScanAttempt);
    debugPrint("User Scan Attempts: ${userAttempts.value}");
  }

  @override
  void onInit() {
    searchController.addListener(() {
      if (searchController.text.isEmpty) {
        isShowClosed.value = false;
      } else {
        isShowClosed.value = true;
      }
    });

    getUserScanAttempt();
    AdService.loadInterstitialAds(scanIntertitalAd);
    AdService.loadInterstitialAds(addToCollectionIntertitalAd);
    super.onInit();
  }

  RxBool isAddCollectionLoader = false.obs;
  TextEditingController collectionNameController = TextEditingController();
  List<CollectionListData> collectionList = [];
  String? selectedCollectionID;
  int? selectedCollectionItems;

  //Fetch Collection List API
  Future<void> fetchCollectionList() async {
    isAddCollectionLoader.value = true;
    update();
    try {
      ResponseModel response = await ApiService.collectionListApi();

      if (response.status == true && response.body is List) {
        try {
          final List<Map<String, dynamic>> collectionListList =
              List<Map<String, dynamic>>.from(response.body);

          collectionList =
              collectionListList
                  .map((e) => CollectionListData.fromJson(e))
                  .toList();
          update();
          isAddCollectionLoader.value = false;
        } catch (e) {
          debugPrint("Collection List Parsing Error: $e");
          isAddCollectionLoader.value = false;
        }
      } else {
        debugPrint("Collection List Error: ${response.message}");
        isAddCollectionLoader.value = false;
      }
    } catch (e) {
      isAddCollectionLoader.value = false;

      debugPrint("Collection List Catch Error: $e");
    } finally {
      isAddCollectionLoader.value = false;
    }
  }

  //Create Collection API
  Future<void> createCollectionApi(BuildContext context) async {
    isAddCollectionLoader.value = true;
    try {
      ResponseModel response = await ApiService.createCollectionApi(
        collectionName: collectionNameController.text,
      );
      debugPrint("Create Collection Response: ${response.body}");

      if (response.status == true) {
        isAddCollectionLoader.value = false;
        showToast(message: response.message);
        await fetchCollectionList();
        collectionNameController.clear();
        if (context.mounted) {
          showDialog(
            context: context,
            builder: (context) {
              return collectionListDialog(context);
            },
          );
        }

        update();
      } else {
        debugPrint("Collection List Error: ${response.message}");
        isAddCollectionLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      isAddCollectionLoader.value = false;
      showToast(message: e.toString());
      debugPrint("Collection List Catch Error: $e");
    } finally {
      isAddCollectionLoader.value = false;
    }
  }

  onTapAddToCollection(BuildContext context) async {
    selectedCollectionID = null;
    selectedCollectionItems = null;
    isAddCollectionLoader.value = true;
    try {
      await fetchCollectionList();
      isAddCollectionLoader.value = false;
      if (collectionList.isEmpty) {
        if (context.mounted) {
          showDialog(
            context: context,
            builder: (context) {
              return addCollectionDialog(context);
            },
          );
        }
      } else {
        if (context.mounted) {
          showDialog(
            context: context,
            builder: (context) {
              return collectionListDialog(context);
            },
          );
        }
      }
    } catch (e) {
      isAddCollectionLoader.value = false;
      dev.log('ON TAP ADD TO COLLECTION :: ERROR :: $e');
    }
  }

  Future<void> onTapContinue() async {
    if (selectedCollectionID == null) {
      return showToast(message: selectCollection.tr);
    } else {
      await saveCardInCollectionApi(
        cardID: createCardData?.id ?? '',
        collectionID: selectedCollectionID ?? '',
      );
    }
  }

  Future<void> saveCardInCollectionApi({
    required String cardID,
    required String collectionID,
  }) async {
    Get.back();
    isAddCollectionLoader.value = true;
    try {
      Map<String, dynamic> data = {
        "cardId": cardID,
        "collectionId": collectionID,
      };
      ResponseModel response = await ApiService.saveCardToCollection(
        data: data,
      );
      dev.log('${response.toJson()}');
      showToast(message: response.message);
      isAddCollectionLoader.value = false;
    } catch (e) {
      isAddCollectionLoader.value = false;
    }
  }
}
