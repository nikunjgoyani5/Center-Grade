import 'package:card_centering/apiservice/api_service.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/profilecontroller/profile_controller.dart';
import 'package:card_centering/model/supportmodel/get_support_model.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart';
import '../../model/response_model.dart';
import '../../pages/authscreens/auth_screen.dart';
import '../../widgets/common_widgets.dart';

class SettingController extends GetxController {
  final oldPassController = TextEditingController();
  final newPassController = TextEditingController();
  final confirmNewPassController = TextEditingController();

  RxBool isSwitched = false.obs;

  RxBool isShowLoader = false.obs;

  String userProfileImage = '';
  String userEmailId = '';
  String userFullName = '';

  bool isLightMode = false;

  // List<String> languageList = [english.tr, chinese.tr, japanese.tr,spanish.tr];

  List<Map<String, dynamic>> languageList = [
    {'name': english.tr, 'countryCode': 'US', 'languageCode': 'en'},
    {'name': chinese.tr, 'countryCode': 'CN', 'languageCode': 'zh'},
    {'name': japanese.tr, 'countryCode': 'JP', 'languageCode': 'ja'},

    {'name': spanish.tr, 'countryCode': 'ES', 'languageCode': 'es'},
  ];

  RxString selectedLanguage = english.tr.obs;

  setLoader(bool value) => isShowLoader.value = value;

  bool isOldPasswordVisible = false;
  bool isNewPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  oldPasswordVisibility() {
    isOldPasswordVisible = !isOldPasswordVisible;
    update();
  }

  newPasswordVisibility() {
    isNewPasswordVisible = !isNewPasswordVisible;
    update();
  }

  confirmPasswordVisibility() {
    isConfirmPasswordVisible = !isConfirmPasswordVisible;
    update();
  }

  onSwitchChange(bool value) {
    isSwitched.value = value;
  }

  onLanguageSelect({required Map<String, dynamic> value}) async {
    selectedLanguage.value = value['name'];

    Get.updateLocale(Locale(value['languageCode'], value['countryCode']));
    await PrefManager().setStringData(
      key: languageCode,
      value: value['languageCode'],
    );
    await PrefManager().setStringData(
      key: contCode,
      value: value['countryCode'],
    );
    await PrefManager().setStringData(key: myLanguage, value: value['name']);
    update();
    Get.back();
  }

  onModeChange() {
    if (Get.isDarkMode) {
      Get.changeThemeMode(ThemeMode.light);
    } else {
      Get.changeThemeMode(ThemeMode.dark);
    }
    update();
  }

  setThemeMode({required bool value}) {
    PrefManager().setBoolData(key: isLightModeKey, value: value);
  }

  getThemeMode() async {
    isLightMode = await PrefManager().getBoolData(key: isLightModeKey);
    update();
    debugPrint("isLightMode ==== $isLightMode");
  }

  getUserData() async {
    userProfileImage = Get.find<ProfileController>().userProfileImage;
    userEmailId = Get.find<ProfileController>().userEmailId;
    userFullName = Get.find<ProfileController>().userFullName;

    // debugPrint(
    //   'User Data === $userProfileImage === $userEmailId === $userFullName',
    // );
    update();
  }

  //Change Password API
  Future<void> changePasswordApi() async {
    setLoader(true);
    try {
      ResponseModel response = await ApiService.changePasswordApi(
        body: {
          "oldPassword": oldPassController.text,
          "newPassword": newPassController.text,
          "conformNewPassword": confirmNewPassController.text,
        },
      );

      debugPrint("Change Password Response == ${response.body}");

      if (response.status == true) {
        setLoader(false);
        showToast(message: response.message);
        // PrefManager().setBoolData(key: isLoginKey, value: false);
        // await PrefManager().clearPref();
        // await prefManager.setBoolData(key: isLoginKey, value: true);
        // Get.find<DashboardController>().currentIndex = 0;
        oldPassController.clear();
        newPassController.clear();
        confirmNewPassController.clear();
        Get.back();
      } else {
        setLoader(false);
        showToast(message: response.message);
      }
    } catch (error) {
      setLoader(false);
      final errorMessage = getCatchFinalErrorMsg(error);
      debugPrint("Change Password Catch Error == $error");
      showToast(message: errorMessage);
    }
  }

  changePasswordTapped() async {
    if (oldPassController.text.isEmpty) {
      return showToast(message: pleaseEnterYourCurrentPass.tr);
    } else if (oldPassController.text.length < 4) {
      return showToast(message: passwordMustBeMinimumChars.tr);
    } else if (newPassController.text.isEmpty) {
      return showToast(message: pleaseEnterNewPass.tr);
    } else if (newPassController.text.length < 4) {
      return showToast(message: passwordMustBeMinimumChars.tr);
    } else if (confirmNewPassController.text.isEmpty) {
      return showToast(message: pleaseEnterConfirmPass.tr);
    } else if (newPassController.text != confirmNewPassController.text) {
      return showToast(message: newPassAndConfirmNotMatch.tr);
    } else {
      await changePasswordApi();
    }
  }

  //Delete Account Api
  Future<void> deleteAccountApi() async {
    setLoader(true);
    try {
      ResponseModel response = await ApiService.deleteUserApi();

      debugPrint("Delete Account Response == ${response.body}");

      if (response.status == true) {
        setLoader(false);
        showToast(message: response.message);
        PrefManager().setBoolData(key: isLoginKey, value: false);
        PrefManager().setBoolData(key: homeAppTutorial, value: false);
        PrefManager().setBoolData(key: manualTutorial, value: false);
        Get.offAll(() => const AuthScreen());
      } else {
        setLoader(false);
        showToast(message: response.message);
      }
    } catch (error) {
      setLoader(false);
      final errorMessage = getCatchFinalErrorMsg(error);
      debugPrint("Delete Account Catch Error == $error");
      showToast(message: errorMessage);
    }
  }

  // Create Support Ticket API

  int selectedSupportIndex = 0;
  RxBool isSupportLoading = false.obs;
  List supportList = [];
  TextEditingController sEmailController = TextEditingController();
  TextEditingController sSubjectController = TextEditingController();
  TextEditingController sDescriptionController = TextEditingController();
  String? sAttachImage = '';

  pickBugImage({required ImageSource source}) async {
    final pickedImage = await ImagePicker().pickImage(source: source);
    if (pickedImage == null) return;
    sAttachImage = pickedImage.path;
    update();
  }

  Future<void> createSupport() async {
    isSupportLoading.value = true;
    final createSupportBody = {
      'email': sEmailController.text,
      'subject': sSubjectController.text,
      'description': sDescriptionController.text,
      if (sAttachImage != null && sAttachImage != '')
        'attachment': await dio.MultipartFile.fromFile(sAttachImage!),
    };
    try {
      final res = await ApiService.createTicketApi(body: createSupportBody);
      if (res.status == true) {
        isSupportLoading.value = false;
        sEmailController.clear();
        sSubjectController.clear();
        sDescriptionController.clear();
        sAttachImage = '';
        Get.back();
        showToast(message: res.message);

        await getSupportList();
      } else {
        isSupportLoading.value = false;
        showToast(message: res.message);
      }
    } catch (e) {
      isSupportLoading.value = false;
      debugPrint('CREATE SUPPORT == ERROR == $e');
    }
  }

  bool isValidEmail(String email) {
    final RegExp emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  onSendRequestTap() async {
    if (sEmailController.text.isEmpty) {
      return showToast(message: pleaseEnterYourEmail.tr);
    } else if (!isValidEmail(sEmailController.text)) {
      return showToast(message: pleaseEnterYourValidEmail.tr);
    }  else if (sSubjectController.text.isEmpty) {
      return showToast(message: enterSubject.tr);
    }  else if (sDescriptionController.text.isEmpty) {
      return showToast(message: enterDesc.tr);
    }  else if (sAttachImage == null || sAttachImage!.isEmpty ) {
      await createSupport();
      // return showToast(message: attachDoc.tr);
    } else {
      await createSupport();
    }
  }

  // Get Support Ticket API

  List<SupportData> supportDataList = [];

  Future<void> getSupportList() async {
    isSupportLoading.value = true;

    try {
      final res = await ApiService.getTicketApi(
        status: selectedSupportIndex == 0 ? 'open' : 'close',
      );

      if (res.status == true && res.body != null) {
        List supportList = res.body;
        supportDataList =
            supportList.map((e) => SupportData.fromJson(e)).toList();

        debugPrint(
          "support Data === ${supportDataList.map((e) => e.toJson())}",
        );

        isSupportLoading.value = false;
        update();
      } else {
        isSupportLoading.value = false;
        showToast(message: res.message);
      }
    } catch (e) {
      isSupportLoading.value = false;
      debugPrint('GET SUPPORT LIST == ERROR == $e');
    }
  }

  getLanguageName() async {
    selectedLanguage.value =
        await PrefManager().getStringData(key: myLanguage) ?? english.tr;
  }

  @override
  void onInit() {
    getThemeMode();
    getUserData();
    getLanguageName();
    super.onInit();
  }
}
