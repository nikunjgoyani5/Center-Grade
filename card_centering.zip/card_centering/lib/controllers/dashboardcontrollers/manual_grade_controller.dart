import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../pages/dashboard/pages/grade_calculate.dart';

class ManualGradeController extends GetxController {
  File? frontImage;
  File? backImage;

  //Front Inner boundaries
  double left = 22, right = 22, top = 22, bottom = 22;

  //Front Outer boundaries
  double outerLeft = 10, outerRight = 10, outerTop = 10, outerBottom = 10;

  final double maxValue = 150.0;
  final double minValue = 0.0;
  String horizontalCentering = '';
  String verticalCentering = '';
  String grading = "";

  double centeringScore = 0.0;
  final double gap = 0;

  double lrRatio = 0.0;
  double tbRatio = 0.0;
  double outerLrRatio = 0.0;
  double outerTbRatio = 0.0;
  double gapLeft = 0.0;
  double gapRight = 0.0;
  double gapTop = 0.0;
  double gapBottom = 0.0;

  //Back Inner boundaries
  double leftBack = 22, rightBack = 22, topBack = 22, bottomBack = 22;

  //Back Outer boundaries
  double outerLeftBack = 10,
      outerRightBack = 10,
      outerTopBack = 10,
      outerBottomBack = 10;

  final double maxValueBack = 150.0;
  final double minValueBack = 0.0;
  String horizontalCenteringBack = '';
  String verticalCenteringBack = '';
  String gradingBack = "";

  double centeringScoreBack = 0.0;
  final double gapBack = 0;

  double lrRatioBack = 0.0;
  double tbRatioBack = 0.0;
  double outerLrRatioBack = 0.0;
  double outerTbRatioBack = 0.0;
  double gapLeftBack = 0.0;
  double gapRightBack = 0.0;
  double gapTopBack = 0.0;
  double gapBottomBack = 0.0;

  RxBool isFront = false.obs;
  RxBool isBack = false.obs;

  //Pick Image
  pickImage({required ImageSource source, required bool isFront}) async {
    final ImagePicker imagePicker = ImagePicker();
    final XFile? pickedFile = await imagePicker.pickImage(source: source);
    if (pickedFile != null) {
      if (isFront) {
        frontImage = File(pickedFile.path);
        onFrontChange(true);
        realTimeFrontBorderChange();
        centeringScore = calculateFrontCentering();
      } else {
        backImage = File(pickedFile.path);
        onBackChange(true);

        realTimeBackBorderChange();
        centeringScoreBack = calculateBackCentering();
      }
      update();
    }
  }

  double calculateFrontCentering() {
    double horizontalRatio = left / (left + right);
    double verticalRatio = top / (top + bottom);
    return ((horizontalRatio + verticalRatio) / 2) * 100;
  }

  double calculateBackCentering() {
    double horizontalRatio = leftBack / (leftBack + rightBack);
    double verticalRatio = topBack / (topBack + bottomBack);
    return ((horizontalRatio + verticalRatio) / 2) * 100;
  }

  void adjustFrontInnerBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        left = (left + delta).clamp(minValue, maxValue);
        if (outerLeft + gap > left) {
          outerLeft = left - gap;
        }
        break;
      case "right":
        right = (right - delta).clamp(minValue, maxValue);
        if (outerRight + gap > right) {
          outerRight = right - gap;
        }
        break;
      case "top":
        top = (top + delta).clamp(minValue, maxValue);
        if (outerTop + gap > top) {
          outerTop = top - gap;
        }
        break;
      case "bottom":
        bottom = (bottom - delta).clamp(minValue, maxValue);
        if (outerBottom + gap > bottom) {
          outerBottom = bottom - gap;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: left,
      innerRight: right,
      innerTop: top,
      innerBottom: bottom,
      outerLeft: outerLeft,
      outerRight: outerRight,
      outerTop: outerTop,
      outerBottom: outerBottom,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCentering = result['horizontalCentering'];
    verticalCentering = result['verticalCentering'];
    grading = result['grading'];
    realTimeFrontBorderChange();
    centeringScore = calculateFrontCentering();
    update();
  }

  void adjustFrontOuterBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        outerLeft = (outerLeft + delta).clamp(minValue, maxValue);
        if (outerLeft + gap > left) {
          left = outerLeft + gap;
        }
        break;
      case "right":
        outerRight = (outerRight - delta).clamp(minValue, maxValue);
        if (outerRight + gap > right) {
          right = outerRight + gap;
        }
        break;
      case "top":
        outerTop = (outerTop + delta).clamp(minValue, maxValue);
        if (outerTop + gap > top) {
          top = outerTop + gap;
        }
        break;
      case "bottom":
        outerBottom = (outerBottom - delta).clamp(minValue, maxValue);
        if (outerBottom + gap > bottom) {
          bottom = outerBottom + gap;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: left,
      innerRight: right,
      innerTop: top,
      innerBottom: bottom,
      outerLeft: outerLeft,
      outerRight: outerRight,
      outerTop: outerTop,
      outerBottom: outerBottom,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCentering = result['horizontalCentering'];
    verticalCentering = result['verticalCentering'];
    grading = result['grading'];

    realTimeFrontBorderChange();
    centeringScore = calculateFrontCentering();

    update();
  }

  realTimeFrontBorderChange() {
    lrRatio = left / (left + right);
    tbRatio = top / (top + bottom);

    outerLrRatio = outerLeft / (outerLeft + outerRight);
    outerTbRatio = outerTop / (outerTop + outerBottom);

    gapLeft = (left - outerLeft).clamp(0, double.infinity);
    gapRight = (right - outerRight).clamp(0, double.infinity);
    gapTop = (top - outerTop).clamp(0, double.infinity);
    gapBottom = (bottom - outerBottom).clamp(0, double.infinity);
  }

  void adjustBackInnerBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        leftBack = (leftBack + delta).clamp(minValueBack, maxValueBack);
        if (outerLeftBack + gapBack > leftBack) {
          outerLeftBack = leftBack - gapBack;
        }
        break;
      case "right":
        rightBack = (rightBack - delta).clamp(minValueBack, maxValueBack);
        if (outerRightBack + gapBack > rightBack) {
          outerRightBack = rightBack - gapBack;
        }
        break;
      case "top":
        topBack = (topBack + delta).clamp(minValueBack, maxValueBack);
        if (outerTopBack + gapBack > topBack) {
          outerTopBack = topBack - gapBack;
        }
        break;
      case "bottom":
        bottomBack = (bottomBack - delta).clamp(minValueBack, maxValueBack);
        if (outerBottomBack + gapBack > bottomBack) {
          outerBottomBack = bottomBack - gapBack;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: leftBack,
      innerRight: rightBack,
      innerTop: topBack,
      innerBottom: bottomBack,
      outerLeft: outerLeftBack,
      outerRight: outerRightBack,
      outerTop: outerTopBack,
      outerBottom: outerBottomBack,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCenteringBack = result['horizontalCentering'];
    verticalCenteringBack = result['verticalCentering'];
    gradingBack = result['grading'];
    realTimeBackBorderChange();
    centeringScoreBack = calculateBackCentering();
    update();
  }

  void adjustBackOuterBorder(String direction, double delta) {
    switch (direction) {
      case "left":
        outerLeftBack = (outerLeftBack + delta).clamp(
          minValueBack,
          maxValueBack,
        );
        if (outerLeftBack + gapBack > leftBack) {
          leftBack = outerLeftBack + gapBack;
        }
        break;
      case "right":
        outerRightBack = (outerRightBack - delta).clamp(
          minValueBack,
          maxValueBack,
        );
        if (outerRightBack + gapBack > rightBack) {
          rightBack = outerRightBack + gapBack;
        }
        break;
      case "top":
        outerTopBack = (outerTopBack + delta).clamp(minValueBack, maxValueBack);
        if (outerTopBack + gapBack > topBack) {
          topBack = outerTopBack + gapBack;
        }
        break;
      case "bottom":
        outerBottomBack = (outerBottomBack - delta).clamp(
          minValueBack,
          maxValueBack,
        );
        if (outerBottomBack + gapBack > bottomBack) {
          bottomBack = outerBottomBack + gapBack;
        }
        break;
    }
    var result = CardGradingCalculator.calculateGradingScore(
      innerLeft: leftBack,
      innerRight: rightBack,
      innerTop: topBack,
      innerBottom: bottomBack,
      outerLeft: outerLeftBack,
      outerRight: outerRightBack,
      outerTop: outerTopBack,
      outerBottom: outerBottomBack,
    );

    debugPrint("Horizontal Centering: ${result['horizontalCentering']}%");
    debugPrint("Vertical Centering: ${result['verticalCentering']}%");
    debugPrint("Grading Score: ${result['grading']}");
    horizontalCenteringBack = result['horizontalCentering'];
    verticalCenteringBack = result['verticalCentering'];
    gradingBack = result['grading'];

    realTimeBackBorderChange();
    centeringScoreBack = calculateBackCentering();

    update();
  }

  realTimeBackBorderChange() {
    lrRatioBack = leftBack / (leftBack + rightBack);
    tbRatioBack = topBack / (topBack + bottomBack);

    outerLrRatioBack = outerLeftBack / (outerLeftBack + outerRightBack);
    outerTbRatioBack = outerTopBack / (outerTopBack + outerBottomBack);

    gapLeftBack = (leftBack - outerLeftBack).clamp(0, double.infinity);
    gapRightBack = (rightBack - outerRightBack).clamp(0, double.infinity);
    gapTopBack = (topBack - outerTopBack).clamp(0, double.infinity);
    gapBottomBack = (bottomBack - outerBottomBack).clamp(0, double.infinity);
  }

  onFrontChange(bool isFrontSide) {
    isFront.value = isFrontSide;
    isBack.value = false;
  }

  onBackChange(bool isBackSide) {
    isBack.value = isBackSide;
    isFront.value = false;
  }
}
