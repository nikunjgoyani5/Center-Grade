import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../apptheme/app_strings.dart';
import '../../prefmanage/pref_manage.dart';

class DashboardController extends GetxController {
  int currentIndex = 0;
  bool isScanned = false;

  RxInt searchCount = 0.obs;

  onBottomNavBarTapped(int index) {
    currentIndex = index;
    update();
  }

  setSearchCount() async {
    PrefManager().setIntData(key: userSearchCount, value: searchCount.value);
    searchCount.value = await PrefManager().getIntData(key: userSearchCount);

    debugPrint("search Count ==== ${searchCount.value}");
  }

  setScanStatus(bool value) {
    isScanned = value;
    update();
  }

  Future<void> requestATTPermission() async {
    final trackingStatus =
    await AppTrackingTransparency.trackingAuthorizationStatus;

    if (trackingStatus == TrackingStatus.notDetermined) {
      final status =
      await AppTrackingTransparency.requestTrackingAuthorization();
      debugPrint('Tracking permission: $status');
    }

    final idfa = await AppTrackingTransparency.getAdvertisingIdentifier();
    debugPrint('Advertising Identifier: $idfa');


    Future.delayed(Duration(seconds: 1), () {

      requestPermission();
    });
  }

  Future<void>  requestPermission()async {
    PermissionStatus status = await Permission.notification.request();

    try{
      if (status.isGranted) {
        debugPrint('✅ Notification permission already granted.');
        return;
      }

      if (status.isDenied || status.isRestricted) {
        debugPrint("🛑 Notification permission denied, requesting again...");
        final newStatus = await Permission.notification.request();

        if (newStatus.isGranted) {
          debugPrint("✅ Notification permission granted after request.");
        } else if (newStatus.isDenied) {
          debugPrint("❌ User denied notification permission.");
        } else if (newStatus.isPermanentlyDenied) {
          debugPrint("⚠️ Notification permission permanently denied. Redirecting to settings...");
          // Open settings to manually enable notifications
        }
      }
    }catch(e){
      debugPrint("===$e");
    }

  }

  @override
  void onInit() {
    setSearchCount();
    if (Platform.isIOS) {
      requestATTPermission();
    }
    super.onInit();
  }
}
