import 'package:card_centering/apiservice/api_service.dart';
import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/model/card_info_model.dart';
import 'package:card_centering/model/cardmodel/create_card_model.dart';
import 'package:card_centering/model/response_model.dart';
import 'package:card_centering/model/search_card_model.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../../model/cardmodel/detected_cards_list.dart';

class SearchCardController extends GetxController {
  final searchController = TextEditingController();
  final collectionNameController = TextEditingController();
  RxBool isShowLoader = false.obs;
  RxBool isSearchLoader = false.obs;
  RxBool isShowClosed = false.obs;

  bool isFieldEmpty = true;

  SearchCardModel? searchCardData;
  List<Product> searchProducts = [];
  CardInfoModel? cardInfoData;

  setLoader(bool value) {
    isShowLoader.value = value;
  }

  //Search Card API
  Future<void> searchCard() async {
    isSearchLoader.value = true;
    try {
      final response = await http.get(
        Uri.parse(searchUrl(searchController.text)),
      );
      debugPrint("Search Card URL: ${searchUrl(searchController.text)}");
      if (response.statusCode == 200 || response.statusCode == 201) {
        isSearchLoader.value = false;

        debugPrint("Search Card Response: ${response.body}");
        searchCardData = searchCardModelFromJson(response.body);
        searchProducts = searchCardData?.products ?? [];
        update();
      } else {
        isSearchLoader.value = false;

        debugPrint("Error: ${response.statusCode}");
      }
    } catch (e) {
      isSearchLoader.value = false;

      debugPrint("Catch Error: $e");
    } finally {
      isSearchLoader.value = false;
    }
  }

  //Get All Detected Cards API
  DetectedCardsData? detectedCardsData;
  List<DetectedCards> detectedCardsList = [];

  Future<void> allDetectedCardsApi() async {
    isSearchLoader.value = true;
    try {
      ResponseModel response = await ApiService.detectedCardListApi(
        query: searchController.text,
      );
      debugPrint("Get All Detected Card List ==== ${response.body}");
      if (response.status == true && response.body != null) {
        try {
          detectedCardsData = DetectedCardsData.fromJson(response.body);
          detectedCardsList = detectedCardsData?.data ?? [];

          debugPrint("detected cards  ${detectedCardsData?.toJson()}");
          update();
          isSearchLoader.value = false;
        } catch (e) {
          debugPrint("Parsing Error: $e");
          isSearchLoader.value = false;
        }
      } else {
        isSearchLoader.value = false;
        showToast(message: response.message);
        debugPrint("Get All Detected Card false ${response.message}");
      }
    } catch (e) {
      isSearchLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Get All Detected Card Catch Error: $e");
    } finally {
      isSearchLoader.value = false;
    }
  }

  //Detected Card Details API
  CreateCardData? detectedCardDetails;

  Future<void> detectedCardDetailsApi({required String cardId}) async {
    setLoader(true);
    try {
      ResponseModel response = await ApiService.singleDetectedCardApi(
        cardId: cardId,
      );
      debugPrint("Single Detected Card Details ==== ${response.body}");
      if (response.status == true && response.body != null) {
        detectedCardDetails = CreateCardData.fromJson(response.body);
        update();
        setLoader(false);
      } else {
        setLoader(false);
        showToast(message: response.message);
      }
    } catch (e) {
      setLoader(false);

      debugPrint("Catch Error: $e");
    } finally {
      setLoader(false);
    }
  }

  //Card Info API
  Future<void> cardInfo({required String cardId}) async {
    setLoader(true);
    try {
      final response = await http.get(Uri.parse(priceUrl(cardId)));
      debugPrint("Info Card URL: ${priceUrl(searchController.text)}");
      if (response.statusCode == 200 || response.statusCode == 201) {
        setLoader(false);

        cardInfoData = cardInfoModelFromJson(response.body);

        debugPrint("Info Card Response: ${cardInfoData?.toJson()}");
        searchCardData = searchCardModelFromJson(response.body);
        update();
      } else {
        debugPrint("Error: ${response.statusCode}");
      }
    } catch (e) {
      setLoader(false);

      debugPrint("Catch Error: $e");
    } finally {
      setLoader(false);
    }
  }

  onAddFieldChange() {
    if (collectionNameController.text.isEmpty) {
      isFieldEmpty = true;
    } else {
      isFieldEmpty = false;
    }
    update();
  }

  @override
  void onInit() {
    searchController.addListener(() {
      if (searchController.text.isEmpty) {
        isShowClosed.value = false;
      } else {
        isShowClosed.value = true;
      }
    });

    super.onInit();
  }
}
