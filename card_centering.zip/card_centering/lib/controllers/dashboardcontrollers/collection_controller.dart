import 'package:card_centering/model/cardmodel/create_card_model.dart';
import 'package:card_centering/model/collectionmodel/collection_list_model.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../apiservice/api_service.dart';
import '../../model/response_model.dart';

class CollectionController extends GetxController {
  final collectionNameController = TextEditingController();

  RxBool isShowLoader = false.obs;
  List<CollectionListData> collectionList = [];

  bool isFieldEmpty = true;

  onAddFieldChange() {
    if (collectionNameController.text.isEmpty) {
      isFieldEmpty = true;
    } else {
      isFieldEmpty = false;
    }
    update();
  }

  //Fetch Collection List API
  Future<void> fetchCollectionList() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.collectionListApi();

      if (response.status == true && response.body is List) {
        try {
          final List<Map<String, dynamic>> collectionListList =
              List<Map<String, dynamic>>.from(response.body);

          collectionList =
              collectionListList
                  .map((e) => CollectionListData.fromJson(e))
                  .toList();
          update();
          isShowLoader.value = false;
        } catch (e) {
          debugPrint("Collection List Parsing Error: $e");
          isShowLoader.value = false;
        }
      } else {
        debugPrint("Collection List Error: ${response.message}");
        isShowLoader.value = false;
      }
    } catch (e) {
      isShowLoader.value = false;
      // final errorMessage = getCatchFinalErrorMsg(e);
      debugPrint("Collection List Catch Error: $e");
    } finally {
      isShowLoader.value = false;
    }
  }

  //Create Collection API
  Future<void> createCollectionApi() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.createCollectionApi(
        collectionName: collectionNameController.text,
      );
      debugPrint("Create Collection Response: ${response.body}");

      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        await fetchCollectionList();
        collectionNameController.clear();
        isFieldEmpty = true;
        update();
      } else {
        debugPrint("Collection List Error: ${response.message}");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      isShowLoader.value = false;
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Collection List Catch Error: $e");
    } finally {
      isShowLoader.value = false;
    }
  }

  //Fetch Collection Cards List API
  List<CreateCardData> collectionCardsList = [];
  RxBool isCardsCollectionLoader = false.obs;

  Future<void> fetchCollectionCardsList({required String collectionId}) async {
    isCardsCollectionLoader.value = true;
    try {
      ResponseModel response = await ApiService.collectionCardsListApi(
        collectionId: collectionId,
      );

      if (response.status == true && response.body is List) {
        try {
          isCardsCollectionLoader.value = false;
          final List<Map<String, dynamic>> collectionCardsListList =
              List<Map<String, dynamic>>.from(response.body);
          collectionCardsList =
              collectionCardsListList
                  .map((e) => CreateCardData.fromJson(e))
                  .toList();
          update();
          // showToast(message: response.message);
        } catch (e) {
          debugPrint("Collection Cards List Parsing Error: $e");
          showToast(message: response.message);
          isCardsCollectionLoader.value = false;
        }
      } else {
        debugPrint("Collection Cards List Error: ${response.message}");
        showToast(message: response.message);
        isCardsCollectionLoader.value = false;
      }
    } catch (e) {
      isCardsCollectionLoader.value = false;
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Collection Cards List Catch Error: $e");
    } finally {
      isCardsCollectionLoader.value = false;
    }
  }

  //Update Collection API
  Future<void> updateCollection({required String collectionId}) async {
    try {
      ResponseModel response = await ApiService.updateCollectionApi(
        collectionId: collectionId,
        collectionName: collectionNameController.text,
      );

      if (response.status == true) {
        showToast(message: response.message);
        await fetchCollectionList();
      } else {
        debugPrint("Update Collection Error: ${response.message}");
        showToast(message: response.message);
      }
    } catch (e) {
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Update Collection Catch Error: $e");
    } finally {
      isCardsCollectionLoader.value = false;
    }
  }

  //Delete Collection API
  Future<void> deleteCollection({required String collectionId}) async {
    try {
      ResponseModel response = await ApiService.deleteCollectionApi(
        collectionId: collectionId,
      );

      if (response.status == true) {
        showToast(message: response.message);
        await fetchCollectionList();
      } else {
        debugPrint("Delete Collection Error: ${response.message}");
        showToast(message: response.message);
      }
    } catch (e) {
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Delete Collection Catch Error: $e");
    } finally {
      isCardsCollectionLoader.value = false;
    }
  }

  //Single Card Details API
  CreateCardData? singleCardDetails;

  Future<void> singleCardDetailsApi({required String cardId}) async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.singleDetectedCardApi(
        cardId: cardId,
      );
      debugPrint("Single Detected Card Details ==== ${response.body}");
      if (response.status == true && response.body != null) {
        singleCardDetails = CreateCardData.fromJson(response.body);
        update();
        isShowLoader.value = false;
      } else {
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      isShowLoader.value = false;
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Single Card Details Catch Error: $e");
    } finally {
      isShowLoader.value = false;
    }
  }

  //Remove Card API
  Future<void> removeCardApi({
    required String collectionId,
    required String cardId,
  }) async {
    isCardsCollectionLoader.value = true;
    try {
      ResponseModel response = await ApiService.removeCardApi(
        body: {"cardId": cardId, "collectionId": collectionId},
      );

      if (response.status == true) {
        showToast(message: response.message);
        await fetchCollectionCardsList(collectionId: collectionId);
      } else {
        debugPrint("Remove Card Error: ${response.message}");
        showToast(message: response.message);
      }
    } catch (e) {
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint("Remove Card Catch Error: $e");
    } finally {
      isCardsCollectionLoader.value = false;
    }
  }
}
