import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../apiservice/api_service.dart';
import '../../apptheme/app_strings.dart';
import '../../model/authmodel/login_model.dart';
import '../../model/response_model.dart';
import '../../pages/authscreens/reset_password.dart';
import '../../pages/dashboard/dashboard_screen.dart';
import '../../pages/onboardscreen/onboard_screen.dart';
import '../../prefmanage/pref_manage.dart';
import '../../widgets/common_widgets.dart';

class VerifyOtpController extends GetxController {
  RxInt seconds = 60.obs;
  Timer? _timer;

  final otpController = TextEditingController();

  RxBool isShowLoader = false.obs;
  LoginBody? loginData;

  String emailIDData = '';

  startTimer() {
    stopTimer();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      seconds = seconds - 1;
      if (seconds.value == 0) {
        timer.cancel();
        stopTimer();
      }
    });
  }

  stopTimer() {
    if (_timer != null) {
      _timer?.cancel();
    }
  }

  // Verify OTP
  Future<void> verifyOtpApi({
    required bool isSignUp,
    required String emailId,
  }) async {
    final isFirstUserEnter = await PrefManager().getBoolData(key: isFirst);
    isShowLoader.value = true;
    emailIDData = emailId;
    update();
    try {
      ResponseModel response = await ApiService.verifyOtpApi(
        body: {"email": emailId, "otp": int.parse(otpController.text.trim())},
      );

      debugPrint('verify OTP Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        if (isSignUp == false) {
          Get.off(() => ResetPassword(emailId: emailId));
        } else {
          loginData = LoginBody.fromJson(response.body);
          update();
          Get.to(
            () =>
                isFirstUserEnter == true ? DashboardScreen() : OnboardScreen(),
            transition: Transition.rightToLeftWithFade,
          );
          debugPrint('verify OTP Response Data === ${loginData?.toJson()}');
          await prefManager.setStringData(
            key: accessToken,
            value: loginData?.token ?? '',
          );
          await prefManager.setStringData(
            key: userId,
            value: loginData?.user?.id ?? '',
          );
          await prefManager.setStringData(
            key: userEmail,
            value: loginData?.user?.email ?? '',
          );
          await prefManager.setStringData(
            key: userName,
            value: loginData?.user?.fullname ?? '',
          );
          await prefManager.setStringData(
            key: userImage,
            value: loginData?.user?.profileImage ?? '',
          );
          await prefManager.setBoolData(key: isLoginKey, value: true);
          otpController.clear();
        }
      } else {
        debugPrint("verify OTP status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('verify OTP Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  verifyOtpTapped(bool isSignUp, String emailId) async {
    if (otpController.text.isEmpty) {
      return showToast(message: pleaseEnterOtp.tr);
    } else {
      await verifyOtpApi(isSignUp: isSignUp, emailId: emailId);
    }
  }

  //Resend OTP
  Future<void> resendOtp({required String emailId}) async {
    try {
      ResponseModel response = await ApiService.resendOtpApi(
        body: {"email": emailId},
      );

      debugPrint('Resend OTP Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
      } else {
        debugPrint("Resend status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('Resend Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }
}
