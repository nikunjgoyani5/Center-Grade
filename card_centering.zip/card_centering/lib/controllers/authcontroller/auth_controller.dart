import 'dart:async';
import 'dart:convert';

import 'package:card_centering/apiservice/api_service.dart';
import 'package:card_centering/model/authmodel/login_model.dart';
import 'package:card_centering/model/profilemodel/profile_model.dart';
import 'package:card_centering/pages/authscreens/reset_password.dart';
import 'package:card_centering/pages/authscreens/varify_otp.dart';
import 'package:card_centering/pages/dashboard/dashboard_screen.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import '../../apiservice/api_end_points.dart';
import '../../apptheme/app_strings.dart';
import '../../model/response_model.dart';
import '../../pages/authscreens/login_page.dart';
import '../../pages/onboardscreen/onboard_screen.dart';
import '../../prefmanage/pref_manage.dart';
import '../profilecontroller/profile_controller.dart';

class AuthController extends GetxController {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final otpController = TextEditingController();
  final newPasswordController = TextEditingController();

  auth.UserCredential? userCredential;

  PrefManager prefManager = PrefManager();
  bool isChecked = false;
  RxBool isFirstTime = false.obs;

  String emailIDData = '';

  RxBool isShowLoader = false.obs;

  LoginBody? loginData;

  RxInt seconds = 60.obs;
  Timer? _timer;

  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  passwordVisibility() {
    isPasswordVisible = !isPasswordVisible;
    update();
  }

  confirmPasswordVisibility() {
    isConfirmPasswordVisible = !isConfirmPasswordVisible;
    update();
  }

  onCheckBoxChange() {
    isChecked = !isChecked;
    update();
  }

  bool isValidEmail(String email) {
    final RegExp emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  startTimer() {
    stopTimer();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      seconds = seconds - 1;
      if (seconds.value == 0) {
        timer.cancel();
        stopTimer();
      }
    });
  }

  stopTimer() {
    if (_timer != null) {
      _timer?.cancel();
    }
  }

  signUpTapped() async {
    if (nameController.text.isEmpty) {
      return showToast(message: pleaseEnterYourName.tr);
    } else if (emailController.text.isEmpty) {
      return showToast(message: pleaseEnterYourEmail.tr);
    } else if (!isValidEmail(emailController.text)) {
      return showToast(message: pleaseEnterYourValidEmail.tr);
    } else if (passwordController.text.isEmpty) {
      return showToast(message: pleaseEnterYourPass.tr);
    } else if (passwordController.text.length < 4) {
      return showToast(message: passwordMustBeMinimumChars.tr);
    } else if (confirmPasswordController.text.isEmpty) {
      return showToast(message: pleaseEnterConfirmPass.tr);
    } else if (passwordController.text != confirmPasswordController.text) {
      return showToast(message: passAndConfirmPassNotMatch.tr);
    } else if (isChecked == false) {
      return showToast(message: pleaseAcceptTheTerms.tr);
    } else {
      await registerUser();
    }
  }

  //User Register API
  Future<void> registerUser() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.registerApi(
        body: {
          "fullname": nameController.text.trim(),
          "email": emailController.text.trim(),
          "password": passwordController.text.trim(),
        },
      );

      debugPrint('register Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        Get.to(
          () => VerifyOtp(isSignUp: true, emailId: emailController.text),
          transition: Transition.rightToLeftWithFade,
        );
      } else {
        debugPrint("register status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('register Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  // Verify OTP
  Future<void> verifyOtpApi({required bool isSignUp}) async {
    final isFirstUserEnter = await PrefManager().getBoolData(key: isFirst);
    isShowLoader.value = true;
    emailIDData = emailController.text.trim();
    update();
    try {
      ResponseModel response = await ApiService.verifyOtpApi(
        body: {
          "email": emailController.text.trim(),
          "otp": int.parse(otpController.text.trim()),
        },
      );

      debugPrint('verify OTP Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        if (isSignUp == false) {
          Get.off(() => ResetPassword(emailId: emailController.text));
        } else {
          loginData = LoginBody.fromJson(response.body);
          update();
          Get.to(
            () =>
                isFirstUserEnter == true ? DashboardScreen() : OnboardScreen(),
            transition: Transition.rightToLeftWithFade,
          );
          debugPrint('verify OTP Response Data === ${loginData?.toJson()}');
          await prefManager.setStringData(
            key: accessToken,
            value: loginData?.token ?? '',
          );
          await prefManager.setStringData(
            key: userId,
            value: loginData?.user?.id ?? '',
          );
          await prefManager.setStringData(
            key: userEmail,
            value: loginData?.user?.email ?? '',
          );
          await prefManager.setStringData(
            key: userName,
            value: loginData?.user?.fullname ?? '',
          );
          await prefManager.setStringData(
            key: userImage,
            value: loginData?.user?.profileImage ?? '',
          );
          await prefManager.setBoolData(key: isLoginKey, value: true);
          clearAll();
        }
      } else {
        debugPrint("verify OTP status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('verify OTP Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  verifyOtpTapped(bool isSignUp) async {
    if (otpController.text.isEmpty) {
      return showToast(message: pleaseEnterOtp.tr);
    } else {
      await verifyOtpApi(isSignUp: isSignUp);
    }
  }

  //Resend OTP
  Future<void> resendOtp() async {
    try {
      ResponseModel response = await ApiService.resendOtpApi(
        body: {"email": emailController.text.trim()},
      );

      debugPrint('Resend OTP Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
      } else {
        debugPrint("Resend status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('Resend Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  loginTapped() async {
    if (emailController.text.isEmpty) {
      return showToast(message: pleaseEnterYourEmail.tr);
    } else if (!isValidEmail(emailController.text)) {
      return showToast(message: pleaseEnterYourValidEmail.tr);
    } else if (passwordController.text.isEmpty) {
      return showToast(message: pleaseEnterYourPass.tr);
    } else if (passwordController.text.length < 4) {
      return showToast(message: passwordMustBeMinimumChars.tr);
    } else if (isChecked == false) {
      return showToast(message: pleaseAcceptTheTerms.tr);
    } else {
      await userLogin();
    }
  }

  //Login API
  final profileController = Get.put(ProfileController());

  Future<void> userLogin() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.loginApi(
        body: {
          "email": emailController.text.trim(),
          "password": passwordController.text.trim(),
        },
      );

      debugPrint('Login User Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        loginData = LoginBody.fromJson(response.body);
        update();
        // Get.to(
        //   () => isFirstUserEnter == true ? DashboardScreen() : OnboardScreen(),
        // );
        Get.to(
          () => DashboardScreen(),
          transition: Transition.rightToLeftWithFade,
        );
        debugPrint('Login User Response Data === ${loginData?.toJson()}');
        profileController.userProfile = UserProfile(
          dateOfBirth: loginData?.user?.dateOfBirth,
          email: loginData?.user?.email,
          fullname: loginData?.user?.fullname,
          id: loginData?.user?.id,
          profileImage: loginData?.user?.profileImage,
        );
        profileController.userProfileImage =
            loginData?.user?.profileImage ?? '';
        profileController.userFullName = loginData?.user?.fullname ?? '';
        profileController.userEmailId = loginData?.user?.email ?? '';
        profileController.update();
        await prefManager.setStringData(
          key: accessToken,
          value: loginData?.token ?? '',
        );
        await prefManager.setStringData(
          key: userId,
          value: loginData?.user?.id ?? '',
        );
        await prefManager.setStringData(
          key: userEmail,
          value: loginData?.user?.email ?? '',
        );
        await prefManager.setStringData(
          key: userName,
          value: loginData?.user?.fullname ?? '',
        );
        await prefManager.setStringData(
          key: userImage,
          value: loginData?.user?.profileImage ?? '',
        );
        await prefManager.setBoolData(key: isLoginKey, value: true);

        clearAll();
      } else {
        debugPrint("Login status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      // rethrow;
      debugPrint('Login Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  forgotPasswordTapped() async {
    if (emailController.text.isEmpty) {
      return showToast(message: pleaseEnterYourEmail.tr);
    } else if (!isValidEmail(emailController.text)) {
      return showToast(message: pleaseEnterYourValidEmail.tr);
    } else {
      await forgotPasswordApi();
    }
  }

  forgotPasswordApi() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.forgotPasswordApi(
        body: {"email": emailController.text.trim()},
      );

      debugPrint('Forget Password Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        Get.to(
          () => VerifyOtp(isSignUp: false, emailId: emailController.text),
          transition: Transition.rightToLeftWithFade,
        );
      } else {
        debugPrint("Forget Password status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('Forget Password Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  resetPasswordTapped(String emailId) async {
    if (newPasswordController.text.isEmpty) {
      return showToast(message: pleaseEnterNewPass.tr);
    } else if (newPasswordController.text.length < 4) {
      return showToast(message: passwordMustBeMinimumChars.tr);
    } else if (confirmPasswordController.text != newPasswordController.text) {
      return showToast(message: newPassAndConfirmNotMatch.tr);
    } else {
      await resetPasswordApi(emailId);
    }
  }

  resetPasswordApi(String emailId) async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.resetPasswordApi(
        body: {
          "email": emailId,
          "newPassword": newPasswordController.text.trim(),
          "conformNewPassword": confirmPasswordController.text.trim(),
        },
      );

      debugPrint('Reset Password Response === ${response.toJson()}');
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);
        clearAll();
        Get.off(() => LoginPage());
      } else {
        debugPrint("Reset Password status false");
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (e) {
      debugPrint('Reset Password Cache Error ${e.toString()}');
      isShowLoader.value = false;
      String errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
    }
  }

  //Sign in with google
  Future<void> signInWithGoogle() async {
    final isFirstUserEnter = await PrefManager().getBoolData(key: isFirst);
    try {
      isShowLoader.value = true;
      final GoogleSignInAccount? googleUser =
          await GoogleSignIn(
            scopes: [
              'https://www.googleapis.com/auth/userinfo.profile',
              'https://www.googleapis.com/auth/userinfo.email',
            ],
          ).signIn();

      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;

      final credential = auth.GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );
      userCredential = await auth.FirebaseAuth.instance.signInWithCredential(
        credential,
      );

      if (userCredential != null) {
        // final loginRequestBody = {"token": googleAuth?.idToken.toString()};
        final loginRequestBody = {
          "email": userCredential?.user?.email ?? '',
          "fullname": userCredential?.user?.displayName ?? '',
          "profileImage": userCredential?.user?.photoURL ?? '',
        };

        final response = await http.post(
          Uri.parse(ApiEndPoint.googleLoginUrl),
          body: jsonEncode(loginRequestBody),
          headers: {"Content-Type": "application/json"},
        );

        // log("Google Login Response Body ==== ${response.body}");

        if (response.statusCode == 200 || response.statusCode == 201) {
          isShowLoader.value = false;
          loginData = LoginBody.fromJson(json.decode(response.body)["body"]);
          update();
          profileController.userProfile = UserProfile(
            dateOfBirth: loginData?.user?.dateOfBirth,
            email: loginData?.user?.email,
            fullname: loginData?.user?.fullname,
            id: loginData?.user?.id,
            profileImage: loginData?.user?.profileImage,
          );
          profileController.userProfileImage =
              loginData?.user?.profileImage ?? '';
          profileController.userFullName = loginData?.user?.fullname ?? '';
          profileController.userEmailId = loginData?.user?.email ?? '';
          profileController.update();

          // debugPrint("Login data === ${loginData?.toJson()}");
          prefManager.setStringData(
            key: userName,
            value: loginData?.user?.fullname ?? '',
          );
          prefManager.setStringData(
            key: userEmail,
            value: loginData?.user?.email ?? "",
          );
          prefManager.setStringData(
            key: userImage,
            value: loginData?.user?.profileImage ?? "",
          );
          prefManager.setBoolData(key: isLoginKey, value: true);
          prefManager.setStringData(
            key: accessToken,
            value: loginData?.token ?? '',
          );

          showToast(message: json.decode(response.body)["message"]);
          try {
            Get.to(
              () => OnboardScreen(),
              transition: Transition.rightToLeftWithFade,
            );
          } catch (e) {
            debugPrint("Navigation failed: $e");
          }
        } else {
          isShowLoader.value = false;
          showToast(message: json.decode(response.body)["message"]);
        }
        update();
      }
    } catch (e) {
      isShowLoader.value = false;
      final errorMessage = getCatchFinalErrorMsg(e);
      showToast(message: errorMessage);
      debugPrint('exception->$e');
    }
  }

  // Sign in with apple

  Future<void> signInWithApple() async {
    final isFirstUserEnter = await PrefManager().getBoolData(key: isFirst);

    isShowLoader.value = true;
    try {
      final userDetail = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );
      final oauthCredential = auth.OAuthProvider('apple.com').credential(
        accessToken: userDetail.authorizationCode,
        idToken: userDetail.identityToken,
      );

      await auth.FirebaseAuth.instance
          .signInWithCredential(oauthCredential)
          .then((value) async {
            final firebaseToken = await value.user?.getIdToken();
            final loginRequestBody = {"token": firebaseToken.toString()};

            final response = await http.post(
              Uri.parse(ApiEndPoint.appleLoginUrl),
              body: jsonEncode(loginRequestBody),
              headers: {"Content-Type": "application/json"},
            );

            // log("login request body ==== $loginRequestBody");

            if (response.statusCode == 200 || response.statusCode == 201) {
              isShowLoader.value = false;
              loginData = LoginBody.fromJson(
                json.decode(response.body)["body"],
              );
              update();
              profileController.userProfile = UserProfile(
                dateOfBirth: loginData?.user?.dateOfBirth,
                email: loginData?.user?.email,
                fullname: loginData?.user?.fullname,
                id: loginData?.user?.id,
                profileImage: loginData?.user?.profileImage,
              );
              profileController.userProfileImage =
                  loginData?.user?.profileImage ?? '';
              profileController.userFullName = loginData?.user?.fullname ?? '';
              profileController.userEmailId = loginData?.user?.email ?? '';
              profileController.update();
              prefManager.setStringData(
                key: userName,
                value: loginData?.user?.fullname ?? '',
              );
              prefManager.setStringData(
                key: userEmail,
                value: loginData?.user?.email ?? "",
              );
              prefManager.setStringData(
                key: userImage,
                value: loginData?.user?.profileImage ?? "",
              );
              prefManager.setBoolData(key: isLoginKey, value: true);
              prefManager.setStringData(
                key: accessToken,
                value: loginData?.token ?? '',
              );

              showToast(message: json.decode(response.body)["message"]);
              Get.to(
                () => OnboardScreen(),
                transition: Transition.rightToLeftWithFade,
              );
            } else {
              isShowLoader.value = false;
              showToast(message: json.decode(response.body)["message"]);
            }
          });
      update();
    } catch (e) {
      isShowLoader.value = false;
      showToast(message: someThingWentWrong.tr);
      debugPrint('exception->$e');
    }
  }

  clearAll() {
    nameController.clear();
    emailController.clear();
    passwordController.clear();
    confirmPasswordController.clear();
    newPasswordController.clear();
    isChecked = false;
    update();
  }

  Future<bool> isUserFirstTime() async {
    isFirstTime.value = await PrefManager().getBoolData(key: isFirst);
    debugPrint("First Time app open == ${isFirstTime.value}");
    return isFirstTime.value;
  }

  @override
  void onClose() {
    // otpController.dispose();
    stopTimer();
    super.onClose();
  }
}
