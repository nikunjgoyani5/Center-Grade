import 'dart:io';

import 'package:card_centering/apiservice/api_service.dart';
import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/model/profilemodel/profile_model.dart';
import 'package:card_centering/model/response_model.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:dio/dio.dart' as dio;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../pages/dashboard/dashboard_screen.dart';

class ProfileController extends GetxController {
  final nameController = TextEditingController();
  final dayController = TextEditingController();
  final monthController = TextEditingController();
  final yearController = TextEditingController();

  File? profileImage;

  String userProfileImage = '';
  String userEmailId = '';
  String userFullName = '';

  RxBool isButtonDisabled = false.obs;
  RxBool isShowLoader = false.obs;
  UserProfile? userProfile;

  pickUserProfile({required ImageSource source, bool? isSetting}) async {
    final pickedImage = await ImagePicker().pickImage(source: source);
    if (pickedImage == null) return;
    profileImage = File(pickedImage.path);
    if (isSetting == true) {
      await updateProfile(isEdit: true, isSetting: isSetting);
    }
    update();
  }

  checkButtonStatus() {
    nameController.addListener(() {
      if (nameController.text.isEmpty) {
        isButtonDisabled.value = true;
      } else {
        isButtonDisabled.value = false;
      }
    });
    dayController.addListener(() {
      if (dayController.text.isEmpty) {
        isButtonDisabled.value = true;
      } else {
        isButtonDisabled.value = false;
      }
    });
    monthController.addListener(() {
      if (monthController.text.isEmpty) {
        isButtonDisabled.value = true;
      } else {
        isButtonDisabled.value = false;
      }
    });
    yearController.addListener(() {
      if (yearController.text.isEmpty) {
        isButtonDisabled.value = true;
      } else {
        isButtonDisabled.value = false;
      }
    });
  }

  Future<void> userSkipProfile() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.userProfileApi(
        body: {
          "fullname": nameController.text,
          "profileImage":
              profileImage != null
                  ? await dio.MultipartFile.fromFile(profileImage!.path)
                  : '',
          "dateOfBirth": DateTime(
            int.parse(yearController.text),
            int.parse(monthController.text),
            int.parse(dayController.text),
          ),
        },
      );

      debugPrint("Profile Response == ${response.body}");
      if (response.status == true) {
        isShowLoader.value = false;
        showToast(message: response.message);

        Get.offAll(() => DashboardScreen());
      } else {
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (error) {
      isShowLoader.value = false;
      debugPrint("Profile Catch Error == $error");
      showToast(message: someThingWentWrong.tr);
    }
  }

  //Profile API
  Future<void> updateProfile({required bool isEdit, bool? isSetting}) async {
    isShowLoader.value = true;
    final profileBody = {
      "fullname": nameController.text,
      "profileImage":
          profileImage != null
              ? await dio.MultipartFile.fromFile(profileImage!.path)
              : '',
      if (yearController.text != "" &&
          monthController.text != "" &&
          dayController.text != "")
        "dateOfBirth":
            DateTime(
              int.parse(yearController.text),
              int.parse(monthController.text),
              int.parse(dayController.text),
            ).toLocal(),
    };

    debugPrint("Profile Request == $profileBody");
    try {
      ResponseModel response = await ApiService.userProfileApi(
        body:
            isSetting == true
                ? {
                  "profileImage":
                      profileImage != null
                          ? await dio.MultipartFile.fromFile(profileImage!.path)
                          : '',
                }
                : profileBody,
      );

      debugPrint("Profile Response == ${response.body}");
      if (response.status == true && response.body != null) {
        userProfile = UserProfile.fromJson(response.body);
        userFullName = userProfile?.fullname ?? '';
        userEmailId = userProfile?.email ?? '';
        userProfileImage = userProfile?.profileImage ?? '';
        update();
        isShowLoader.value = false;
        showToast(message: response.message);
        if (isEdit == true) {
          if (isSetting == true) {
            return;
          } else {
            Get.back();
          }
        } else {
          Get.offAll(() => DashboardScreen());
        }
      } else {
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (error) {
      isShowLoader.value = false;
      final errorMessage = getCatchFinalErrorMsg(error);
      debugPrint("Profile Catch Error == $error");
      showToast(message: errorMessage);
    }
  }

  //Fetch User Profile
  Future<void> fetchUserProfileApi() async {
    isShowLoader.value = true;
    try {
      ResponseModel response = await ApiService.getUerProfileApi();

      debugPrint("Fetch Profile Response == ${response.body}");
      if (response.status == true && response.body != null) {
        userProfile = UserProfile.fromJson(response.body);
        userFullName = userProfile?.fullname ?? '';
        userEmailId = userProfile?.email ?? '';
        userProfileImage = userProfile?.profileImage ?? '';
        nameController.text = userFullName;
        dayController.text =
            userProfile?.dateOfBirth?.day.toString().toDoubleDigit() ?? '';
        monthController.text =
            userProfile?.dateOfBirth?.month.toString().toDoubleDigit() ?? '';
        yearController.text = userProfile?.dateOfBirth?.year.toString() ?? '';
        update();
        isShowLoader.value = false;
        // showToast(message: response.message);
      } else {
        isShowLoader.value = false;
        showToast(message: response.message);
      }
    } catch (error) {
      isShowLoader.value = false;
      debugPrint("Fetch Profile Catch Error == $error");
      // showToast(message: someThingWentWrong.tr);
    }
  }

  @override
  void onInit() {
    fetchUserProfileApi();
    super.onInit();
  }
}
