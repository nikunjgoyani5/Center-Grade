import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../apptheme/app_assets.dart';
import '../../apptheme/app_constants.dart';
import '../../apptheme/app_strings.dart';
import '../../prefmanage/pref_manage.dart';

class OnboardController extends GetxController {
  final pageController = PageController();

  RxBool isFirstTime = false.obs;

  int currentPage = 0;

  List<String> onboardImages = [];

  List<String> onboardLightImages = [
    AppAssets.imgOnboard1,
    AppAssets.imgOnboard2,
    AppAssets.imgOnboard3,
  ];

  List<String> onboardDarkImages = [
    AppAssets.imgOnboard1Dark,
    AppAssets.imgOnboard2Dark,
    AppAssets.imgOnboard3Dark,
  ];

  List<String> onboardTitle = [
    scanYourCard.tr,
    knowThatYourCardIs.tr,
    buildYourPersonalCollection.tr,
  ];
  List<String> onboardDesc = [
    checkYourCard.tr,
    getRealTime.tr,
    saveYouFav.tr,
  ];

  onPageChanged(int value) {
    currentPage = value;
    update();
  }

  Future<bool> isUserFirstTime() async {
    isFirstTime.value = await PrefManager().getBoolData(key: isFirst);
    debugPrint("First Time app open == ${isFirstTime.value}");
    return isFirstTime.value;
  }

  @override
  void onInit() {
    onboardImages = isDarkMode() ? onboardDarkImages : onboardLightImages;
    super.onInit();
  }
}
