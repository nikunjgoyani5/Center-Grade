import 'package:get/get.dart';
import '../../model/ad_model.dart';

class AdController extends GetxController {
  AdModel adData = AdModel();
}
