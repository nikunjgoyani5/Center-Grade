import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'app_colors.dart';

class AppTextStyle {
  static TextStyle regular10({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 10.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular12({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 12.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular13({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 13.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular14({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 14.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular16({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 16.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular18({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 18.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular20({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 20.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular22({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 22.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular24({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 24.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular26({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 26.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular28({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 28.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle regular30({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 30.sp,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle medium10({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 10.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium11({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 11.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium12({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 12.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium13({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 13.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium14({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 14.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium15({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 15.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium16({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 16.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium17({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 17.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium18({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 18.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium20({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 20.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium22({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 22.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium24({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 24.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium26({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 26.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium28({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 28.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle medium30({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 30.sp,
      fontWeight: FontWeight.w500,
    );
  }

  static TextStyle semiBold10({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 10.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold11({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 11.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold12({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 12.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold13({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 13.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold14({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 14.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold15({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 15.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold16({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 16.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold17({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 17.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold18({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 18.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold20({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 20.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold22({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 22.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold24({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 24.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold26({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 26.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold28({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 28.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold30({Color color = (AppColors.blackColor)}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 30.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold32({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 32.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold36({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 36.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold40({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 40.sp,
      fontWeight: FontWeight.w600,
    );
  }  static TextStyle semiBold44({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 44.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold42({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 42.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle semiBold48({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 48.sp,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle bold10({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 10.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold12({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 12.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold14({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 14.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold15({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 15.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold16({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 16.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold18({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 18.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold20({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 20.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold22({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 22.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold24({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 24.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold26({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 26.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold28({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 28.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold30({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 30.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold36({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 36.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold38({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 38.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle bold40({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 40.sp,
      fontWeight: FontWeight.w700,
    );
  }

  static TextStyle extraBold10({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 10.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold12({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 12.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold14({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 14.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold16({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 16.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold18({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 18.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold20({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 20.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold22({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 22.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold24({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 24.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold26({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 26.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold28({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 28.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold30({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 30.sp,
      fontWeight: FontWeight.w800,
    );
  }

  static TextStyle extraBold48({Color color = AppColors.blackColor}) {
    return TextStyle(
      fontFamily: 'overused_grotesk',
      color: color,
      fontSize: 48.sp,
      fontWeight: FontWeight.w800,
    );
  }
}
