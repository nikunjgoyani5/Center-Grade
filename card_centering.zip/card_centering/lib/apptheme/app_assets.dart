class AppAssets {
  /// =============== ICONS ================ ///
  static const icGoogle = "assets/icons/ic_google.svg";
  static const icApple = "assets/icons/ic_apple.svg";
  static const icVisible = "assets/icons/ic_visible.svg";
  static const icVisibleOff = "assets/icons/ic_visible_off.svg";
  static const icAdd = "assets/icons/ic_add.svg";
  static const icAddWhite = "assets/icons/ic_add_white.svg";
  static const icCollection = "assets/icons/ic_collection.svg";
  static const icHome = "assets/icons/ic_home.svg";
  static const icSetting = "assets/icons/ic_setting.svg";
  static const icSettingSelected = "assets/icons/ic_setting_selected.svg";
  static const icHomeSelected = "assets/icons/ic_home_selected.svg";
  static const icCollectionSelected = "assets/icons/ic_collection_selected.svg";
  static const icArrowRight = "assets/icons/ic_arrow_right.svg";
  static const icFavFilled = "assets/icons/ic_fav_filled.svg";
  static const icClose = "assets/icons/ic_close.svg";
  static const icArrowBack = "assets/icons/ic_arrow_back.svg";
  static const icScanOrange = "assets/icons/ic_scan_orange.svg";
  static const icScanPurple = "assets/icons/ic_scan_purple.svg";
  static const icScanWhite = "assets/icons/ic_scan_white.svg";
  static const icSearch = "assets/icons/ic_search.svg";
  static const icSearchSelected = "assets/icons/ic_search_selected.svg";
  static const icDrawer = "assets/icons/ic_drawer.svg";
  static const icProfile = "assets/icons/ic_profile.svg";
  static const icGallery = "assets/icons/ic_gallery.svg";
  static const icGalleryWhite = "assets/icons/ic_gallery_white.svg";
  static const icCamera = "assets/icons/ic_camera.svg";
  static const icCameraWhite = "assets/icons/ic_camera_white.svg";
  static const icLogo = "assets/icons/ic_logo.png";
  static const icFaq = "assets/icons/ic_faq.svg";
  static const icFavorite = "assets/icons/ic_favorite.svg";
  static const icLanguage = "assets/icons/ic_language.svg";
  static const icChangePass = "assets/icons/ic_change_pass.svg";
  static const icLogout = "assets/icons/ic_logout.svg";
  static const icManualGrade = "assets/icons/ic_manual_grade.svg";
  static const icPrivacy = "assets/icons/ic_privacy.svg";
  static const icTutorial = "assets/icons/ic_tutorial.svg";
  static const icEdit = "assets/icons/ic_edit.svg";
  static const icDarkMode = "assets/icons/ic_dark_mode.svg";
  static const icFaqSetting = "assets/icons/ic_faq_setting.svg";
  static const icShare = "assets/icons/ic_share.svg";
  static const icContact = "assets/icons/ic_contact.svg";
  static const icSelected = "assets/icons/ic_selected.svg";
  static const icUnselected = "assets/icons/ic_unselected.svg";
  static const icDelete = "assets/icons/ic_delete.svg";
  static const icFolder = "assets/icons/ic_folder.svg";
  static const icMore = "assets/icons/ic_more.svg";
  static const icRename = "assets/icons/ic_rename.svg";
  static const icEmptyCollection = "assets/icons/ic_empty_collection.svg";
  static const icPriceChecker = "assets/icons/ic_price_checker.svg";
  static const icEmptyFav = "assets/icons/ic_fav_empty.svg";
  static const icCollectionIcon = 'assets/icons/ic_collection_icon.svg';
  static const icManualArrowLeft = 'assets/icons/ic_manual_arrow_left.svg';
  static const icManualArrowRight = 'assets/icons/ic_manual_arrow_right.svg';
  static const icManualArrowTop = 'assets/icons/ic_manual_arrow_top.svg';
  static const icManualArrowDown = 'assets/icons/ic_manual_arrow_down.svg';
  static const icInfo = 'assets/icons/ic_info.svg';
  static const icImprove = 'assets/darktheme/icons/ic_improve.svg';

  /// =============== IMAGES ================ ///
  static const imgPremium = "assets/images/img_premium.svg";
  static const imgAuthBg = "assets/images/img_auth_bg.png";
  static const imgCard = "assets/images/img_card.png";
  static const imgWhiteBg = "assets/images/img_white_bg.png";
  static const imgOnboardBg = "assets/images/img_onboard_bg.png";
  static const imgOnboard1 = "assets/images/img_onboard_1.png";
  static const imgOnboard2 = "assets/images/img_onboard_2.png";
  static const imgOnboard3 = "assets/images/img_onboard_3.png";
  static const imgPlaceHolder = "assets/images/img_place_holder.png";
  static const imgLogo = "assets/images/img_logo.png";
  static const imgWhiteLogo = "assets/images/img_white_logo.png";

  // =================================== DARK THEME ASSETS ===================================== //

  // =============== ICONS ================ //
  static const icArrowBackDark =
      "assets/darktheme/icons/ic_arrow_back_dark.svg";
  static const icAppleWhite = "assets/darktheme/icons/ic_apple_white.svg";
  static const icLogoDark = "assets/darktheme/icons/ic_logo_dark.png";
  static const icArrowRightDark =
      "assets/darktheme/icons/ic_arrow_right_dark.svg";
  static const icEmptyCollectionDark =
      "assets/darktheme/icons/ic_empty_collection_dark.svg";
  static const icEmptyFavDark = "assets/darktheme/icons/ic_fav_empty_dark.svg";
  static const icLevelUp = "assets/darktheme/icons/ic_levelup.svg";
  static const icPlaceCard = "assets/darktheme/icons/ic_place_card.svg";
  static const icProtection = "assets/darktheme/icons/ic_protection.svg";
  static const icScanner = "assets/darktheme/icons/ic_scanner.svg";
  static const icTips = "assets/darktheme/icons/ic_tips.svg";

  // =============== IMAGES ================ //
  static const imgAuthBgDark = "assets/darktheme/images/img_auth_bg_dark.png";
  static const imgOnboardBgDark =
      "assets/darktheme/images/img_onboard_bg_dark.png";
  static const imgOnboard1Dark =
      "assets/darktheme/images/img_onboard_1_dark.png";
  static const imgOnboard2Dark =
      "assets/darktheme/images/img_onboard_2_dark.png";
  static const imgOnboard3Dark =
      "assets/darktheme/images/img_onboard_3_dark.png";
  static const imgPsa = "assets/darktheme/images/img_psa.png";
  static const imgBeckett = "assets/darktheme/images/img_beckett.png";
  static const imgCgc = "assets/darktheme/images/img_cgc.png";
  static const imgSgc = "assets/darktheme/images/img_sgc.png";
  static const imgTag = "assets/darktheme/images/img_tag.png";
}
