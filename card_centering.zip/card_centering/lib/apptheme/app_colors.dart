import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xFF3D8AFF);
  static const primaryPurple = Color(0xFF982AF3);
  static const purpleE8B4F3 = Color(0xFFE8B4F3);
  static const purpleF1D5F9 = Color(0xFFF1D5F9);
  static const purpleF4E7FF = Color(0xFFF4E7FF);
  static const purpleFAF5FF = Color(0xFFFAF5FF);
  static const orangeFFF5ED = Color(0xFFFFF5ED);
  static const orangeFCE3C9 = Color(0xFFFCE3C9);
  static const orangeF16E31 = Color(0xFFF16E31);
  static const blackColor = Color(0xFF222222);
  static const black = Color(0xFF000000);
  static const black0D0C0C = Color(0xFF0D0C0C);
  static const black888888 = Color(0xFF888888);
  static const whiteColor = Color(0xFFFFFFFF);
  static const whiteFFFEFD = Color(0xFFFFFEFD);
  static const whiteFAFAFA = Color(0xFFFAFAFA);
  static const lightWhiteColor = Color(0xFFDAEDFF);
  static const bgColor = Color(0xFFF8F8F8);
  static const borderColor = Color(0xFFE1E1E1);
  static const borderD9D9D9 = Color(0xFFD9D9D9);
  static const borderFFE8D5 = Color(0xFFFFE8D5);
  static const borderF4E7FF = Color(0xFFF4E7FF);
  static const lightBlueColor = Color(0xFFEDF6FE);
  static const greyE2E2E8 = Color(0xFFE2E2E8);
  static const greyF2F2F7 = Color(0xFFF2F2F7);
  static const greyCBCBCF = Color(0xFFCBCBCF);
  static const grey85858B = Color(0xFF85858B);
  static const grey8E8E94 = Color(0xFF8E8E94);
  static const greyF4F5F5 = Color(0xFFF4F5F5);
  static const greyC8C8CA = Color(0xFFC8C8CA);
  static const greyF6F6F6 = Color(0xFFF6F6F6);
  static const grey878787 = Color(0xFF878787);
  static const greyE5E5E5 = Color(0xFFE5E5E5);
  static const grey6D6D6D = Color(0xFF6D6D6D);
  static const greyEBEBEB = Color(0xFFEBEBEB);
  static const grey9B9B9B = Color(0xFF9B9B9B);
  static const greyF5F5F5 = Color(0xFFF5F5F5);
  static const greyEFEFEF = Color(0xFFEFEFEF);
  static const disableColor = Color(0xFFe0bffb);
  static const disableWhiteColor = Color(0xFF595959);

  static const greyTextColor = Color(0xFF99A0B7);
  static const containerBgColor = Color(0xFFF4F6FC);
  static const dividerColor = Color(0xFFEBEBEC);
  static const hintColor = Color(0xFF5F6368);
  static const appBgColor = Color(0xFFF6F9FF);
  static const liteGrayColors = Color(0xFFF5F6F9);
  static const darkBlueColors = Color(0xff232447);
  static const disableTextColor = Color(0xFF7D7D91);
  static const standingsDarkBlueColor = Color(0xFF174182);
  static const grayColors = Color(0xFF6C7278);
  static const tileBoxShadow = Color(0xffEEF1F5);

  static Color redColor = Colors.red;
  static Color green = Color(0xFF34C759);
  static Color yellow = Colors.yellow;
  static const Color transparent = Colors.transparent;

  /// ==================== Dark Theme Colors ======================== ///
  static const black121212 = Color(0xFF121212);
  static const black1E1E1E = Color(0xFF1E1E1E);
  static const blackB3B3B3 = Color(0xFFB3B3B3);
  static const disableColorDark = Color(0xFF3a1955);
  static const grey2A2A2A = Color(0xFF2A2A2A);
  static const greyCCCCCC = Color(0xFFCCCCCC);
  static const grey888888 = Color(0xFF888888);
  static const grey2F2F2F = Color(0xFF2F2F2F);
  static const grey3E3E3E = Color(0xFF3E3E3E);
}
