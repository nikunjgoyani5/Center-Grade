// Grading API Token
import 'package:get/get.dart';
import 'package:logic_go_network/network/rest_client.dart';

const apiKey = "27baf822dd2e473b57c8f19b91b2f2e6500af7ac";
const gradingUrl = "https://api.ximilar.com/card-grader/v2/grade";

// Price API Token
const priceApiKey = "c54ebbf1e63b815efde46ecd383ab415093e07bc";

late RestClient restClient;
const baseUrl = "http://139.59.36.221:8090/api/v1";
String token = '';

String searchUrl(String query) =>
    "https://www.pricecharting.com/api/products?t=$priceApiKey&q=$query";

String priceUrl(String id) =>
    "https://www.pricecharting.com/api/product?t=$priceApiKey&id=$id";

bool isDarkMode() {
  return Get.context!.isDarkMode;
}
