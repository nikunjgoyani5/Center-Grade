import 'package:flutter/material.dart';
import 'app_colors.dart';

final ThemeData darkTheme = ThemeData(
  pageTransitionsTheme: PageTransitionsTheme(
    builders: Map<TargetPlatform, PageTransitionsBuilder>.fromIterable(
      TargetPlatform.values,
      value: (_) => const FadeForwardsPageTransitionsBuilder(),
    ),
  ),
  fontFamily: "overused_grotesk",
  brightness: Brightness.dark,
  colorScheme: ColorScheme.fromSeed(
    seedColor: AppColors.black121212,
    brightness: Brightness.dark,
  ),
  hoverColor: AppColors.transparent,
  splashColor: AppColors.transparent,
  highlightColor: AppColors.transparent,
  focusColor: AppColors.transparent,
  scaffoldBackgroundColor: AppColors.black121212,
  appBarTheme: const AppBarTheme(
    backgroundColor: AppColors.black121212,
    scrolledUnderElevation: 0.0,
  ),
  textSelectionTheme: const TextSelectionThemeData(
    selectionHandleColor: AppColors.black121212,
  ),
  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: AppColors.primaryPurple,
  ),
  dialogTheme: const DialogTheme(backgroundColor: AppColors.black121212),
);

final ThemeData lightTheme = ThemeData(
  pageTransitionsTheme: PageTransitionsTheme(
    builders: Map<TargetPlatform, PageTransitionsBuilder>.fromIterable(
      TargetPlatform.values,
      value: (_) => const FadeForwardsPageTransitionsBuilder(),
    ),
  ),
  fontFamily: "overused_grotesk",
  brightness: Brightness.light,
  colorScheme: ColorScheme.fromSeed(
    seedColor: AppColors.whiteColor,
    brightness: Brightness.light,
  ),
  hoverColor: AppColors.transparent,
  splashColor: AppColors.transparent,
  highlightColor: AppColors.transparent,
  focusColor: AppColors.transparent,
  scaffoldBackgroundColor: AppColors.whiteColor,
  appBarTheme: const AppBarTheme(
    backgroundColor: AppColors.whiteColor,
    scrolledUnderElevation: 0.0,
  ),
  textSelectionTheme: const TextSelectionThemeData(
    selectionHandleColor: AppColors.black121212,
  ),
  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: AppColors.primaryColor,
  ),
  dialogTheme: const DialogTheme(backgroundColor: AppColors.whiteColor),
  tabBarTheme: TabBarTheme(
    overlayColor: WidgetStatePropertyAll(AppColors.transparent),
    labelPadding: EdgeInsets.all(10),
  ),
);
