/// ============= DASHBOARD SCREEN ============= ///
const appName = "Center Grade";
const lrText = "L/R";
const tbText = "T/B";
const confirmExit = "Confirm Exit?";
const exitWarning = "Are you sure you want to exit ?";
const quit = "Quit";
const cancel = "Cancel";
const manualGrading = "Manual Grading";
const cardDetails = "Card Details";
const category = "Category";
const cardSide = "Card Side";
const aiGrade = "AI Grade";
const corners = "Corners";
const edges = "Edges";
const centering = "Centering";
const exitText = "Exit";

/// ============= Shared Pref KEYs ============= ///
const isFirst = "is_first_time";
const isLightModeKey = "is_light_mode";
const isLoginKey = "is_login";
const accessToken = "Access-Token";
const userId = "User-Id";
const userEmail = "User-Email";
const userName = "User-Name";
const userImage = "User-Image";
const languageCode = "languageCode";
const contCode = "countryCode";
const myLanguage = "myLanguage";
const iapStatusKey = "iap_status";
const userScanAttempt = "user_scan_attempt";
const userSearchCount = "user_search_count";
const homeAppTutorial = "home_app_tutorial";
const manualTutorial = "manual_tutorial";

/// ================ Auth Screens ============== ///
const knowYour = 'Know Your';
const cardsGrade = 'Card\'s Grade';
const beforeYouSubmit = 'Before You Submit.';
const continueText = 'Continue';
const aiPoweredCenteringScansInSecondsAvoidPSA9sGetMore10s =
    'AI-powered centering scans in seconds. Avoid PSA 9s. Get more 10s.';
const signUp = 'Sign Up';
const signIn = 'Sign In';
const accessYourScansAndPickUpRightWhereYouLeftOff =
    'Access your scans and pick up right where you left off.';
const emailAddress = 'Email Address';
const enterYourEmailAddress = 'Enter Your Email Address';
const pleaseEnterYourName = 'Please Enter Your Name';
const pleaseEnterYourEmail = 'Please Enter Your Email';
const pleaseEnterYourValidEmail = 'Please Enter A Valid Email';
const pleaseEnterYourPass = 'Please Enter Your Password';
const passwordMustBeMinimumChars = 'Password Must Be Minimum 4 Characters';
const pleaseEnterConfirmPass = 'Please Enter Your Confirm Password';
const passAndConfirmPassNotMatch =
    'Password And Confirm Password Does Not Match';
const pleaseAcceptTheTerms =
    'Please Accept The Terms of use and Privacy Policy';
const pleaseEnterOtp = 'Please Enter OTP';
const pleaseEnterNewPass = 'Please Enter New Password';
const newPassAndConfirmNotMatch =
    'New Password And Confirm Password Does Not Match';

/// AHI THI BAAKI CHHE
const password = 'Password';
const enterYourPassword = 'Enter Your Password';
const forgotPassword = 'Forgot Password?';
const iHaveReadAndIAgreeToThe = 'I have read and I agree to the';

const termsOfUse = 'Terms of use';
const and = 'and';
const privacyPolicy = 'Privacy Policy';
const centerGradeAccount = 'CenterGrade Account';
const findOutIfYourCardIsCenteredEnoughForAPSA10inSeconds =
    'Find out if your card is centered enough for a PSA 10 - in seconds.';
const fullName = 'Full Name';
const enterYourFullName = 'Enter your full name';
const usedToLoginAndAAccessYourScansSecurely =
    'Used to log in and access your scans securely';
const confirmPassword = 'Confirm Password';
const reEnterPassword = 'Re-enter password';
const weWillEmailYouAOneTimeCodeToResetYourPassword =
    'We\'ll email you a one-time code to reset your password.';
const sendCode = 'Send Code';
const verifyYourCode = 'Verify Your Code';
const weJustEmailedYouA6DigitCodeEnterItBelowToContinue =
    'We just emailed you a 6-digit code. Enter it below to continue.';
const didntGetTheCode = 'Didn\'t get the code?';
const resendOTP = 'Resend OTP';
const verifyOTP = 'Verify OTP';
const resetPassword = 'Reset Password';
const enterANewPasswordToSecureYourAccount =
    'Enter a new password to secure your account.';
const newPassword = 'New Password';
const enterNewPassword = 'Enter New Password';
const getStarted = 'Get Started';
const get3FreeScansNoCreditCardKnowYourCardsCenteringInSeconds =
    'Get 3 free scans. No credit card. Know your card\'s centering in seconds.';
const or = 'or';
const continueWithGoogle = 'Continue with Google';
const continueWithApple = 'Continue with apple';

///--home screen ---///
const welcomeBack = 'Welcome Back!';
const lets = "Let’s check your card’s centering";
const threeFreeScan = "3 Free Scan Left";
const scanMyCard = "Scan My Card";
const scanYourCardIn = "Scan your card in seconds";
const uploadAPhoto =
    "Upload a photo or take one now - we’ll scan it and show centering instantly.";

///---Collection ---///

const ungraded = 'Ungraded';
const rename = 'Rename';
const delete = 'Delete';
const noCardsAvailable = 'No Cards Available in this collection';
const card = 'Card';
const myCollection = 'My Collection';
const addCollection = 'Add Collection';
const renameCollection = 'Rename Collection';
const renameYourCollection = 'Rename Your Collection';
const createCollection = 'Create Collection';
const createNewCollection = 'Create New Collection';
const noCardsYet = 'No cards yet. Start adding.';
const nameYourCollection = 'Name Your Collection';
const youCanChangeThis = 'You can change this anytime.';

/// favourite
const favorites = 'Favorites';
const noFavoritesYet = 'No Favorites Yet';
const tapTheStar = 'Tap the ⭐ to save your favorite cards and scans here.';

/// paywall screen
const gradeSmarter = 'Grade Smarter. Your First 3 Scans Are Free.';
const noCreditCard =
    'No credit card. Instant centering analysis. Try it risk-free.';
const proPlan = 'Pro Plan';
const mostPopular = 'Most Popular';
const month = 'month';
const save25 = 'Save 25%';
const startFreeThen = 'Start Free – Then';
const threeScanFree =
    '3 scans free. Cancel anytime before trial ends. Limited-time 25% off.';
const otherPlan = 'Other Plans';
const subScriptionPurchasedSuccess = "Subscription purchased successfully";

/// profile screen

const saveProfile = 'Save Profile';
const skipForNow = 'Skip for now';
const yourProfile = 'Your Profile';
const setUpYour = 'Set up your profile to personalize your experience.';
const name = 'Name';
const enterYourName = 'Enter Your Name';
const birthDay = 'Birthday';
const pleaseEnterDate = 'Please Enter Date.';
const pleaseEnterMonth = 'Please Enter Month.';
const pleaseEnterYear = 'Please Enter Year.';
const takeAPhoto = 'Take A Photo';
const selectPhoto = 'Select A Photo';
const enterValidNumber = "Enter Valid Number";

///search card
const addCards = 'Add cards easily and keep track effortlessly';
const collectionName = 'Collection Name';
const enterYourCollectionName = 'Enter your collection name';
const searchCard = 'Search your card or cert';
const search = 'Search';
const noCard = 'No Card Found';

///setting
const lowerThan = 'Lower than';
const top = 'top';
const bottom = 'bottom';
const left = 'left';
const right = 'right';
const leftRight = 'Left/Right';
const topBottom = 'Top/Bottom';
const grading = 'Grading';
const download = 'Download';
const frontDetail = 'Front Details';
const backDetail = 'Back Details';
const addToCollection = 'Add to Collection';
const items = 'Items';
const done = 'Done';
const priceChecker = 'Price Checker';
const grade = 'Grade';
const setting = 'Setting';
const no = 'No';
const yes = 'Yes';
const saveCardDetail = 'Save Card Details?';
const doYouWantTo = 'Do you want to keep your card details saved or not?';
const editProfile = 'Edit Profile';
const general = 'General';
const darkMode = 'Dark Mode';
const appTutorial = 'App Tutorial';
const language = 'Language';
const share = 'Share';
const changePass = 'Change Password';
const deleteAccount = 'Delete Account';
const deleteWarning = "Are you sure you want to delete your account?";
const aboutUs = 'About us';
const letMeReCommand = 'Let Me Recommend You This App';
const contactUs = 'Contact us';

// ============= Support Ticket Screen ============== //
const getSupport = "Get Support";
const supportRequests = "Support Requests";
const openTickets = 'Open Tickets';
const closeTickets = 'Closed Tickets';
const noTicket = "No Ticket Found";
const open = "open";
const close = "close";
const sendRequest = 'Send Request';
const email = "Email";
const enterMail = "Enter Email";
const subject = "Subject";
const enterSubject = "Enter Subject";
const description = "Description";
const enterDesc = "Enter Description";
const attachImage = 'Attach Image';
const attachDoc = 'Attach Document';


// ================= Change Password Screen =================== //
const currentPass = "Current Password";
const reTypeNewPass = "Retype New Password";

const faq = 'FAQ';
const home = 'Home';
const collection = 'Collection';
const center = 'Center';
const manualCardGrading = 'Manual Card Grading';
const manualCentering = 'Manual Centering';
const logout = 'Logout';
const logoutText = 'Log Out';
const logOutWarning = "Are you sure you want to log out?";
const user = 'User';
const doYouReally = 'do you really want to exit the app ?';

///onboard
const startUsingCenterGrade = 'Start Using CenterGrade';
const next = 'Next';

// ============== Manual Card Grading ============== //
const frontSide = "Front Side";
const backSide = "Back Side";
const frontScore = "Front Centering Score";
const backScore = "Back Centering Score";
const gradeYourCard = "Grade your card";
const instantGrade = "Get an instant grade for your collectible card.";
const pickCard = "Pick card";
const captureYourCard = "Capture your card";
const checkCentering = "Manually Check Centering";
const centerDesc =
    "Use the drag tool to manually align your card and measure centering.";
const uploadPhoto = "Upload Card Photo";
const takePhoto = "Take Card Photo";

/// ================ Standard Screens ============== ///
const standard = "Standards";
const determineStandards =
    "To determine what category the center grading result falls under, Kindly";
const tapHere = "Tap Here.";
const gradingStandards = "Grading Standards";
const psa = "PSA";
const psaFullName = "Professional Sports Authenticator";
const beckett = "Beckett";
const beckettFullName = "Beckett Grading Company";
const cgc = "CGC";
const cgcFullName = "Certified Guaranty Company";
const sgc = "SGC";
const sgcFullName = "Sportscard Guaranty Corporation";
const tag = "TAG";
const tagFullName = "Technical Authentication & Grading";
const reference = "Reference";
const tipsTricks = "Tips & Tricks";
const placeCardOn = 'Place Card On a Solid, High-Contrast Background';
const usingSolid =
    'Using a SOLID, high-contrast background is crucial for helping the scanner find your card. use a light background (e.g., white) for cards with dark borders, and a dark background (e.g., black or blue) for cards with light borders';
const improveLightening = 'Improve Lightening & Avoid Glare';
const ensureThere =
    'Ensure there is adequate lighting when scanning. In low light conditions, utilize the flashlight (accessible via the button in the lower-left corner) and adjust your position to minimize glare';
const removeCard = 'Remove Card Protection';
const removeAnyProtection =
    'Remove any protection such as card sleeves, top loaders, or semi-rigid holders during scanning. Card protection can cause reflections and make it difficult to identity the edges & inner content of the card. This results in poor scans and less accurate auto border detection.';
const scannerResolution = "Scanner resolution";
const choosing =
    'Choosing a higher resolution will improve auto border detection and produce crispier images for better centering calculations. Normal resolution is 1920x1080. Highest resolution is 4224x2376.';
const levelUpYourScans = 'Level Up Your Scans';
const ensureYourPhone =
    'Ensure your phone is perfectly level with your card to avoid edge distortions. Use the app\'s built-in vertical and horizontal leveling indicators to guid your alignment. As you adjust your phone, the bounding box around your card will transition from red to yellow to green. For optimal results, wait until the bounding box turns green before taking your scan.';
const gradingScale = "Grading Scale";

///other
const someThingWentWrong = 'Something Went Wrong';
const selectCollection = 'Select Collection';
const english = 'English';
const chinese = 'Chinese (Simplified)';
const japanese = 'Japanese';
const spanish = 'Spanish';
const pleaseEnterYourCurrentPass = 'Please Enter Your Current Password';
const scanYourCard = 'Scan Your Card';
const knowThatYourCardIs = 'Know What Your Card Is Really Worth';
const buildYourPersonalCollection = 'Build Your Personal Collection';
const checkYourCard =
    'Check your card’s centering in seconds - no guessing, just data.';
const getRealTime =
    'Get real-time prices for PSA 10 through 7 - and ungraded - powered by PriceCharting.';
const saveYouFav =
    'Save your favorite scans and organize your cards in one place.';
const purchaseCompleted = 'Purchase Completed';
const noPurchase = "You Have Not Made Any Purchase.";

/// ============== TEST ADs IDs ================ ///
const testHomeBannerAdKey = "ca-app-pub-3940256099942544/6300978111";
const testOpenAdKey = "ca-app-pub-3940256099942544/9257395921";
const testInterstitialAdKey = "ca-app-pub-3940256099942544/1033173712";
const testNativeAdKey = "ca-app-pub-3940256099942544/2247696110";

/// ============== LIVE ADs IDs ================ ///
const liveHomeBannerAdKey = "ca-app-pub-3940256099942544/6300978111";
const liveOpenAdKey = "ca-app-pub-3940256099942544/9257395921";
const liveInterstitialAdKey = "ca-app-pub-3940256099942544/1033173712";
const liveNativeAdKey = "ca-app-pub-3940256099942544/2247696110";

/// ============== Ad Mode ================ ///
const isTestMode = true;

/// ============== Firebase Remote Config Keys ================ ///

const testAdsData = "test_ads_json";
const liveAdsData = "live_ads_json";
const iapPlan = "iap_plans";

/// =================== ADs Type Key ===================== ///

const backgroundOpenAd = "background_open_app";
const splashOpenAd = "splash_open_app";
const scanIntertitalAd = "scan_interstitial";
const addToCollectionIntertitalAd = "add_to_collection_interstitial";
const homeBannerAd = "home_banner";
const homeNativeAd = "home_native";

/// ================================ REVENUE-CAT PURCHASE KEYs ======================================= ///
const revenueCatAppleKey = '';
const revenueCatAndroidKey = '';
const entitlementIdentifierIos = "";
const entitlementIdentifierAndroid = "";
const monthlyBaseKey = "monthly_base";
const monthlyProKey = "monthly_Pro";
const monthlyEliteKey = "monthly_elite";
