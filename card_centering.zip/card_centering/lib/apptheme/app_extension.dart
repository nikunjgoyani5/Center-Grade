import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

import '../widgets/common_button.dart';
import 'app_colors.dart';
import 'app_textstyle.dart';

extension PriceExtension on int {
  String formatPrice() {
    double priceInDollars = this / 100;
    return '\$${priceInDollars.toStringAsFixed(2)}';
  }
}

extension NameExtension on String {
  String convertToSlug() {
    return toLowerCase()
        .replaceAll('#', '')
        .replaceAll(RegExp(r'[^\w\s-]'), '')
        .replaceAll(RegExp(r'\s+'), '-')
        .replaceAll(RegExp(r'-+'), '-')
        .trim();
  }
}

Future<int> getApiLevel() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  return androidInfo.version.sdkInt;
}

Future<bool> askPermission(
  Permission permission,
  String type,
  bool isFront,
) async {
  PermissionStatus status = await permission.request();
  switch (status) {
    case PermissionStatus.denied:
      if (type == "Photos") {
        // Get.find<HomeController>().pickImage(
        //   source: ImageSource.gallery,
        //   isFront: isFront
        // );
      } else if (type == "Camera") {
        Get.find<HomeController>().getImageFromCamera(isFront);
      }
      return false;
    case PermissionStatus.granted:
      return true;
    case PermissionStatus.restricted:
      return false;
    case PermissionStatus.limited:
      return true;
    case PermissionStatus.permanentlyDenied:
      Get.dialog(
        transitionCurve: Curves.ease,
        barrierDismissible: false,
        Dialog(
          backgroundColor: AppColors.whiteColor,
          insetAnimationCurve: Curves.linear,
          insetPadding: EdgeInsets.symmetric(horizontal: Get.width * .05),
          child: PopScope(
            // ignore: deprecated_member_use
            onPopInvoked: (val) async => true,
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Need Access", style: AppTextStyle.semiBold22()),
                  SizedBox(height: Get.height * .02),
                  Text(
                    "The app has been denied $type access. You can allow it in app settings.",
                    textAlign: TextAlign.center,
                    style: AppTextStyle.semiBold16(color: AppColors.hintColor),
                  ),
                  SizedBox(height: Get.height * .05),
                  Row(
                    children: [
                      Expanded(
                        child: CommonButton(
                          buttonColor: AppColors.primaryColor,
                          borderColor: Colors.transparent,
                          onPressed: () async {
                            Get.back();
                            openAppSettings();
                          },
                          buttonHeight: Get.height * 0.06,
                          buttonWidth: Get.width,
                          child: Text(
                            "Go Settings",
                            style: AppTextStyle.semiBold16(
                              color: AppColors.whiteColor,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: CommonButton(
                          buttonColor: AppColors.whiteColor,
                          borderColor: AppColors.hintColor,
                          onPressed: () {
                            Get.back();
                          },
                          buttonHeight: Get.height * 0.06,
                          buttonWidth: Get.width,
                          child: Text(
                            "Cancel",
                            style: AppTextStyle.semiBold16(
                              color: AppColors.hintColor,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
      return false;
    case PermissionStatus.provisional:
      return false;
  }
}

extension DateFormatting on String {
  String toDoubleDigit() {
    final number = int.tryParse(this);
    if (number == null || number <= 0) return '00';
    return number.toString().padLeft(2, '0');
  }
}
