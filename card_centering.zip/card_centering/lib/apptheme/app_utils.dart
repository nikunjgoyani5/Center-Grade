import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:get/get.dart';

import '../widgets/common_button.dart';
import 'app_colors.dart';
import 'app_textstyle.dart';


Future<bool> askPermission(PermissionStatus status, String type,{ bool? isHome }) async {
  switch (status) {
    case PermissionStatus.denied:
      if (type == "Photos" && isHome == true) {
        // Get.find<HomeController>().pickQrImage();
      } else if (type == "Photos" && isHome == false) {
        // Get.find<AddManualController>().pickImage();
      }
      return false;
    case PermissionStatus.granted:
      return true;
    case PermissionStatus.restricted:
      return false;
    case PermissionStatus.limited:
      return true;
    case PermissionStatus.permanentlyDenied:
      Get.dialog(
          transitionCurve: Curves.ease,
          barrierDismissible: false,
          Dialog(
            backgroundColor: AppColors.whiteColor,
            insetAnimationCurve: Curves.linear,
            insetPadding: EdgeInsets.symmetric(horizontal: Get.width * .05),
            child: PopScope(
              // ignore: deprecated_member_use
              onPopInvoked: (val) async => true,
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("Need Access", style: AppTextStyle.semiBold22()),
                    SizedBox(height: Get.height * .02),
                    Text(
                        "The app has been denied $type access. You can allow it in app settings.",
                        textAlign: TextAlign.center,
                        style: AppTextStyle.semiBold16(
                            color: AppColors.hintColor)),
                    SizedBox(height: Get.height * .05),
                    Row(
                      children: [
                        Expanded(
                          child: CommonButton(
                              buttonColor: AppColors.primaryColor,
                              borderColor: Colors.transparent,
                              onPressed: () async {
                                Get.back();
                                openAppSettings();
                              },
                              buttonHeight: Get.height * 0.06,
                              buttonWidth: Get.width,
                              child: Text("Go Settings",
                                  style: AppTextStyle.semiBold16(
                                      color: AppColors.whiteColor))),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: CommonButton(
                              buttonColor: AppColors.whiteColor,
                              borderColor: AppColors.hintColor,
                              onPressed: () {
                                Get.back();
                              },
                              buttonHeight: Get.height * 0.06,
                              buttonWidth: Get.width,
                              child: Text("Cancel",
                                  style: AppTextStyle.semiBold16(
                                      color: AppColors.hintColor))),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ));
      return false;
    case PermissionStatus.provisional:
      return false;
  }
}