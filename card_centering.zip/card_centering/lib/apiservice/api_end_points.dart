import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:flutter/material.dart';
import 'package:logic_go_network/network/api_type.dart';

import '../apptheme/app_strings.dart';

class ApiEndPoint {
  // ============== Auth APIs =============== //
  static const registerWithMailUrl = "$baseUrl/auth/register-by-email";
  static const verifyOTPUrl = "$baseUrl/auth/verify-email-otp";
  static const resendOTPUrl = "$baseUrl/auth/resend-email-otp";
  static const loginUrl = "$baseUrl/auth/login-by-email";
  static const forgotPasswordUrl = "$baseUrl/auth/forgot-password";
  static const resetPasswordUrl = "$baseUrl/auth/reset-password";
  static const googleLoginUrl = "$baseUrl/auth/google-login";
  static const appleLoginUrl = "$baseUrl/auth/apple-login";

  // ============== User Profile APIs =============== //
  static const profileUrl = "$baseUrl/user/profile";
  static const changePasswordUrl = "$baseUrl/user/change-password";
  static const deleteAccountUrl = "$baseUrl/user/delete-account";

  // ============== Card Detect APIs =============== //
  static const createNewCardUrl = "$baseUrl/card-detect/add";

  static getAllDetectedCardsUrl(String query) =>
      "$baseUrl/card-detect/list?search=$query";

  static detectedCardDetailsUrl(String cardId) =>
      "$baseUrl/card-detect/detail/$cardId";

  static updateCardUrl(String cardId) => "$baseUrl/card-detect/update/$cardId";

  static favoriteCardUrl(String cardId) =>
      "$baseUrl/card-detect/toggle-favorite/$cardId";
  static const favoriteCardListUrl = "$baseUrl/card-detect/favorites";

  static deleteCardUrl(String cardId) => "$baseUrl/card-detect/delete/$cardId";
  static const addCardToCollection = '$baseUrl/card-detect/add-to-collection';

  // =============== Collection APIs ================= //

  static const collectionListUrl = "$baseUrl/collection/list";
  static const createCollectionUrl = "$baseUrl/collection/add";

  static fetchCollectionCards(String collectionId) =>
      "$baseUrl/card-detect/by-collection/$collectionId";

  static renameCollectionUrl(String collectionId) =>
      "$baseUrl/collection/update/$collectionId";

  static deleteCollectionUrl(String collectionId) =>
      "$baseUrl/collection/delete/$collectionId";
  static const removeCardUrl =
      "$baseUrl/card-detect/remove-card-from-collection";

  // ============== Support APIs =============== //
  static const createSupportUrl = "$baseUrl/support/support-request/add";
  static const getSupportUrl = "$baseUrl/support/support-request/list?status";
  static updateSupportUrl(String ticketId) =>
      "$baseUrl/support/support-request/$ticketId/status";
}

Future<Map<String, String>> requestHeader(
  APIType apiType, {
  bool? passRefreshToken,
}) async {
  debugPrint(
    'bearer token == ${await PrefManager().getStringData(key: accessToken)}',
  );
  return {
    if (apiType == APIType.protected)
      RequestHeaderKey.authorization:
          "Bearer ${await PrefManager().getStringData(key: accessToken)}",
  };
}

class RequestHeaderKey {
  static const contentType = "Content-Type";
  static const userAgent = "User-Agent";
  static const authToken = "Auth-Token";
  static const authorization = "Authorization";
}
