import 'dart:isolate';

import 'package:card_centering/model/response_model.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:logic_go_network/network/api_type.dart';
import 'package:logic_go_network/utils/failure.dart';

import '../apptheme/app_constants.dart';
import '../apptheme/app_strings.dart';
import 'api_end_points.dart';

final prefManager = PrefManager();

class ApiService {
  //Register API
  static Future<ResponseModel> registerApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.registerWithMailUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Verify OTP
  static Future<ResponseModel> verifyOtpApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.verifyOTPUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Resend OTP
  static Future<ResponseModel> resendOtpApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.resendOTPUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Login API
  static Future<ResponseModel> loginApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.loginUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Forgot Password API
  static Future<ResponseModel> forgotPasswordApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.forgotPasswordUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Reset Password API
  static Future<ResponseModel> resetPasswordApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.public,
      body,
      path: ApiEndPoint.resetPasswordUrl,
      headers: await requestHeader(APIType.public),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //User Profile API
  static Future<ResponseModel> userProfileApi({
    required Map<String, dynamic> body,
  }) async {
    final token = await prefManager.getStringData(key: accessToken);
    final response = await restClient.putFormData(
      APIType.protected,
      body,
      path: ApiEndPoint.profileUrl,
      headers: {RequestHeaderKey.authorization: "Bearer $token"},
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Fetch User Profile API
  static Future<ResponseModel> getUerProfileApi() async {
    final token = await prefManager.getStringData(key: accessToken);
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.profileUrl,
      headers: {RequestHeaderKey.authorization: "Bearer $token"},
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Change Password API
  static Future<ResponseModel> changePasswordApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.put(
      APIType.protected,
      body,
      path: ApiEndPoint.changePasswordUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Delete Account API
  static Future<ResponseModel> deleteUserApi() async {
    final response = await restClient.delete(
      APIType.protected,
      data: {"isPermanentlyDelete": true},
      path: ApiEndPoint.deleteAccountUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Create New Card API
  static Future<ResponseModel> createNewCardApi({
    required Map<String, dynamic> body,
    required SendPort sendPort,
  }) async {
    final response = await restClient.postFormData(
      APIType.protected,
      body,
      path: ApiEndPoint.createNewCardUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        sendPort.send(
          ResponseModel(
            message: result.message,
            body: result.body,
            status: result.status,
          ).toJson(),
        );
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        sendPort.send(
          ResponseModel(
            message: result.message,
            body: result.body,
            status: result.status,
          ).toJson(),
        );
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      sendPort.send(
        ResponseModel(message: finalError, body: null, status: false).toJson(),
      );
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Update Card API
  static Future<ResponseModel> updateCardApi({
    required Map<String, dynamic> body,
    required String cardId,
  }) async {
    final response = await restClient.putFormData(
      APIType.protected,
      body,
      path: ApiEndPoint.updateCardUrl(cardId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Favorite Toggle Card API
  static Future<ResponseModel> favoriteToggleCardApi({
    required String cardId,
  }) async {
    final response = await restClient.patch(
      APIType.protected,
      {},
      path: ApiEndPoint.favoriteCardUrl(cardId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Favorite List Card API
  static Future<ResponseModel> favoriteCardListApi() async {
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.favoriteCardListUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Delete Card API
  static Future<ResponseModel> deleteCardApi({required String cardId}) async {
    final response = await restClient.delete(
      APIType.protected,
      path: ApiEndPoint.deleteCardUrl(cardId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Detected Card List API
  static Future<ResponseModel> detectedCardListApi({
    required String query,
  }) async {
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.getAllDetectedCardsUrl(query),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Single Detected Card Details API
  static Future<ResponseModel> singleDetectedCardApi({
    required String cardId,
  }) async {
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.detectedCardDetailsUrl(cardId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Collection List API
  static Future<ResponseModel> collectionListApi() async {
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.collectionListUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Create Collection API
  static Future<ResponseModel> createCollectionApi({
    required String collectionName,
  }) async {
    final response = await restClient.post(
      APIType.protected,
      {"name": collectionName},
      path: ApiEndPoint.createCollectionUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Collection Cards List API
  static Future<ResponseModel> collectionCardsListApi({
    required String collectionId,
  }) async {
    final response = await restClient.get(
      APIType.protected,
      path: ApiEndPoint.fetchCollectionCards(collectionId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Update Collection API
  static Future<ResponseModel> updateCollectionApi({
    required String collectionId,
    required String collectionName,
  }) async {
    final response = await restClient.put(
      APIType.protected,
      {"name": collectionName},
      path: ApiEndPoint.renameCollectionUrl(collectionId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Delete Collection API
  static Future<ResponseModel> deleteCollectionApi({
    required String collectionId,
  }) async {
    final response = await restClient.delete(
      APIType.protected,
      path: ApiEndPoint.deleteCollectionUrl(collectionId),
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Remove Card From Collection API
  static Future<ResponseModel> removeCardApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.post(
      APIType.protected,
      body,
      path: ApiEndPoint.removeCardUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Save Card In Collection API
  static Future<ResponseModel> saveCardToCollection({
    required Map<String, dynamic> data,
  }) async {
    final response = await restClient.post(
      APIType.protected,
      data,
      path: ApiEndPoint.addCardToCollection,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Create Support Ticket API
  static Future<ResponseModel> createTicketApi({
    required Map<String, dynamic> body,
  }) async {
    final response = await restClient.postFormData(
      APIType.protected,
      body,
      path: ApiEndPoint.createSupportUrl,
      headers: await requestHeader(APIType.protected),
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }

  //Get Support Ticket API
  static Future<ResponseModel> getTicketApi({ required String status }) async {
    final token = await prefManager.getStringData(key: accessToken);
    final response = await restClient.get(
      APIType.protected,
      path: "${ApiEndPoint.getSupportUrl}=$status",
      headers: {RequestHeaderKey.authorization: "Bearer $token"},
    );
    ResponseModel result = ResponseModel.fromJson(response.data);
    try {
      if (result.status == true) {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      } else {
        return ResponseModel(
          message: result.message,
          body: result.body,
          status: result.status,
        );
      }
    } on Failure catch (e) {
      List<String> error = e.toString().split(': ');
      List<String> splitError = error[4].split(',');
      String finalError = splitError[0];
      return ResponseModel(message: finalError, body: null, status: false);
    }
  }
}
