import 'package:card_centering/localization/language/chinese_language.dart';
import 'package:card_centering/localization/language/english_language.dart';
import 'package:card_centering/localization/language/japanese_language.dart';
import 'package:card_centering/localization/language/spanish_language.dart';
import 'package:get/get.dart';

class Localization extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'ja_JP': JapaneseLang().japaneseLanguage,
    'en_US': EnglishLang().englishLanguage,
    'zh_CN': ChineseLang().chineseLanguage,
    'es_ES': SpanishLang().spanishLanguage,
  };
}
