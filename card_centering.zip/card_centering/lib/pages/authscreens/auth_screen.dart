import 'dart:io';

import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/pages/authscreens/login_page.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../apptheme/app_constants.dart';
import '../../controllers/authcontroller/auth_controller.dart';
import '../../widgets/common_widgets.dart';
import 'sign_up_page.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(AuthController());
    return Scaffold(
      body: GetBuilder<AuthController>(
        builder:
            (controller) => Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image:
                          Image.asset(
                            isDarkMode()
                                ? AppAssets.imgAuthBgDark
                                : AppAssets.imgAuthBg,
                          ).image,
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    children: [
                      Image.asset(AppAssets.imgCard),
                      SizedBox(height: 20.h),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Column(
                          children: [
                            Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(
                                    text: "${knowYour.tr} ",
                                    style: AppTextStyle.semiBold42(
                                      color:
                                          isDarkMode()
                                              ? AppColors.whiteColor
                                              : AppColors.black0D0C0C,
                                    ).copyWith(height: 0.9),
                                  ),
                                  TextSpan(
                                    text: "${cardsGrade.tr} ",
                                    style: AppTextStyle.semiBold42(
                                      color: AppColors.primaryPurple,
                                    ).copyWith(height: 0.9),
                                  ),
                                  TextSpan(
                                    text: beforeYouSubmit.tr,
                                    style: AppTextStyle.semiBold42(
                                      color:
                                          isDarkMode()
                                              ? AppColors.whiteColor
                                              : AppColors.black0D0C0C,
                                    ).copyWith(height: 0.9),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20.h),
                            Text(
                              aiPoweredCenteringScansInSecondsAvoidPSA9sGetMore10s
                                  .tr,
                              style: AppTextStyle.regular20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ).copyWith(height: 1.1),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 20.w,
                          right: 20.w,
                          bottom: 20.h,
                        ),
                        child: CommonButton(
                          radius: 10.r,
                          onPressed: () {
                            Get.find<AuthController>().clearAll();
                            showModalBottomSheet(
                              context: context,
                              builder: (context) {
                                return getStartBottomSheet();
                              },
                            );
                          },
                          buttonWidth: double.infinity,
                          buttonHeight: 55.h,
                          child: Text(
                            continueText.tr,
                            style: AppTextStyle.medium20(
                              color: AppColors.whiteColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: Platform.isIOS ? 20.h : 0),
                    ],
                  ),
                ),
                Obx(
                  () =>
                      controller.isShowLoader.value
                          ? showLoader()
                          : const SizedBox.shrink(),
                ),
              ],
            ),
      ),
    );
  }

  getStartBottomSheet() {
    return Container(
      decoration: BoxDecoration(
        color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(20.r),
          topLeft: Radius.circular(20.r),
        ),
      ),
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.transparent,
                ),
                padding: EdgeInsets.all(3.sp),
                child: Center(
                  child: SvgPicture.asset(
                    AppAssets.icClose,
                    colorFilter: ColorFilter.mode(
                      Colors.transparent,
                      BlendMode.srcIn,
                    ),
                  ),
                ),
              ),
              Text(
                getStarted.tr,
                style: AppTextStyle.semiBold26(
                  color: isDarkMode() ? AppColors.whiteColor : AppColors.black,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyF6F6F6,
                  ),
                  padding: EdgeInsets.all(10.r),
                  child: Center(
                    child: SvgPicture.asset(
                      AppAssets.icClose,
                      colorFilter: ColorFilter.mode(
                        isDarkMode() ? AppColors.whiteColor : AppColors.black,
                        BlendMode.srcIn,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12.sp),
          Text(
            get3FreeScansNoCreditCardKnowYourCardsCenteringInSeconds.tr,
            textAlign: TextAlign.center,
            style: AppTextStyle.regular18(
              color: isDarkMode() ? AppColors.grey9B9B9B : AppColors.grey878787,
            ),
          ),
          SizedBox(height: 20.h),
          CommonButton(
            buttonColor: AppColors.primaryPurple,
            buttonWidth: double.infinity,
            buttonHeight: 55.h,

            radius: 12.r,
            onPressed: () {
              Get.back();

              Get.to(
                () => LoginPage(),
                transition: Transition.rightToLeftWithFade,
              );
            },
            child: Text(
              signIn.tr,
              style: AppTextStyle.medium20(color: AppColors.whiteColor),
            ),
          ),
          SizedBox(height: 8.h),
          CommonButton(
            buttonWidth: double.infinity,
            buttonHeight: 55.h,
            buttonColor: Colors.transparent,
            borderColor: Colors.transparent,
            onPressed: () {
              Get.back();

              Get.to(
                () => SignUpPage(),
                transition: Transition.rightToLeftWithFade,
              );
            },
            child: Text(
              centerGradeAccount.tr,
              style: AppTextStyle.medium20(
                color:
                    isDarkMode() ? AppColors.grey9B9B9B : AppColors.black0D0C0C,
              ),
            ),
          ),
          SizedBox(height: 12.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Container(
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.greyE5E5E5,
                  height: 1.h,
                ),
              ),
              SizedBox(width: 10.w),
              Text(
                or.tr,
                style: AppTextStyle.regular18(color: AppColors.black888888),
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: Container(
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.greyE5E5E5,
                  height: 1.h,
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          CommonButton(
            buttonColor:
                isDarkMode() ? AppColors.grey2A2A2A : AppColors.whiteColor,
            radius: 12.r,
            borderColor:
                isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
            buttonWidth: double.infinity,
            onPressed: () async {
              await Get.find<AuthController>().signInWithGoogle();
            },
            buttonHeight: 55.h,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(AppAssets.icGoogle),
                SizedBox(width: 10.w),
                Text(
                  continueWithGoogle.tr,
                  style: AppTextStyle.medium20(
                    color:
                        isDarkMode()
                            ? AppColors.grey9B9B9B
                            : AppColors.grey6D6D6D,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: Platform.isIOS ? 12.h : 0),
          Platform.isIOS
              ? CommonButton(
                buttonColor:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.whiteColor,
                borderColor:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.borderColor,
                radius: 12.r,
                onPressed: () async {
                  await Get.find<AuthController>().signInWithApple();
                },
                buttonHeight: 55.h,
                buttonWidth: double.infinity,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      isDarkMode() ? AppAssets.icAppleWhite : AppAssets.icApple,
                    ),
                    SizedBox(width: 10.w),
                    Text(
                      continueWithApple.tr,
                      style: AppTextStyle.medium20(
                        color:
                            isDarkMode()
                                ? AppColors.grey9B9B9B
                                : AppColors.grey6D6D6D,
                      ),
                    ),
                  ],
                ),
              )
              : const SizedBox.shrink(),
          SizedBox(height: 25.h),
        ],
      ),
    );
  }
}
