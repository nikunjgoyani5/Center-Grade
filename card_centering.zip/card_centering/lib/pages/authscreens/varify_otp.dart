import 'dart:io';

import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/authcontroller/verify_otp_controller.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../../apptheme/app_colors.dart';
import '../../apptheme/app_constants.dart';
import '../../apptheme/app_textstyle.dart';
import '../../widgets/common_appbar.dart';
import '../../widgets/common_button.dart';

class VerifyOtp extends StatefulWidget {
  final bool isSignUp;
  final String emailId;

  const VerifyOtp({super.key, required this.isSignUp, required this.emailId});

  @override
  State<VerifyOtp> createState() => _VerifyOtpState();
}

class _VerifyOtpState extends State<VerifyOtp> {
  final verifyOtpController = Get.put(VerifyOtpController());

  @override
  void initState() {
    verifyOtpController.startTimer();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(
          title: '',
          leadingTap: () {
            verifyOtpController.stopTimer();
          },
        ),
        bottomNavigationBar: GetBuilder<VerifyOtpController>(
          builder:
              (controller) => Obx(
                () => Padding(
                  padding: EdgeInsets.only(
                    left: 20.w,
                    right: 20.w,
                    bottom: Platform.isIOS ? 40.h : 20.h,
                  ),
                  child:
                      controller.isShowLoader.value
                          ? Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CircularProgressIndicator(
                                color: AppColors.primaryPurple,
                              ),
                            ],
                          )
                          : CommonButton(
                            buttonColor:
                                // controller.otpController.text.isEmpty
                                //     ? isDarkMode()
                                //         ? AppColors.disableColorDark
                                //         : AppColors.disableColor
                                //     :
                                AppColors.primaryPurple,
                            buttonWidth: double.infinity,
                            buttonHeight: 55.h,
                            radius: 12.r,
                            onPressed: () async {
                              await controller.verifyOtpTapped(
                                widget.isSignUp,
                                widget.emailId,
                              );
                            },
                            child: Text(
                              verifyOTP.tr,
                              style: AppTextStyle.medium20(
                                color:
                                    /*controller.otpController.text.isEmpty
                                        ? AppColors.whiteColor.withValues(
                                          alpha: 0.4,
                                        )
                                        : */
                                    AppColors.whiteColor,
                              ),
                            ),
                          ),
                ),
              ),
        ),
        body: GetBuilder<VerifyOtpController>(
          builder:
              (controller) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 20.h),
                    Text(
                      verifyYourCode.tr,
                      style: AppTextStyle.semiBold30(
                        color:
                            isDarkMode()
                                ? AppColors.whiteColor
                                : AppColors.black,
                      ),
                    ),
                    SizedBox(height: 10.h),
                    Text(
                      weJustEmailedYouA6DigitCodeEnterItBelowToContinue.tr,
                      style: AppTextStyle.regular20(
                        color:
                            isDarkMode()
                                ? AppColors.whiteColor
                                : AppColors.black0D0C0C,
                      ),
                    ),
                    SizedBox(height: 30.h),
                    PinCodeTextField(
                      appContext: context,
                      length: 6,
                      controller: controller.otpController,
                      keyboardType: TextInputType.number,
                      animationType: AnimationType.slide,
                      onSubmitted: (value) {
                        FocusScope.of(context).unfocus();
                        controller.verifyOtpTapped(
                          widget.isSignUp,
                          widget.emailId,
                        );
                      },
                      onCompleted: (value) {
                        FocusScope.of(context).unfocus();
                        controller.verifyOtpTapped(
                          widget.isSignUp,
                          widget.emailId,
                        );
                      },
                      textStyle: AppTextStyle.semiBold20(
                        color:
                            isDarkMode()
                                ? AppColors.whiteColor
                                : AppColors.black0D0C0C,
                      ),
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      pinTheme: PinTheme(
                        inactiveColor:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                        shape: PinCodeFieldShape.box,
                        activeColor: AppColors.primaryPurple,
                        selectedColor: AppColors.primaryPurple,
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                    ),
                    Center(
                      child: Obx(
                        () =>
                            controller.seconds.value != 0
                                ? Text(
                                  "00:${controller.seconds.value.toString().padLeft(2, '0')}",
                                  style: AppTextStyle.medium20(
                                    color: AppColors.primaryPurple,
                                  ),
                                )
                                : Text.rich(
                                  TextSpan(
                                    children: [
                                      TextSpan(
                                        text: '${didntGetTheCode.tr} ',
                                        style: AppTextStyle.medium20(
                                          color: AppColors.grey9B9B9B,
                                        ),
                                      ),
                                      TextSpan(
                                        text: resendOTP.tr,
                                        recognizer:
                                            TapGestureRecognizer()
                                              ..onTap = () async {
                                                controller.otpController
                                                    .clear();
                                                controller.seconds.value = 60;
                                                controller.startTimer();
                                                await controller.resendOtp(
                                                  emailId: widget.emailId,
                                                );
                                              },
                                        style: AppTextStyle.medium20(
                                          color: AppColors.primaryPurple,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                      ),
                    ),
                  ],
                ),
              ),
        ),
      ),
    );
  }
}
