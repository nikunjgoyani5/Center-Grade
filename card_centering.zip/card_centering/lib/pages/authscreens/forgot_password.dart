import 'dart:io';

import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/authcontroller/auth_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/common_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../apptheme/app_colors.dart';
import '../../apptheme/app_constants.dart';
import '../../apptheme/app_textstyle.dart';
import '../../widgets/common_button.dart';

class ForgotPassword extends StatelessWidget {
  const ForgotPassword({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
      appBar: commonAppbar(title: ''),
      bottomNavigationBar: GetBuilder<AuthController>(
        builder:
            (controller) => Obx(
              () => Padding(
                padding: EdgeInsets.only(
                  left: 20.w,
                  right: 20.w,
                  bottom: Platform.isIOS ? 40.h : 20.h,
                ),
                child:
                    controller.isShowLoader.value
                        ? Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircularProgressIndicator(
                              color: AppColors.primaryPurple,
                            ),
                          ],
                        )
                        : CommonButton(
                          buttonColor: AppColors.primaryPurple,
                          buttonWidth: double.infinity,
                          buttonHeight: 55.h,
                          radius: 12.r,
                          onPressed: () async {
                            await controller.forgotPasswordTapped();
                          },
                          child: Text(
                            sendCode.tr,
                            style: AppTextStyle.medium20(
                              color: AppColors.whiteColor,
                            ),
                          ),
                        ),
              ),
            ),
      ),
      body: GetBuilder<AuthController>(
        builder:
            (controller) => Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20.h),
                  Text(
                    forgotPassword.tr,
                    style: AppTextStyle.semiBold30(
                      color:
                          isDarkMode() ? AppColors.whiteColor : AppColors.black,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    weWillEmailYouAOneTimeCodeToResetYourPassword.tr,
                    style: AppTextStyle.regular20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    emailAddress.tr,
                    style: AppTextStyle.medium20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  commonTextfield(
                    controller: controller.emailController,
                    hintText: enterYourEmailAddress.tr,
                  ),
                ],
              ),
            ),
      ),
    );
  }
}
