import 'dart:io';

import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/authcontroller/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/gestures.dart';
import '../../apptheme/app_constants.dart';
import '../../widgets/common_appbar.dart';
import '../../widgets/common_button.dart';
import '../../widgets/common_textfield.dart';
import 'login_page.dart';

class SignUpPage extends StatelessWidget {
  const SignUpPage({super.key});

  @override
  Widget build(BuildContext context) {
    final authController = Get.find<AuthController>();
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(
          title: '',
          action: [
            GestureDetector(
              onTap: () {
                authController.clearAll();
                Get.to(
                  () => LoginPage(),
                  transition: Transition.rightToLeftWithFade,
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30.r),
                  color:
                      isDarkMode()
                          ? AppColors.black1E1E1E
                          : AppColors.greyF5F5F5,
                  border: Border.all(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                ),
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 8.h),
                child: Text(
                  signIn.tr,
                  style: AppTextStyle.medium20(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ),
            ),
            SizedBox(width: 20.w),
          ],
        ),
        bottomNavigationBar: GetBuilder<AuthController>(
          builder:
              (controller) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Obx(
                  () => Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      controller.isShowLoader.value
                          ? CircularProgressIndicator(
                            color: AppColors.primaryPurple,
                          )
                          : CommonButton(
                            buttonWidth: double.infinity,
                            buttonHeight: 55.h,
                            radius: 12.r,
                            onPressed: () async {
                              await controller.signUpTapped();
                            },
                            child: Text(
                              signUp.tr,
                              style: AppTextStyle.medium20(
                                color: AppColors.whiteColor,
                              ),
                            ),
                          ),
                      SizedBox(height: 15.h),
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          controller.onCheckBoxChange();
                        },
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Checkbox(
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              checkColor: AppColors.whiteColor,
                              side: BorderSide(
                                color:
                                    isDarkMode()
                                        ? AppColors.grey2A2A2A
                                        : AppColors.borderD9D9D9,
                              ),
                              visualDensity: VisualDensity(
                                horizontal: VisualDensity.minimumDensity,
                                vertical: VisualDensity.minimumDensity,
                              ),
                              value: controller.isChecked,
                              activeColor: AppColors.primaryPurple,
                              onChanged: (value) {
                                controller.onCheckBoxChange();
                              },
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4.r),
                              ),
                            ),
                            SizedBox(width: 10.w),
                            Text.rich(
                              textAlign: TextAlign.center,
                              TextSpan(
                                children: [
                                  TextSpan(
                                    text: iHaveReadAndIAgreeToThe.tr,
                                    style: AppTextStyle.medium16(
                                      color: AppColors.grey9B9B9B,
                                    ),
                                  ),
                                  TextSpan(
                                    text: " ${termsOfUse.tr}",
                                    style: AppTextStyle.medium16(
                                      color: AppColors.primaryPurple,
                                    ),
                                    recognizer:
                                        TapGestureRecognizer()
                                          ..onTap = () {
                                            launchUrl(
                                              Uri.parse(
                                                'https://center-grade.blogspot.com/2025/05/terms-conditions.html',
                                              ),
                                            );
                                          },
                                  ),
                                  TextSpan(
                                    text: '\n${and.tr} ',
                                    style: AppTextStyle.medium16(
                                      color: AppColors.grey9B9B9B,
                                    ),
                                  ),
                                  TextSpan(
                                    text: privacyPolicy.tr,
                                    style: AppTextStyle.medium16(
                                      color: AppColors.primaryPurple,
                                    ),
                                    recognizer:
                                        TapGestureRecognizer()
                                          ..onTap = () {
                                            launchUrl(
                                              Uri.parse(
                                                'https://center-grade.blogspot.com/2025/05/privacy-policy.html',
                                              ),
                                            );
                                          },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: Platform.isIOS ? 40.h : 20.h),
                    ],
                  ),
                ),
              ),
        ),
        body: GetBuilder<AuthController>(
          builder:
              (authController) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 20.h),
                      Text(
                        centerGradeAccount.tr,
                        style: AppTextStyle.semiBold30(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black,
                        ),
                      ),
                      SizedBox(height: 10.h),
                      Text(
                        findOutIfYourCardIsCenteredEnoughForAPSA10inSeconds.tr,
                        style: AppTextStyle.regular20(
                          color:
                              isDarkMode()
                                  ? AppColors.grey9B9B9B
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 20.h),
                      Text(
                        fullName.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      commonTextfield(
                        controller: authController.nameController,
                        hintText: enterYourFullName.tr,
                      ),
                      SizedBox(height: 15.h),
                      Text(
                        emailAddress.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      commonTextfield(
                        keyboardType: TextInputType.emailAddress,
                        controller: authController.emailController,
                        hintText: enterYourEmailAddress.tr,
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        usedToLoginAndAAccessYourScansSecurely.tr,
                        style: AppTextStyle.medium18(
                          color: AppColors.grey9B9B9B,
                        ),
                      ),
                      SizedBox(height: 15.h),
                      Text(
                        password.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      GetBuilder<AuthController>(
                        builder:
                            (controller) => commonTextfield(
                              isObscure: !controller.isPasswordVisible,
                              suffixWidget: Column(
                                mainAxisAlignment: MainAxisAlignment.center,

                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      controller.passwordVisibility();
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                      ),
                                      padding: EdgeInsets.all(8),
                                      child: SvgPicture.asset(
                                        controller.isPasswordVisible
                                            ? AppAssets.icVisible
                                            : AppAssets.icVisibleOff,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              controller: authController.passwordController,
                              hintText: enterYourPassword.tr,
                            ),
                      ),
                      SizedBox(height: 15.h),
                      Text(
                        confirmPassword.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      GetBuilder<AuthController>(
                        builder:
                            (controller) => commonTextfield(
                              isObscure: !controller.isConfirmPasswordVisible,
                              suffixWidget: Column(
                                mainAxisAlignment: MainAxisAlignment.center,

                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      controller.confirmPasswordVisibility();
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                      ),
                                      padding: EdgeInsets.all(8),
                                      child: SvgPicture.asset(
                                        controller.isConfirmPasswordVisible
                                            ? AppAssets.icVisible
                                            : AppAssets.icVisibleOff,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              controller:
                                  authController.confirmPasswordController,
                              hintText: reEnterPassword.tr,
                            ),
                      ),
                      SizedBox(height: 20.h),
                    ],
                  ),
                ),
              ),
        ),
      ),
    );
  }
}
