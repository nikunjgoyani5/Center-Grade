import 'dart:io';

import 'package:card_centering/pages/dashboard/pages/profilemodule/profile_page.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../../apptheme/app_assets.dart';
import '../../apptheme/app_colors.dart';
import '../../apptheme/app_constants.dart';
import '../../apptheme/app_strings.dart';
import '../../apptheme/app_textstyle.dart';
import '../../controllers/onboardcontroller/onboard_controller.dart';
import '../../prefmanage/pref_manage.dart';

class OnboardScreen extends StatelessWidget {
  OnboardScreen({super.key});

  final onboardController = Get.put(OnboardController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
      // extendBodyBehindAppBar: true,
      body: GetBuilder<OnboardController>(
        builder:
            (controller) => Container(
              decoration: BoxDecoration(
                color:
                    isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
                image: DecorationImage(
                  image:
                      Image.asset(
                        isDarkMode()
                            ? AppAssets.imgOnboardBgDark
                            : AppAssets.imgOnboardBg,
                      ).image,
                  fit: BoxFit.fill,
                ),
              ),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Column(
                    children: [
                      Expanded(
                        flex: 5,
                        child: Container(
                          color: Colors.transparent,
                          child: PageView.builder(
                            controller: controller.pageController,
                            itemCount: controller.onboardImages.length,
                            onPageChanged: (value) {
                              controller.onPageChanged(value);
                            },
                            itemBuilder: (context, index) {
                              return Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(height: 90.h),
                                    Image.asset(
                                      controller.onboardImages[index],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 3,
                        child: Container(
                          color: Colors.transparent,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            child: Column(
                              children: [
                                AnimatedSmoothIndicator(
                                  activeIndex: onboardController.currentPage,
                                  count: 3,
                                  effect: WormEffect(
                                    activeDotColor: AppColors.primaryPurple,
                                    dotColor:
                                        isDarkMode()
                                            ? AppColors.grey2A2A2A
                                            : AppColors.borderF4E7FF,
                                    dotHeight: 15.h,
                                    dotWidth: 15.w,
                                    spacing: 8.w,
                                  ),
                                ),
                                SizedBox(height: 35.h),
                                Text(
                                  onboardController
                                      .onboardTitle[onboardController
                                      .currentPage],
                                  textAlign: TextAlign.center,
                                  style: AppTextStyle.semiBold40(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ).copyWith(height: 1.1),
                                ),
                                SizedBox(height: 15.h),
                                Text(
                                  onboardController
                                      .onboardDesc[onboardController
                                      .currentPage],
                                  textAlign: TextAlign.center,
                                  style: AppTextStyle.regular20(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ).copyWith(height: 1.1),
                                ),
                                const Spacer(),
                                Padding(
                                  padding: EdgeInsets.only(bottom: 15.h),
                                  child: CommonButton(
                                    radius: 10.r,
                                    buttonHeight: 55.h,
                                    buttonWidth: double.infinity,
                                    onPressed: () {
                                      if (onboardController.currentPage == 2) {
                                        PrefManager().setBoolData(
                                          key: isFirst,
                                          value: true,
                                        );
                                        Get.to(
                                          () => ProfilePage(),
                                          transition:
                                              Transition.rightToLeftWithFade,
                                        );
                                      } else {
                                        onboardController.pageController
                                            .nextPage(
                                              duration: 300.milliseconds,
                                              curve: Curves.easeInOut,
                                            );
                                      }
                                    },
                                    child: Text(
                                      onboardController.currentPage == 2
                                          ? startUsingCenterGrade.tr
                                          : next.tr,
                                      style: AppTextStyle.medium20(
                                        color: AppColors.whiteColor,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: Platform.isIOS ? 20.h : 0),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Positioned(
                    right: 25.w,
                    top: 50.h,
                    child: GestureDetector(
                      onTap: () {
                        PrefManager().setBoolData(key: isFirst, value: true);
                        Get.to(
                          () => ProfilePage(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color:
                              isDarkMode()
                                  ? AppColors.black1E1E1E
                                  : AppColors.whiteColor,
                          borderRadius: BorderRadius.circular(30.r),
                          border: Border.all(
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyEBEBEB,
                          ),
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 12.w,
                          vertical: 6.h,
                        ),
                        child: Text(
                          skipForNow.tr,
                          style: AppTextStyle.medium18(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
      ),
    );
  }
}
