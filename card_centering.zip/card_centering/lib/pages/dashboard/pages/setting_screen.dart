import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/dashboard_controller.dart';
import 'package:card_centering/controllers/dashboardcontrollers/setting_controller.dart';
import 'package:card_centering/controllers/profilecontroller/profile_controller.dart';
import 'package:card_centering/pages/dashboard/pages/drawerscreen/favorite_screen.dart';
import 'package:card_centering/pages/dashboard/pages/settingpage/supportpage/get_support.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../../../apptheme/app_assets.dart';
import '../../../apptheme/app_strings.dart';
import '../../../widgets/common_appbar.dart';
import 'settingpage/change_password.dart';
import 'settingpage/edit_profile.dart';
import 'settingpage/faq_screen.dart';
import 'settingpage/language_page.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingScreen extends StatelessWidget {
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final profileController = Get.find<ProfileController>();
    return Scaffold(
      backgroundColor:
          isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
      appBar: commonAppbar(title: setting.tr, isShowBackButton: false),
      body: GetBuilder<SettingController>(
        builder:
            (controller) => Stack(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20.h),
                        GetBuilder<ProfileController>(
                          builder:
                              (pController) => Center(
                                child: Column(
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        showDialog(
                                          context: context,
                                          builder:
                                              (context) => pickImageDialog(
                                                onCameraTap: () async {
                                                  Get.back();
                                                  await pController
                                                      .pickUserProfile(
                                                        source:
                                                            ImageSource.camera,
                                                        isSetting: true,
                                                      );
                                                },
                                                onGalleryTap: () async {
                                                  Get.back();
                                                  await pController
                                                      .pickUserProfile(
                                                        source:
                                                            ImageSource.gallery,
                                                        isSetting: true,
                                                      );
                                                },
                                              ),
                                        );
                                      },
                                      child: SizedBox(
                                        child: Stack(
                                          alignment: Alignment.bottomRight,
                                          clipBehavior: Clip.none,
                                          children: [
                                            pController
                                                    .userProfileImage
                                                    .isNotEmpty
                                                ? ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                        55.r,
                                                      ),
                                                  child: Container(
                                                    width: 110.r,
                                                    height: 110.r,
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      border: Border.all(
                                                        color:
                                                            AppColors
                                                                .greyEBEBEB,
                                                      ),
                                                      color:
                                                          isDarkMode()
                                                              ? AppColors
                                                                  .grey2A2A2A
                                                              : AppColors
                                                                  .greyEBEBEB,
                                                    ),
                                                    child: Image.network(
                                                      pController
                                                          .userProfileImage,
                                                      fit: BoxFit.cover,
                                                      loadingBuilder: (
                                                        context,
                                                        child,
                                                        loadingProgress,
                                                      ) {
                                                        if (loadingProgress ==
                                                            null) {
                                                          return ClipOval(
                                                            child: child,
                                                          ); // Fully loaded image
                                                        }
                                                        return Shimmer.fromColors(
                                                          baseColor:
                                                              isDarkMode()
                                                                  ? AppColors
                                                                      .grey2A2A2A
                                                                  : Colors
                                                                      .grey[300]!,
                                                          highlightColor:
                                                              isDarkMode()
                                                                  ? AppColors
                                                                      .grey9B9B9B
                                                                  : Colors
                                                                      .grey[100]!,
                                                          child: Container(
                                                            decoration:
                                                                const BoxDecoration(
                                                                  shape:
                                                                      BoxShape
                                                                          .circle,
                                                                  color:
                                                                      Colors
                                                                          .grey,
                                                                ),
                                                          ),
                                                        );
                                                      },
                                                      errorBuilder: (
                                                        context,
                                                        error,
                                                        stackTrace,
                                                      ) {
                                                        return ClipOval(
                                                          child:
                                                              SvgPicture.asset(
                                                                AppAssets
                                                                    .icProfile,
                                                                fit:
                                                                    BoxFit
                                                                        .cover,
                                                              ),
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                )
                                                : CircleAvatar(
                                                  radius: 55.r,
                                                  backgroundColor:
                                                      isDarkMode()
                                                          ? AppColors.grey2A2A2A
                                                          : AppColors
                                                              .greyEBEBEB,
                                                  child: SvgPicture.asset(
                                                    AppAssets.icProfile,
                                                  ),
                                                ),
                                            Positioned(
                                              // right: -12.w,
                                              bottom: -2.h,
                                              child: GestureDetector(
                                                onTap: () {
                                                  showDialog(
                                                    context: context,
                                                    builder:
                                                        (
                                                          context,
                                                        ) => pickImageDialog(
                                                          onCameraTap: () async {
                                                            Get.back();
                                                            await pController
                                                                .pickUserProfile(
                                                                  source:
                                                                      ImageSource
                                                                          .camera,
                                                                  isSetting:
                                                                      true,
                                                                );
                                                          },
                                                          onGalleryTap: () async {
                                                            Get.back();
                                                            await pController
                                                                .pickUserProfile(
                                                                  source:
                                                                      ImageSource
                                                                          .gallery,
                                                                  isSetting:
                                                                      true,
                                                                );
                                                          },
                                                        ),
                                                  );
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color:
                                                        isDarkMode()
                                                            ? AppColors
                                                                .black121212
                                                            : Colors.white,
                                                    shape: BoxShape.circle,
                                                  ),
                                                  padding: EdgeInsets.all(4.r),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color:
                                                          isDarkMode()
                                                              ? AppColors
                                                                  .grey2F2F2F
                                                              : AppColors
                                                                  .black0D0C0C,
                                                    ),
                                                    padding: EdgeInsets.all(
                                                      5.r,
                                                    ),
                                                    child: SvgPicture.asset(
                                                      AppAssets.icCameraWhite,
                                                      height: 14,
                                                      width: 14,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height:
                                          pController.userFullName.isEmpty
                                              ? 0
                                              : 15.h,
                                    ),
                                    pController.userFullName.isEmpty
                                        ? const SizedBox.shrink()
                                        : Text(
                                          pController.userFullName,
                                          style: AppTextStyle.semiBold22(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C,
                                          ),
                                        ),
                                    pController.userEmailId.isEmpty
                                        ? const SizedBox.shrink()
                                        : Text(
                                          pController.userEmailId,
                                          style: AppTextStyle.semiBold22(
                                            color: AppColors.grey9B9B9B,
                                          ),
                                        ),
                                  ],
                                ),
                              ),
                        ),
                        SizedBox(height: 20.h),
                        Center(
                          child: CommonButton(
                            buttonColor:
                                isDarkMode()
                                    ? AppColors.black1E1E1E
                                    : AppColors.whiteFAFAFA,
                            radius: 50.r,
                            borderColor:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyEBEBEB,
                            onPressed: () {
                              Get.to(
                                () => EditProfile(
                                  userImage: profileController.userProfileImage,
                                  userName: profileController.userFullName,
                                  userBirthday:
                                      profileController
                                          .userProfile
                                          ?.dateOfBirth ??
                                      DateTime.now(),
                                ),
                                transition: Transition.rightToLeftWithFade,
                              );
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: 15.w,
                                vertical: 8.h,
                              ),
                              child: Text(
                                editProfile.tr,
                                style: AppTextStyle.medium20(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 15.h),
                        Text(
                          general.tr,
                          style: AppTextStyle.medium20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8.r),
                                    color: AppColors.primaryPurple,
                                  ),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 12.w,
                                    vertical: 12.h,
                                  ),
                                  child: SvgPicture.asset(
                                    AppAssets.icDarkMode,
                                    height: 20,
                                    width: 20,
                                  ),
                                ),
                                SizedBox(width: 10.w),
                                Text(
                                  darkMode.tr,
                                  style: AppTextStyle.medium20(
                                    color:
                                        isDarkMode()
                                            ? AppColors.grey888888
                                            : AppColors.black0D0C0C,
                                  ),
                                ),
                              ],
                            ),
                            Switch(
                              value: !controller.isLightMode,
                              // value: true,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              inactiveTrackColor:
                                  isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.borderD9D9D9,
                              trackOutlineColor: WidgetStatePropertyAll(
                                Colors.transparent,
                              ),
                              thumbColor: WidgetStatePropertyAll(Colors.white),
                              activeTrackColor: AppColors.primaryPurple,
                              onChanged: (value) {
                                Get.changeThemeMode(
                                  context.isDarkMode
                                      ? ThemeMode.light
                                      : ThemeMode.dark,
                                );
                                controller.setThemeMode(
                                  value: context.isDarkMode ? true : false,
                                );
                                controller.getThemeMode();
                                controller.update();
                                Get.find<DashboardController>().update();
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 5.h),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        SizedBox(height: 5.h),
                        settingTile(
                          leadingIcon: AppAssets.icFavorite,
                          title: favorites.tr,
                          onTap: () {
                            Get.to(
                              () => FavoriteScreen(),
                              transition: Transition.rightToLeftWithFade,
                            );
                          },
                        ),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        // settingTile(
                        //   leadingIcon: AppAssets.icTutorial,
                        //   title: appTutorial.tr,
                        //   onTap: () {
                        //     Get.find<DashboardController>().currentIndex = 0;
                        //     Get.find<DashboardController>().update();
                        //   },
                        // ),
                        // Divider(
                        //   color:
                        //       isDarkMode()
                        //           ? AppColors.grey2A2A2A
                        //           : AppColors.greyEBEBEB,
                        // ),
                        settingTile(
                          leadingIcon: AppAssets.icLanguage,
                          title: language.tr,
                          onTap: () {
                            Get.to(
                              () => LanguagePage(),
                              transition: Transition.rightToLeftWithFade,
                            );
                          },
                        ),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        FirebaseAuth.instance.currentUser != null
                            ? const SizedBox.shrink()
                            : settingTile(
                              leadingIcon: AppAssets.icChangePass,
                              title: changePass.tr,
                              onTap: () {
                                controller.oldPassController.clear();
                                controller.newPassController.clear();
                                controller.confirmNewPassController.clear();
                                Get.to(
                                  () => ChangePassword(),
                                  transition: Transition.rightToLeftWithFade,
                                );
                              },
                            ),
                        FirebaseAuth.instance.currentUser != null
                            ? const SizedBox.shrink()
                            : Divider(
                              color:
                                  isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyEBEBEB,
                            ),
                        settingTile(
                          leadingIcon: AppAssets.icDelete,
                          title: deleteAccount.tr,
                          onTap: () {
                            showDeleteAccountDialog(
                              context,
                              onDeleteTap: () async {
                                Get.back();
                                Future.delayed(150.milliseconds, () async {
                                  await controller.deleteAccountApi();
                                });
                              },
                            );
                          },
                        ),
                        SizedBox(height: 15.h),

                        Text(
                          aboutUs.tr,
                          style: AppTextStyle.medium20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        settingTile(
                          leadingIcon: AppAssets.icShare,
                          title: share.tr,
                          onTap: () {
                            Share.share(
                              "${letMeReCommand.tr}  https://play.google.com/store/apps/details?id=com.center.grade",
                            );
                          },
                        ),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        settingTile(
                          leadingIcon: AppAssets.icContact,
                          title: contactUs.tr,
                          onTap: () async {
                            Get.to(
                              () => GetSupportScreen(),
                              transition: Transition.rightToLeftWithFade,
                            );
                            // Uri uri = Uri.parse(
                            //   "mailto:admin@centergrade.com?subject=Center Grade Support",
                            // );
                            // await launchUrl(uri);
                          },
                        ),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        settingTile(
                          leadingIcon: AppAssets.icPrivacy,
                          title: privacyPolicy.tr,
                          onTap: () async {
                            await launchUrl(
                              Uri.parse(
                                'https://center-grade.blogspot.com/2025/05/privacy-policy.html',
                              ),
                            );
                          },
                        ),
                        Divider(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        settingTile(
                          leadingIcon: AppAssets.icFaqSetting,
                          title: faq.tr,
                          onTap: () {
                            Get.to(
                              () => FaqScreen(),
                              transition: Transition.rightToLeftWithFade,
                            );
                          },
                        ),
                        SizedBox(height: 25.h),
                      ],
                    ),
                  ),
                ),

                Obx(
                  () =>
                      controller.isShowLoader.value
                          ? showLoader()
                          : const SizedBox.shrink(),
                ),
              ],
            ),
      ),
    );
  }

  pickImageDialog({
    required VoidCallback onCameraTap,
    required VoidCallback onGalleryTap,
  }) {
    return AlertDialog(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
      insetPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onCameraTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),

                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icCamera),
                          SizedBox(height: 10.h),
                          Text(
                            takeAPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.w),
              Expanded(
                child: GestureDetector(
                  onTap: onGalleryTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icGallery),
                          SizedBox(height: 10.h),
                          Text(
                            selectPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  settingTile({
    required String leadingIcon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GetBuilder<SettingController>(
      builder:
          (controller) => GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: onTap,
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 5.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.r),
                          color: AppColors.primaryPurple,
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 12.w,
                          vertical: 12.h,
                        ),
                        child: SvgPicture.asset(
                          leadingIcon,
                          height: 20,
                          width: 20,
                          colorFilter: ColorFilter.mode(
                            AppColors.whiteColor,
                            BlendMode.srcIn,
                          ),
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Text(
                        title,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.grey888888
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                    ],
                  ),
                  SvgPicture.asset(
                    isDarkMode()
                        ? AppAssets.icArrowRightDark
                        : AppAssets.icArrowRight,
                  ),
                ],
              ),
            ),
          ),
    );
  }

  showDeleteAccountDialog(
    BuildContext context, {
    required VoidCallback onDeleteTap,
  }) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          titlePadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.r),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
          backgroundColor:
              isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                deleteAccount.tr,
                style: AppTextStyle.semiBold24(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyF6F6F6,
                  ),
                  padding: EdgeInsets.all(10.r),
                  child: Center(
                    child: SvgPicture.asset(
                      AppAssets.icClose,
                      colorFilter: ColorFilter.mode(
                        isDarkMode() ? AppColors.whiteColor : AppColors.black,
                        BlendMode.srcIn,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                deleteWarning.tr,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
              ),
              // SizedBox(height: 16),
              // Text('Deleting your account will:'),
              // SizedBox(height: 8),
              // Text(
              //   '- Permanently remove your profile, settings, and preferences',
              // ),
              // Text('- Erase all your data associated with this account'),
              // Text('- Sign you out from all devices'),
              // SizedBox(height: 16),
              // Text(
              //   'This action cannot be undone.',
              //   style: TextStyle(
              //     color: Colors.red,
              //     fontWeight: FontWeight.bold,
              //   ),
              // ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Get.back();
              },
              child: Text(
                cancel.tr,
                style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
              ),
            ),
            CommonButton(
              buttonColor: AppColors.redColor,
              onPressed: onDeleteTap,
              child: Text(
                delete.tr,
                style: AppTextStyle.medium20(color: AppColors.whiteColor),
              ),
            ),
          ],
        );
      },
    );
  }
}
