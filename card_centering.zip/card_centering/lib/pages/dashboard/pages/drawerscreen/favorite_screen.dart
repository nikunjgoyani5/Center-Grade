import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:card_centering/widgets/shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';
import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/common_appbar.dart';

class FavoriteScreen extends StatefulWidget {
  const FavoriteScreen({super.key});

  @override
  State<FavoriteScreen> createState() => _FavoriteScreenState();
}

class _FavoriteScreenState extends State<FavoriteScreen> {
  @override
  void initState() {
    Get.find<HomeController>().favoriteCardListApi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Get.find<HomeController>();
    return Scaffold(
      backgroundColor:
          isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
      appBar: commonAppbar(title: favorites.tr),
      body: GetBuilder<HomeController>(
        builder:
            (controller) => Obx(
              () =>
                  controller.isFavLoader.value
                      ? showFavShimmer()
                      : controller.favCardList.isEmpty
                      ? Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                isDarkMode()
                                    ? AppAssets.icEmptyFavDark
                                    : AppAssets.icEmptyFav,
                              ),
                              Text(
                                noFavoritesYet.tr,
                                style: AppTextStyle.medium24(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                              SizedBox(height: 10.h),
                              Text(
                                tapTheStar.tr,
                                textAlign: TextAlign.center,
                                style: AppTextStyle.medium17(
                                  color: AppColors.grey9B9B9B,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                      : GridView.builder(
                        padding: EdgeInsets.only(
                          left: 20.w,
                          right: 20.w,
                          top: 10.h,
                        ),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 15,
                          mainAxisSpacing: 15,
                          childAspectRatio: 5 / 4,
                        ),
                        itemCount: controller.favCardList.length,
                        itemBuilder: (context, index) {
                          final favCardData = controller.favCardList[index];
                          return Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.r),
                              color:
                                  isDarkMode()
                                      ? AppColors.black1E1E1E
                                      : AppColors.whiteColor,
                              border: Border.all(
                                color:
                                    isDarkMode()
                                        ? AppColors.grey2A2A2A
                                        : AppColors.greyEBEBEB,
                              ),
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 15.w,
                              vertical: 15.h,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    // Image.asset(
                                    //   AppAssets.imgPlaceHolder,
                                    //   height: 50.h,
                                    //   width: 50.w,
                                    // ),
                                    Image.network(
                                      favCardData.frontImageUrl ?? '',
                                      height: 55.h,
                                      width: 45.w,
                                      loadingBuilder: (
                                        context,
                                        child,
                                        loadingProgress,
                                      ) {
                                        if (loadingProgress == null) {
                                          return child;
                                        }
                                        return Shimmer.fromColors(
                                          baseColor:
                                              isDarkMode()
                                                  ? AppColors.grey2A2A2A
                                                  : Colors.grey[300]!,
                                          highlightColor:
                                              isDarkMode()
                                                  ? AppColors.grey9B9B9B
                                                  : Colors.grey[100]!,
                                          child: Container(
                                            height: 60.h,
                                            width: 45.w,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(8.r),
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.grey2A2A2A
                                                      : AppColors.whiteColor,
                                            ),
                                          ),
                                        );
                                      },
                                      errorBuilder: (
                                        context,
                                        error,
                                        stackTrace,
                                      ) {
                                        return Image.asset(
                                          AppAssets.imgPlaceHolder,
                                          height: 50.h,
                                          width: 50.w,
                                          fit: BoxFit.cover,
                                        );
                                      },
                                    ),
                                    GestureDetector(
                                      onTap: () async {
                                        await controller.favoriteCardApi(
                                          cardId: favCardData.id ?? '',
                                        );
                                      },
                                      child: SvgPicture.asset(
                                        AppAssets.icFavFilled,
                                        height: 20,
                                        width: 20,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 15.h),
                                Text(
                                  favCardData.priceCheckerDetails!.name!.isEmpty
                                      ? "Card"
                                      : favCardData.priceCheckerDetails?.name ??
                                          'Card',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTextStyle.medium22(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
            ),
      ),
    );
  }
}
