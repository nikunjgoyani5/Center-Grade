import 'dart:io';

import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/manual_grade_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_strings.dart';

class ManualGradingPage extends StatefulWidget {
  final File? frontImage;
  final File? backImage;

  const ManualGradingPage({super.key, this.frontImage, this.backImage});

  @override
  State<ManualGradingPage> createState() => _ManualGradingPageState();
}

class _ManualGradingPageState extends State<ManualGradingPage> {
  bool isBackDetailsClicked = false;
  final manualController = Get.put(ManualGradeController());

  @override
  void initState() {
    if (widget.frontImage != null) {
      Get.find<ManualGradeController>().frontImage = widget.frontImage;
      Get.find<ManualGradeController>().isFront.value = true;
    }
    if (widget.backImage != null) {
      Get.find<ManualGradeController>().backImage = widget.backImage;
      Get.find<ManualGradeController>().isFront.value = false;
      isBackDetailsClicked = true;
    }
    super.initState();
  }

  final GlobalKey iconKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(
          title: manualCentering.tr,
          action: [
            IconButton(
              splashColor: Colors.transparent,
              // removes splash effect
              highlightColor: Colors.transparent,
              // removes tap highlight
              hoverColor: Colors.transparent,
              key: iconKey,
              icon: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:
                      isDarkMode()
                          ? AppColors.black1E1E1E
                          : AppColors.whiteFAFAFA,
                  border: Border.all(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                ),
                padding: EdgeInsets.all(18.r),
                child: SvgPicture.asset(
                  AppAssets.icMore,
                  height: 20,
                  width: 20,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
              ),
              onPressed: () async {
                final RenderBox renderBox =
                    iconKey.currentContext!.findRenderObject() as RenderBox;
                final Offset offset = renderBox.localToGlobal(Offset.zero);
                final Size size = renderBox.size;

                final selected = await showMenu<int>(
                  context: context,
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.whiteColor,
                  position: RelativeRect.fromLTRB(
                    offset.dx,
                    offset.dy + size.height, // popup appears BELOW the icon
                    offset.dx + size.width,
                    offset.dy,
                  ),
                  items: [
                    PopupMenuItem<int>(
                      value: 1,
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            AppAssets.icGalleryWhite,
                            width: 20,
                            height: 20,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                              BlendMode.srcIn,
                            ),
                          ),
                          SizedBox(width: 10),
                          Text(
                            uploadPhoto.tr,
                            style: AppTextStyle.medium16(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const PopupMenuDivider(),
                    PopupMenuItem<int>(
                      value: 2,
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            AppAssets.icCameraWhite,
                            width: 20,
                            height: 20,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                              BlendMode.srcIn,
                            ),
                          ),
                          SizedBox(width: 10),
                          Text(
                            takePhoto.tr,
                            style: AppTextStyle.medium16(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );

                if (selected == 1) {
                  await Get.find<ManualGradeController>().pickImage(
                    source: ImageSource.gallery,
                    isFront: Get.find<ManualGradeController>().isFront.value,
                  );
                } else if (selected == 2) {
                  await Get.find<ManualGradeController>().pickImage(
                    source: ImageSource.camera,
                    isFront: Get.find<ManualGradeController>().isFront.value,
                  );
                }
              },
            ),
            // moreMenuWidget(),
            // GestureDetector(
            //   onTap: () async {
            //     await Get.find<ManualGradeController>().pickImage(
            //       source: ImageSource.camera,
            //       isFront:
            //           Get.find<ManualGradeController>().isFront.value
            //               ? true
            //               : false,
            //     );
            //   },
            //   child: SvgPicture.asset(
            //     AppAssets.icCamera,
            //     height: 30,
            //     width: 30,
            //   ),
            // ),
            // SizedBox(width: 10.w),
            // GestureDetector(
            //   onTap: () async {
            //     await Get.find<ManualGradeController>().pickImage(
            //       source: ImageSource.gallery,
            //       isFront:
            //           Get.find<ManualGradeController>().isFront.value
            //               ? true
            //               : false,
            //     );
            //   },
            //   child: SvgPicture.asset(
            //     AppAssets.icGallery,
            //     height: 30,
            //     width: 30,
            //   ),
            // ),
            SizedBox(width: 15.w),
          ],
        ),
        body: GetBuilder<ManualGradeController>(
          builder:
              (manualGradeController) =>
                  manualGradeController.frontImage != null
                      ? Center(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 20.h),

                            Center(
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Container(
                                    height: 400.h,
                                    width: 250.w,
                                    color: Colors.transparent,
                                    child: Stack(
                                      children: [
                                        Obx(
                                          () => Image.file(
                                            height: 400.h,
                                            width: 250.w,
                                            manualGradeController.isFront.value
                                                ? manualGradeController
                                                    .frontImage!
                                                : manualGradeController
                                                        .backImage !=
                                                    null
                                                ? manualGradeController
                                                    .backImage!
                                                : manualGradeController
                                                    .frontImage!,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        // Diagonal Grid (outside boundary)
                                        Obx(
                                          () =>
                                              manualGradeController
                                                      .isFront
                                                      .value
                                                  ? CustomPaint(
                                                    painter: DiagonalGridPainter(
                                                      outerLeft:
                                                          manualGradeController
                                                              .outerLeft,
                                                      outerRight:
                                                          manualGradeController
                                                              .outerRight,
                                                      outerTop:
                                                          manualGradeController
                                                              .outerTop,
                                                      outerBottom:
                                                          manualGradeController
                                                              .outerBottom,
                                                      innerLeft:
                                                          manualGradeController
                                                              .left,
                                                      innerRight:
                                                          manualGradeController
                                                              .right,
                                                      innerTop:
                                                          manualGradeController
                                                              .top,
                                                      innerBottom:
                                                          manualGradeController
                                                              .bottom,
                                                    ),
                                                    size: Size(250.w, 400.h),
                                                  )
                                                  : CustomPaint(
                                                    painter: DiagonalGridPainter(
                                                      outerLeft:
                                                          manualGradeController
                                                              .outerLeftBack,
                                                      outerRight:
                                                          manualGradeController
                                                              .outerRightBack,
                                                      outerTop:
                                                          manualGradeController
                                                              .outerTopBack,
                                                      outerBottom:
                                                          manualGradeController
                                                              .outerBottomBack,
                                                      innerLeft:
                                                          manualGradeController
                                                              .leftBack,
                                                      innerRight:
                                                          manualGradeController
                                                              .rightBack,
                                                      innerTop:
                                                          manualGradeController
                                                              .topBack,
                                                      innerBottom:
                                                          manualGradeController
                                                              .bottomBack,
                                                    ),
                                                    size: Size(250.w, 400.h),
                                                  ),
                                        ),
                                        // Center rectangle between inner boundaries
                                        Obx(
                                          () =>
                                              manualGradeController
                                                      .isFront
                                                      .value
                                                  ? Positioned(
                                                    left:
                                                        manualGradeController
                                                            .left,
                                                    right:
                                                        manualGradeController
                                                            .right,
                                                    top:
                                                        manualGradeController
                                                            .top,
                                                    bottom:
                                                        manualGradeController
                                                            .bottom,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color:
                                                              AppColors
                                                                  .primaryPurple,
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                  : Positioned(
                                                    left:
                                                        manualGradeController
                                                            .leftBack,
                                                    right:
                                                        manualGradeController
                                                            .rightBack,
                                                    top:
                                                        manualGradeController
                                                            .topBack,
                                                    bottom:
                                                        manualGradeController
                                                            .bottomBack,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color:
                                                              AppColors
                                                                  .primaryPurple,
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                        ),
                                        Obx(
                                          () =>
                                              manualGradeController
                                                      .isFront
                                                      .value
                                                  ? Positioned(
                                                    left:
                                                        manualGradeController
                                                            .outerLeft,
                                                    right:
                                                        manualGradeController
                                                            .outerRight,
                                                    top:
                                                        manualGradeController
                                                            .outerTop,
                                                    bottom:
                                                        manualGradeController
                                                            .outerBottom,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color:
                                                              AppColors
                                                                  .primaryPurple,
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                  : Positioned(
                                                    left:
                                                        manualGradeController
                                                            .outerLeftBack,
                                                    right:
                                                        manualGradeController
                                                            .outerRightBack,
                                                    top:
                                                        manualGradeController
                                                            .outerTopBack,
                                                    bottom:
                                                        manualGradeController
                                                            .outerBottomBack,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color:
                                                              AppColors
                                                                  .primaryPurple,
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Inner Arrows
                                  Obx(
                                    () => Positioned(
                                      top:
                                          manualGradeController.isFront.value
                                              ? manualGradeController.top
                                              : manualGradeController.topBack,
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontInnerBorder(
                                                          "top",
                                                          details.delta.dy,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackInnerBorder(
                                                          "top",
                                                          details.delta.dy,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowTop,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      bottom:
                                          manualGradeController.isFront.value
                                              ? manualGradeController.bottom
                                              : manualGradeController
                                                  .bottomBack,
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontInnerBorder(
                                                          "bottom",
                                                          details.delta.dy,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackInnerBorder(
                                                          "bottom",
                                                          details.delta.dy,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowDown,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      left:
                                          manualGradeController.isFront.value
                                              ? manualGradeController.left
                                              : manualGradeController.leftBack,
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontInnerBorder(
                                                          "left",
                                                          details.delta.dx,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackInnerBorder(
                                                          "left",
                                                          details.delta.dx,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowLeft,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      right:
                                          manualGradeController.isFront.value
                                              ? manualGradeController.right
                                              : manualGradeController.rightBack,
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontInnerBorder(
                                                          "right",
                                                          details.delta.dx,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackInnerBorder(
                                                          "right",
                                                          details.delta.dx,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowRight,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Outer Arrows (10px further from inner)
                                  Obx(
                                    () => Positioned(
                                      top:
                                          manualGradeController.isFront.value
                                              ? (manualGradeController
                                                      .outerTop -
                                                  manualGradeController.gap)
                                              : (manualGradeController
                                                      .outerTopBack -
                                                  manualGradeController
                                                      .gapBack),
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontOuterBorder(
                                                          "top",
                                                          details.delta.dy,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackOuterBorder(
                                                          "top",
                                                          details.delta.dy,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowTop,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      bottom:
                                          manualGradeController.isFront.value
                                              ? (manualGradeController
                                                      .outerBottom -
                                                  manualGradeController.gap)
                                              : (manualGradeController
                                                      .outerBottomBack -
                                                  manualGradeController
                                                      .gapBack),
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontOuterBorder(
                                                          "bottom",
                                                          details.delta.dy,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackOuterBorder(
                                                          "bottom",
                                                          details.delta.dy,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowDown,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      left:
                                          manualGradeController.isFront.value
                                              ? (manualGradeController
                                                      .outerLeft -
                                                  manualGradeController.gap)
                                              : (manualGradeController
                                                      .outerLeftBack -
                                                  manualGradeController
                                                      .gapBack),
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontOuterBorder(
                                                          "left",
                                                          details.delta.dx,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackOuterBorder(
                                                          "left",
                                                          details.delta.dx,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowLeft,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Obx(
                                    () => Positioned(
                                      right:
                                          manualGradeController.isFront.value
                                              ? (manualGradeController
                                                      .outerRight -
                                                  manualGradeController.gap)
                                              : (manualGradeController
                                                      .outerRightBack -
                                                  manualGradeController
                                                      .gapBack),
                                      child: GestureDetector(
                                        onPanUpdate:
                                            (details) =>
                                                manualGradeController
                                                        .isFront
                                                        .value
                                                    ? manualGradeController
                                                        .adjustFrontOuterBorder(
                                                          "right",
                                                          details.delta.dx,
                                                        )
                                                    : manualGradeController
                                                        .adjustBackOuterBorder(
                                                          "right",
                                                          details.delta.dx,
                                                        ),
                                        child: _overlayButton(
                                          AppAssets.icManualArrowRight,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20.h),

                            // SizedBox(height: 20.h),
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 15.w,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.all(5.r),
                                        decoration: BoxDecoration(
                                          color:
                                              isDarkMode()
                                                  ? AppColors.black1E1E1E
                                                  : AppColors.greyF5F5F5,
                                          borderRadius: BorderRadius.circular(
                                            30,
                                          ),
                                        ),
                                        child: TabBar(
                                          labelColor:
                                              isDarkMode()
                                                  ? AppColors.black0D0C0C
                                                  : AppColors.whiteColor,
                                          labelStyle: AppTextStyle.medium20(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.black0D0C0C
                                                    : AppColors.whiteColor,
                                          ),
                                          splashBorderRadius:
                                              BorderRadius.circular(30),
                                          indicatorWeight: 0.0,
                                          dividerHeight: 0.0,
                                          labelPadding: EdgeInsets.zero,
                                          unselectedLabelColor:
                                              isDarkMode()
                                                  ? AppColors.grey9B9B9B
                                                  : AppColors.black0D0C0C,
                                          onTap: (value) async {
                                            if (value == 1) {
                                              if (!isBackDetailsClicked) {
                                                showDialog(
                                                  context: context,
                                                  barrierDismissible: false,
                                                  builder: (context) {
                                                    return pickImageDialog(
                                                      onCameraTap: () async {
                                                        Get.back();
                                                        await manualGradeController
                                                            .pickImage(
                                                              source:
                                                                  ImageSource
                                                                      .camera,
                                                              isFront: false,
                                                            );
                                                      },
                                                      onGalleryTap: () async {
                                                        Get.back();
                                                        await manualGradeController
                                                            .pickImage(
                                                              source:
                                                                  ImageSource
                                                                      .gallery,
                                                              isFront: false,
                                                            );
                                                      },
                                                    );
                                                  },
                                                );

                                                isBackDetailsClicked = true;
                                              }
                                              manualGradeController
                                                  .onBackChange(true);
                                            } else {
                                              manualGradeController
                                                  .onFrontChange(true);
                                            }
                                          },
                                          indicator: BoxDecoration(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.primaryPurple,
                                            borderRadius: BorderRadius.circular(
                                              30,
                                            ),
                                          ),
                                          indicatorSize:
                                              TabBarIndicatorSize.tab,

                                          tabs: [
                                            Tab(text: frontDetail.tr),
                                            Tab(text: backDetail.tr),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 12.h),
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                          0.35,
                                      child: TabBarView(
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        children: [
                                          frontGradingWidget(
                                            lrValue:
                                                manualGradeController
                                                    .horizontalCentering,
                                            tbValue:
                                                manualGradeController
                                                    .verticalCentering,
                                            gradeValue:
                                                manualGradeController.grading,
                                          ),
                                          backGradingWidget(
                                            lrValue:
                                                manualGradeController
                                                    .horizontalCenteringBack,
                                            tbValue:
                                                manualGradeController
                                                    .verticalCenteringBack,
                                            gradeValue:
                                                manualGradeController
                                                    .gradingBack,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                      : Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: Column(
                            // crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                isDarkMode()
                                    ? AppAssets.icEmptyCollectionDark
                                    : AppAssets.icEmptyCollection,
                              ),
                              SizedBox(height: 10.h),
                              Text(
                                checkCentering.tr,
                                style: AppTextStyle.medium24(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                              Text(
                                centerDesc.tr,
                                textAlign: TextAlign.center,
                                style: AppTextStyle.medium17(
                                  color: AppColors.grey9B9B9B,
                                ),
                              ),

                              SizedBox(height: 20.h),
                              CommonButton(
                                onPressed: () async {
                                  await manualGradeController.pickImage(
                                    source: ImageSource.gallery,
                                    isFront: true,
                                  );
                                },
                                buttonWidth: double.infinity,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SvgPicture.asset(
                                      AppAssets.icGalleryWhite,
                                      width: 20,
                                      height: 20,
                                    ),
                                    SizedBox(width: 10.w),
                                    Text(
                                      uploadPhoto.tr,
                                      style: AppTextStyle.medium20(
                                        color: AppColors.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 15.h),
                              CommonButton(
                                onPressed: () async {
                                  await manualGradeController.pickImage(
                                    source: ImageSource.camera,
                                    isFront: true,
                                  );
                                },
                                buttonWidth: double.infinity,

                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SvgPicture.asset(
                                      AppAssets.icCameraWhite,
                                      width: 20,
                                      height: 20,
                                    ),
                                    SizedBox(width: 10.w),
                                    Text(
                                      takePhoto.tr,
                                      style: AppTextStyle.medium20(
                                        color: AppColors.whiteColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
        ),
      ),
    );
  }

  frontGradingWidget({
    required String lrValue,
    required String tbValue,
    required String gradeValue,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      child: Column(
        children: [
          SizedBox(height: 10.h),

          Text(
            frontScore.tr,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
          SizedBox(height: 15.h),
          gradeWidget(title: leftRight.tr, value: lrValue),
          Divider(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          gradeWidget(title: topBottom.tr, value: tbValue),
          Divider(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          gradeWidget(title: grade.tr, value: gradeValue),
        ],
      ),
    );
  }

  backGradingWidget({
    required String lrValue,
    required String tbValue,
    required String gradeValue,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      child: Column(
        children: [
          SizedBox(height: 10.h),
          Text(
            backScore.tr,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
          SizedBox(height: 15.h),
          gradeWidget(title: leftRight.tr, value: lrValue),
          Divider(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          gradeWidget(title: topBottom.tr, value: tbValue),
          Divider(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          gradeWidget(title: grade.tr, value: gradeValue),
        ],
      ),
    );
  }

  gradeWidget({required String title, required String value}) {
    return Container(
      color: Colors.transparent,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$title:",
            style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
          ),
          Text(
            value,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
        ],
      ),
    );
  }

  Widget _overlayButton(String emoji) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
        shape: BoxShape.circle,
      ),
      // padding: EdgeInsets.all(5.r),
      child: SvgPicture.asset(emoji, height: 24, width: 24),
      // child: Text(emoji, style: TextStyle(fontSize: 22.h, color: Colors.white)),
    );
  }

  pickImageDialog({
    required VoidCallback onCameraTap,
    required VoidCallback onGalleryTap,
  }) {
    return AlertDialog(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
      insetPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onCameraTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),

                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icCamera),
                          SizedBox(height: 10.h),
                          Text(
                            takeAPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.w),
              Expanded(
                child: GestureDetector(
                  onTap: onGalleryTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icGallery),
                          SizedBox(height: 10.h),
                          Text(
                            selectPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      // content: Container(
      //   decoration: BoxDecoration(
      //     borderRadius: BorderRadius.circular(14.r),
      //     color: AppColors.whiteColor,
      //   ),
      //   padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
      //   child: ,
      // ),
    );
  }

  moreMenuWidget() {
    return PopupMenuButton<int>(
      color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.whiteColor,
      icon: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteFAFAFA,
          border: Border.all(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
        ),
        padding: EdgeInsets.all(18.r),
        child: SvgPicture.asset(
          AppAssets.icMore,
          height: 20,
          width: 20,
          colorFilter: ColorFilter.mode(
            isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            BlendMode.srcIn,
          ),
        ),
      ),
      padding: EdgeInsets.zero,
      menuPadding: EdgeInsets.zero,
      itemBuilder: (context) {
        return [
          PopupMenuItem(
            onTap: () async {
              await Get.find<ManualGradeController>().pickImage(
                source: ImageSource.gallery,
                isFront:
                    Get.find<ManualGradeController>().isFront.value
                        ? true
                        : false,
              );
            },
            child: Row(
              children: [
                SvgPicture.asset(
                  AppAssets.icGalleryWhite,
                  width: 20,
                  height: 20,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  uploadPhoto.tr,
                  style: AppTextStyle.medium16(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ],
            ),
          ),
          PopupMenuDivider(),
          PopupMenuItem(
            onTap: () async {
              await Get.find<ManualGradeController>().pickImage(
                source: ImageSource.camera,
                isFront:
                    Get.find<ManualGradeController>().isFront.value
                        ? true
                        : false,
              );
            },
            child: Row(
              children: [
                SvgPicture.asset(
                  AppAssets.icCameraWhite,
                  width: 20,
                  height: 20,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  takePhoto.tr,
                  style: AppTextStyle.medium16(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ],
            ),
          ),
        ];
      },
    );
  }
}

class DiagonalGridPainter extends CustomPainter {
  final double outerLeft;
  final double outerRight;
  final double outerTop;
  final double outerBottom;

  final double innerLeft;
  final double innerRight;
  final double innerTop;
  final double innerBottom;

  DiagonalGridPainter({
    required this.outerLeft,
    required this.outerRight,
    required this.outerTop,
    required this.outerBottom,
    required this.innerLeft,
    required this.innerRight,
    required this.innerTop,
    required this.innerBottom,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..color = AppColors.primaryPurple
          ..strokeWidth = 2;

    double step = 15;

    // Outer rect boundaries
    double leftX = outerLeft;
    double topY = outerTop;
    double rightX = size.width - outerRight;
    double bottomY = size.height - outerBottom;

    // Inner rect boundaries
    double innerLeftX = innerLeft;
    double innerTopY = innerTop;
    double innerRightX = size.width - innerRight;
    double innerBottomY = size.height - innerBottom;

    // Create paths
    Path outerPath =
        Path()..addRect(Rect.fromLTRB(leftX, topY, rightX, bottomY));

    Path innerPath =
        Path()..addRect(
          Rect.fromLTRB(innerLeftX, innerTopY, innerRightX, innerBottomY),
        );

    // Create a path that excludes the inner rectangle
    Path gridPath = Path.combine(
      PathOperation.difference,
      outerPath,
      innerPath,
    );

    // Clip to the ring area (between outer and inner)
    canvas.save();
    canvas.clipPath(gridPath);

    // Draw diagonal lines inside the clipped area
    for (double i = -size.height; i < size.width; i += step) {
      canvas.drawLine(
        Offset(i, size.height),
        Offset(i + size.height, 0),
        paint,
      );
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
