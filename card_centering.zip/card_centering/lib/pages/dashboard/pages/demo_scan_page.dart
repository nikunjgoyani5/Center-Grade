import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../apptheme/app_assets.dart';
import '../../../apptheme/app_colors.dart';
import '../../../apptheme/app_constants.dart';
import '../../../apptheme/app_textstyle.dart';

class DemoScanPage extends StatefulWidget {
  const DemoScanPage({super.key});

  @override
  State<DemoScanPage> createState() => _DemoScanPageState();
}

class _DemoScanPageState extends State<DemoScanPage> {
  @override
  void initState() {
    Get.find<HomeController>().getImageFromCamera(true);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        toolbarHeight: 80.h,
        leading: GestureDetector(
          onTap: () => Get.back(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                height: 45.h,
                width: 45.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:
                      isDarkMode()
                          ? AppColors.black1E1E1E
                          : AppColors.whiteFAFAFA,
                  border: Border.all(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      isDarkMode()
                          ? AppAssets.icArrowBackDark
                          : AppAssets.icArrowBack,
                      width: 18,
                      height: 18,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
              ),
              borderRadius: BorderRadius.circular(50.r),
              color:
                  isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
            ),
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
            child: Text(
              download.tr,
              style: AppTextStyle.medium20(
                color:
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
              ),
            ),
          ),
          SizedBox(width: 15.w),
          GetBuilder<HomeController>(
            builder:
                (controller) => Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:
                        isDarkMode()
                            ? AppColors.black1E1E1E
                            : AppColors.whiteFAFAFA,
                    border: Border.all(
                      color:
                          isDarkMode()
                              ? AppColors.grey2A2A2A
                              : AppColors.greyEBEBEB,
                    ),
                  ),
                  padding: EdgeInsets.all(10.r),
                  child: SvgPicture.asset(
                    controller.favCardData?.isFavorite == true
                        ? AppAssets.icFavFilled
                        : AppAssets.icFavorite,
                    height: 20,
                    width: 20,
                    colorFilter: ColorFilter.mode(
                      controller.favCardData?.isFavorite == true
                          ? AppColors.primaryPurple
                          : isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                      BlendMode.srcIn,
                    ),
                  ),
                ),
          ),
          SizedBox(width: 15.w),
        ],
      ),
    );
  }
}
