import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../controllers/iapcontroller/iap_controller.dart';

class PaywallScreen extends StatelessWidget {
  const PaywallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(IapController());
    return GetBuilder<IapController>(
      builder:
          (iapController) => Container(
            decoration: BoxDecoration(
              color:
                  isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(20.r),
                topLeft: Radius.circular(20.r),
              ),
            ),
            padding: EdgeInsets.only(
              left: 20.w,
              right: 20.w,
              top: 15.h,
              bottom: 20.h,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SvgPicture.asset(
                        AppAssets.imgPremium,
                        width: 45.h,
                        height: 45.h,
                      ),
                      GestureDetector(
                        onTap: () => Get.back(),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyF6F6F6,
                          ),
                          padding: EdgeInsets.all(8.r),
                          child: SvgPicture.asset(
                            AppAssets.icClose,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black,
                              BlendMode.srcIn,
                            ),
                            height: 12,
                            width: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    gradeSmarter.tr,
                    style: AppTextStyle.semiBold36(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ).copyWith(height: 0.9),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    noCreditCard.tr,
                    style: AppTextStyle.regular18(
                      color:
                          isDarkMode()
                              ? AppColors.grey9B9B9B
                              : AppColors.grey878787,
                    ),
                  ),
                  SizedBox(height: 30.h),
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    separatorBuilder:
                        (context, index) => SizedBox(height: 15.h),
                    itemCount: iapController.iapPlanList.length,
                    itemBuilder: (context, index) {
                      final iapData = iapController.iapPlanList[index];
                      return GestureDetector(
                        onTap: () {
                          iapController.onPlanSelect(planData: iapData);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color:
                                isDarkMode()
                                    ? AppColors.black1E1E1E
                                    : AppColors.whiteColor,
                            borderRadius: BorderRadius.circular(15.r),
                            border: Border.all(
                              width: 2,
                              color:
                                  iapController.selectedPlanName ==
                                          iapData.planName
                                      ? AppColors.primaryPurple
                                      : isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyF6F6F6,
                            ),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 15.w,
                            vertical: 15.h,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  iapController.selectedPlanName ==
                                          iapData.planName
                                      ? SvgPicture.asset(AppAssets.icSelected)
                                      : SvgPicture.asset(
                                        AppAssets.icUnselected,
                                      ),
                                  SizedBox(width: 10.w),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            iapData.planName,
                                            style: AppTextStyle.semiBold22(
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.whiteColor
                                                      : AppColors.black0D0C0C,
                                            ),
                                          ),
                                          SizedBox(width: 8.w),
                                          iapController.selectedPlanName ==
                                                      iapData.planName &&
                                                  iapData.planName == proPlan.tr
                                              ? Container(
                                                decoration: BoxDecoration(
                                                  color:
                                                      AppColors.primaryPurple,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                        50.r,
                                                      ),
                                                ),
                                                padding: EdgeInsets.symmetric(
                                                  horizontal: 12.w,
                                                  vertical: 5.h,
                                                ),
                                                child: Text(
                                                  mostPopular.tr,
                                                  style: AppTextStyle.regular14(
                                                    color: AppColors.whiteColor,
                                                  ),
                                                ),
                                              )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                      Text(
                                        iapData.planDesc,
                                        maxLines: 2,
                                        style: AppTextStyle.regular16(
                                          color: AppColors.grey878787,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text.rich(
                                      TextSpan(
                                        children: [
                                          TextSpan(
                                            text: "\$${iapData.planPrice}/",
                                            style: AppTextStyle.semiBold24(
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.whiteColor
                                                      : AppColors.black0D0C0C,
                                            ),
                                          ),
                                          TextSpan(
                                            text: month.tr,
                                            style: AppTextStyle.semiBold20(
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.whiteColor
                                                      : AppColors.black0D0C0C,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      save25.tr,
                                      style: AppTextStyle.medium20(
                                        color: AppColors.primaryPurple,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 20.h),
                  Center(
                    child: Column(
                      children: [
                        CommonButton(
                          onPressed: () async {
                            // if (iapController.selectedPlanName ==
                            //     'Basic Plan') {
                            //   await RevenueCatService.purchaseMonthlyBasePlan();
                            // } else if (iapController.selectedPlanName ==
                            //     "Pro Plan") {
                            //   await RevenueCatService.purchaseMonthlyProPlan();
                            // } else {
                            //   await RevenueCatService.purchaseMonthElitePlan();
                            // }
                          },
                          buttonWidth: double.infinity,
                          child: Text(
                            "${startFreeThen.tr} \$${iapController.selectedPlanPrice}/${month.tr}",
                            style: AppTextStyle.medium20(
                              color: AppColors.whiteColor,
                            ),
                          ),
                        ),
                        SizedBox(height: 15.h),
                        Text(
                          threeScanFree.tr,
                          textAlign: TextAlign.center,
                          style: AppTextStyle.medium16(
                            color: AppColors.grey9B9B9B,
                          ),
                        ),
                        SizedBox(height: 12.h),
                        Text(
                          otherPlan.tr,
                          style: AppTextStyle.medium18(
                            color: AppColors.primaryPurple,
                          ).copyWith(decoration: TextDecoration.underline),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ),
    );
  }
}
