import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';

class DetailView extends StatelessWidget {
  final String grade;
  const DetailView({super.key, required this.grade});

  @override
  Widget build(BuildContext context) {
    List<String> psaList =
        [
          "GEM-MT",
          "MINT",
          "NM-MT",
          "NM",
          "EX-MT",
          "EX",
          "EX",
          "EX",
          "EX",
          "EX",
        ].reversed.toList();

    // List<String> beckettList =
    //     [
    //       "Pristine",
    //       "Gem Mint",
    //       "Mint",
    //       "Near Mint/Mint",
    //       "Near Mint",
    //       "Excellent Mint",
    //       "Excellent",
    //       "Very Good/Excellent",
    //       "Very Good",
    //       "Good",
    //       "Poor",
    //     ].reversed.toList();

    // List<String> cgcList =
    //     [
    //       "Pristine",
    //       "Gem Mint",
    //       "Mint+",
    //       "Mint",
    //       "NM/Mint",
    //       "NM/Mint",
    //       "Near Mint",
    //       "Near Mint",
    //       "Ex/NM",
    //       "Ex/NM",
    //       "Excellent",
    //       "Excellent",
    //       "VG/Ex",
    //       "VG/Ex",
    //       "Very Good",
    //       "Very Good",
    //       "Good",
    //       "Good",
    //       "Poor",
    //       "Poor",
    //     ].reversed.toList();

    List<Map<String, String>> psaGradeList =
        [
          {'front': "55/45", 'back': "75/25"},
          {'front': "60/40", 'back': "90/10"},
          {'front': "65/35", 'back': "90/10"},
          {'front': "70/10", 'back': "90/10"},
          {'front': "80/20", 'back': "90/10"},
          {'front': "85/15", 'back': "90/10"},
          {'front': "85/15", 'back': "90/10"},
          {'front': "90/10", 'back': "90/10"},
          {'front': "90/10", 'back': "90/10"},
          {'front': "N/A", 'back': "N/A"},
        ].reversed.toList();

    List<Map<String, String>> beckettGradeList =
        [
          {'front': "50/50", 'back': "60/40"},
          {'front': "50/50, 55/45", 'back': "60/40"},
          {'front': "55/45", 'back': "70/30"},
          {'front': "60/40", 'back': "80/20"},
          {'front': "65/35", 'back': "90/10"},
          {'front': "70/30", 'back': "95/5"},
          {'front': "75/25", 'back': "95/5"},
          {'front': "80/20", 'back': "100/0"},
          {'front': "85/15", 'back': "100/0"},
          {'front': "Offcut", 'back': "Offcut"},
        ].reversed.toList();

    return Scaffold(
      appBar: commonAppbar(title: "$grade ${gradingScale.tr}"),
      body: Padding(
        padding: EdgeInsets.only(bottom: 20.h),
        child: ListView.separated(
          itemCount:
              grade == psa.tr
                  ? psaGradeList.length
                  : grade == beckett.tr
                  ? beckettGradeList.length
                  : psaGradeList.length,
          reverse: true,
          separatorBuilder: (context, index) => SizedBox(height: 10.h),
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.symmetric(horizontal: 20.w),
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.r),
                color:
                    isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$grade ${index + 1}.0',
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ).copyWith(height: 1),
                      ),
                      SizedBox(height: 5.h),
                      Text(
                        psaList[index],
                        style: AppTextStyle.medium17(
                          color: AppColors.grey9B9B9B,
                        ).copyWith(height: 1),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                  SizedBox(width: 15.w),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GradingTag(
                          label: 'Front:',
                          grade:
                              grade == psa.tr
                                  ? psaGradeList[index]['front'].toString()
                                  : grade == beckett.tr
                                  ? beckettGradeList[index]['front'].toString()
                                  : psaGradeList[index]['front'].toString(),
                        ),
                        SizedBox(width: 10.w),
                        GradingTag(
                          label: 'Back:',
                          grade:
                              grade == psa.tr
                                  ? psaGradeList[index]['back'].toString()
                                  : grade == beckett.tr
                                  ? beckettGradeList[index]['back'].toString()
                                  : psaGradeList[index]['back'].toString(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class GradingTag extends StatelessWidget {
  final String label;
  final String grade;

  const GradingTag({super.key, required this.label, required this.grade});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        width: Get.width * 0.3,
        padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyF5F5F5,
          // color: Colors.red,
          borderRadius: BorderRadius.circular(7.r),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyle.medium17(color: AppColors.grey9B9B9B),
              ),
            ),
            Expanded(
              child: Text(
                grade,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
