import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/pages/dashboard/pages/standardmodule/detail_view.dart';
import 'package:card_centering/pages/dashboard/pages/standardmodule/tricks_view.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

class StandardScreen extends StatelessWidget {
  const StandardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(title: standard.tr),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              gradingStandards.tr,
              style: AppTextStyle.medium20(
                color:
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
              ),
            ),
            SizedBox(height: 15.h),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.r),
                color:
                    isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
              ),
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
              child: Column(
                children: [
                  standardWidget(
                    leadingIcon: AppAssets.imgPsa,
                    title: psa.tr,
                    subTitle: psaFullName.tr,
                    onTap: () {
                      Get.to(
                        () => DetailView(grade: psa.tr),
                        transition: Transition.rightToLeftWithFade,
                      );
                    },
                  ),
                  Divider(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                  standardWidget(
                    leadingIcon: AppAssets.imgBeckett,
                    title: beckett.tr,
                    subTitle: beckettFullName.tr,
                    onTap: () {
                      Get.to(
                        () => DetailView(grade: beckett.tr),
                        transition: Transition.rightToLeftWithFade,
                      );
                    },
                  ),
                  Divider(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                  standardWidget(
                    leadingIcon: AppAssets.imgCgc,
                    title: cgc.tr,
                    subTitle: cgcFullName.tr,
                    onTap: () {
                      Get.to(
                        () => DetailView(grade: cgc.tr),
                        transition: Transition.rightToLeftWithFade,
                      );
                    },
                  ),
                  Divider(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                  standardWidget(
                    leadingIcon: AppAssets.imgSgc,
                    title: sgc.tr,
                    subTitle: sgcFullName.tr,
                    onTap: () {
                      Get.to(
                        () => DetailView(grade: sgc.tr),
                        transition: Transition.rightToLeftWithFade,
                      );
                    },
                  ),
                  Divider(
                    color:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEBEBEB,
                  ),
                  standardWidget(
                    leadingIcon: AppAssets.imgTag,
                    title: tag.tr,
                    subTitle: tagFullName.tr,
                    onTap: () {
                      Get.to(
                        () => DetailView(grade: tag.tr),
                        transition: Transition.rightToLeftWithFade,
                      );
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: 20.h),
            Text(
              reference.tr,
              style: AppTextStyle.medium20(
                color:
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
              ),
            ),
            SizedBox(height: 15.h),
            GestureDetector(
              onTap: () {
                Get.to(
                  () => TricksView(),
                  transition: Transition.rightToLeftWithFade,
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.r),
                  color:
                      isDarkMode()
                          ? AppColors.black1E1E1E
                          : AppColors.whiteColor,
                ),
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8.r),
                            color: AppColors.primaryPurple,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 12.w,
                            vertical: 12.h,
                          ),
                          child: SvgPicture.asset(
                            AppAssets.icTips,
                            height: 20,
                            width: 20,
                            colorFilter: ColorFilter.mode(
                              AppColors.whiteColor,
                              BlendMode.srcIn,
                            ),
                          ),
                        ),
                        SizedBox(width: 10.w),
                        Text(
                          tipsTricks.tr,
                          style: AppTextStyle.medium20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                      ],
                    ),
                    SvgPicture.asset(
                      isDarkMode()
                          ? AppAssets.icArrowRightDark
                          : AppAssets.icArrowRight,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  standardWidget({
    required String leadingIcon,
    required String title,
    required String subTitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Image.asset(leadingIcon, height: 50, width: 50),
              SizedBox(width: 10.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTextStyle.medium20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  Text(
                    subTitle,
                    style: AppTextStyle.medium17(color: AppColors.grey9B9B9B),
                  ),
                ],
              ),
            ],
          ),
          SvgPicture.asset(
            isDarkMode() ? AppAssets.icArrowRightDark : AppAssets.icArrowRight,
          ),
        ],
      ),
    );
  }
}
