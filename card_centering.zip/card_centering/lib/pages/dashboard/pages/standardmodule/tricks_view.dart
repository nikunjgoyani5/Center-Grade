import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';

class TricksView extends StatelessWidget {
  const TricksView({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> iconList = [
      AppAssets.icPlaceCard,
      AppAssets.icImprove,
      AppAssets.icProtection,
      AppAssets.icScanner,
      AppAssets.icLevelUp,
    ];
    List<String> titleList = [
      placeCardOn.tr,
      improveLightening.tr,
      removeCard.tr,
      scannerResolution.tr,
      levelUpYourScans.tr,
    ];
    List<String> subTitleList = [
      usingSolid.tr,
      ensureThere.tr,
      removeAnyProtection.tr,
      choosing.tr,
      ensureYourPhone.tr,
    ];

    return Scaffold(
      appBar: commonAppbar(title: tipsTricks.tr),
      body: ListView.builder(
        itemCount: iconList.length,
        itemBuilder: (context, index) {
          return trickWidget(
            leadingIcon: iconList[index],
            title: titleList[index],
            subTitle: subTitleList[index],
          );
        },
      ),
    );
  }

  trickWidget({
    required String leadingIcon,
    required String title,
    required String subTitle,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
      decoration: BoxDecoration(
        color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyF5F5F5,
        borderRadius: BorderRadius.circular(10.r),
      ),
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.r),
                  color: AppColors.primaryPurple,
                ),
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
                child: SvgPicture.asset(
                  leadingIcon,
                  height: 20,
                  width: 20,
                  colorFilter: ColorFilter.mode(
                    AppColors.whiteColor,
                    BlendMode.srcIn,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Text(
                  title,
                  maxLines: 2,
                  style: AppTextStyle.medium20(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          Text(
            subTitle,
            style: AppTextStyle.medium16(color: AppColors.grey9B9B9B),
          ),
        ],
      ),
    );
  }
}
