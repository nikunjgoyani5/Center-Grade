import 'dart:async';
import 'dart:io';

import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/profilecontroller/profile_controller.dart';
import 'package:card_centering/widgets/common_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/common_appbar.dart';
import '../../../../widgets/common_button.dart';
import '../../../../widgets/common_widgets.dart';

class EditProfile extends StatefulWidget {
  final String userImage;
  final String userName;
  final DateTime userBirthday;

  const EditProfile({
    super.key,
    required this.userImage,
    required this.userName,
    required this.userBirthday,
  });

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  final profileController = Get.put(ProfileController());

  Timer? _debounce;

  final FocusNode _focusNode1 = FocusNode();
  final FocusNode _focusNode2 = FocusNode();
  final FocusNode _focusNode3 = FocusNode();

  @override
  void dispose() {
    _focusNode1.dispose();
    _focusNode2.dispose();
    _focusNode3.dispose();
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      profileController.nameController.text = widget.userName;
      if (widget.userBirthday.day != DateTime.now().day) {
        profileController.dayController.text =
            widget.userBirthday.day.toString().toDoubleDigit();
        profileController.yearController.text =
            widget.userBirthday.year.toString();
        profileController.monthController.text =
            widget.userBirthday.month.toString().toDoubleDigit();
      } else {
        profileController.dayController.text = '';
        profileController.yearController.text = '';
        profileController.monthController.text = '';
      }

      profileController.checkButtonStatus();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(title: editProfile.tr),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 20.w,
            right: 20.w,
            bottom: Platform.isIOS ? 40.h : 20.h,
          ),
          child: Obx(
            () => CommonButton(
              buttonColor:
                  profileController.isButtonDisabled.value
                      ? isDarkMode()
                          ? AppColors.disableColorDark
                          : AppColors.disableColor
                      : AppColors.primaryPurple,
              buttonWidth: double.infinity,
              buttonHeight: 55.h,
              radius: 12.r,
              onPressed: () async {
                await profileController.updateProfile(isEdit: true);
              },
              child: Text(
                saveProfile.tr,
                style: AppTextStyle.medium20(
                  color:
                      profileController.isButtonDisabled.value
                          ? AppColors.whiteColor.withValues(alpha: 0.4)
                          : AppColors.whiteColor,
                ),
              ),
            ),
          ),
        ),
        body: GetBuilder<ProfileController>(
          builder:
              (controller) => Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20.h),
                        Center(
                          child: Stack(
                            alignment: Alignment.bottomRight,
                            clipBehavior: Clip.none,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder:
                                        (context) => pickImageDialog(
                                          onCameraTap: () async {
                                            Get.back();
                                            await controller.pickUserProfile(
                                              source: ImageSource.camera,
                                            );
                                          },
                                          onGalleryTap: () async {
                                            Get.back();
                                            await controller.pickUserProfile(
                                              source: ImageSource.gallery,
                                            );
                                          },
                                        ),
                                  );
                                },
                                child:
                                    widget.userImage.isNotEmpty &&
                                            controller.profileImage == null
                                        ? ClipRRect(
                                          borderRadius: BorderRadius.circular(
                                            55.r,
                                          ),
                                          child: CircleAvatar(
                                            radius: 55.r,
                                            backgroundImage:
                                                Image.network(
                                                  widget.userImage,
                                                  errorBuilder: (
                                                    context,
                                                    error,
                                                    stackTrace,
                                                  ) {
                                                    return SvgPicture.asset(
                                                      AppAssets.icProfile,
                                                    );
                                                  },
                                                ).image,
                                          ),
                                        )
                                        : controller.profileImage != null
                                        ? CircleAvatar(
                                          radius: 55.r,
                                          backgroundColor:
                                              isDarkMode()
                                                  ? AppColors.black1E1E1E
                                                  : AppColors.greyEBEBEB,
                                          backgroundImage:
                                              Image.file(
                                                controller.profileImage!,
                                              ).image,
                                        )
                                        : CircleAvatar(
                                          radius: 55.r,
                                          backgroundColor:
                                              isDarkMode()
                                                  ? AppColors.black1E1E1E
                                                  : AppColors.greyEBEBEB,
                                          child: SvgPicture.asset(
                                            AppAssets.icProfile,
                                          ),
                                        ),
                              ),
                              Positioned(
                                bottom: -2.h,
                                child: GestureDetector(
                                  onTap: () {},
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color:
                                          isDarkMode()
                                              ? AppColors.black121212
                                              : Colors.white,
                                      shape: BoxShape.circle,
                                    ),
                                    padding: EdgeInsets.all(4.r),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color:
                                            isDarkMode()
                                                ? AppColors.grey2F2F2F
                                                : AppColors.black0D0C0C,
                                      ),
                                      padding: EdgeInsets.all(5.r),
                                      child: SvgPicture.asset(
                                        AppAssets.icCameraWhite,
                                        height: 14,
                                        width: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20.h),
                        Text(
                          name.tr,
                          style: AppTextStyle.medium20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        commonTextfield(
                          controller: controller.nameController,
                          hintText: enterYourName.tr,
                        ),
                        SizedBox(height: 20.h),
                        Text(
                          birthDay.tr,
                          style: AppTextStyle.medium20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: commonTextfield(
                                focusNode: _focusNode1,
                                controller: controller.dayController,
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  if (value != null && value.isNotEmpty) {
                                    final dayValue = int.parse(value);
                                    if (dayValue > 31) {
                                      controller.dayController.text = '31';
                                    } /*else if (dayValue < 0) {
                                      controller.dayController.text = '1';
                                    }*/
                                  }
                                  if (_debounce?.isActive ?? false) {
                                    _debounce?.cancel();
                                  }
                                  _debounce = Timer(300.milliseconds, () {
                                    if (value!.length == 2) {
                                      if (int.parse(value) != 0) {
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode2);
                                      } else {
                                        showToast(message: enterValidNumber.tr);
                                      }
                                    }
                                  });
                                },
                                onSubmitted: (p0) {
                                  if (profileController
                                      .dayController
                                      .text
                                      .isEmpty) {
                                    showToast(message: pleaseEnterDate.tr);
                                    FocusScope.of(
                                      context,
                                    ).requestFocus(_focusNode1);
                                  } else {
                                    if (int.parse(p0) == 0) {
                                      showToast(message: enterValidNumber.tr);
                                      FocusScope.of(
                                        context,
                                      ).requestFocus(_focusNode1);
                                    } else {
                                      if (int.parse(p0) <= 9) {
                                        profileController.dayController.text =
                                            '0$p0';
                                      }
                                      _focusNode1.unfocus();
                                      FocusScope.of(
                                        context,
                                      ).requestFocus(_focusNode2);
                                    }
                                  }
                                },
                                hintText: "dd",
                                textFormatter: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(2),
                                ],
                              ),
                            ),

                            SizedBox(width: 12.w),
                            Expanded(
                              child: commonTextfield(
                                focusNode: _focusNode2,
                                controller: controller.monthController,
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  if (value != null && value.isNotEmpty) {
                                    final dayValue = int.parse(value);
                                    if (dayValue > 12) {
                                      controller.monthController.text = '12';
                                    }
                                    /*else if (dayValue < 1) {
                                      controller.monthController.text = '1';
                                    }*/
                                    if (_debounce?.isActive ?? false) {
                                      _debounce?.cancel();
                                    }
                                    _debounce = Timer(300.milliseconds, () {
                                      if (value.length == 2) {
                                        if (int.parse(value) != 0) {
                                          FocusScope.of(
                                            context,
                                          ).requestFocus(_focusNode3);
                                        } else {
                                          showToast(
                                            message: enterValidNumber.tr,
                                          );
                                        }
                                      }
                                    });
                                  }
                                },
                                hintText: "mm",
                                onSubmitted: (p0) {
                                  if (profileController
                                      .monthController
                                      .text
                                      .isEmpty) {
                                    showToast(message: pleaseEnterMonth.tr);
                                    FocusScope.of(
                                      context,
                                    ).requestFocus(_focusNode2);
                                  } else {
                                    if (int.parse(p0) == 0) {
                                      showToast(message: enterValidNumber.tr);
                                      FocusScope.of(
                                        context,
                                      ).requestFocus(_focusNode2);
                                    } else {
                                      if (int.parse(p0) <= 9) {
                                        profileController.monthController.text =
                                            '0$p0';
                                      }
                                      _focusNode2.unfocus();
                                      FocusScope.of(
                                        context,
                                      ).requestFocus(_focusNode3);
                                    }
                                  }
                                },
                                textFormatter: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(2),
                                ],
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: commonTextfield(
                                focusNode: _focusNode3,
                                controller: controller.yearController,
                                keyboardType: TextInputType.number,
                                hintText: "yyyy",
                                onChanged: (value) {
                                  if (value != null && value.isNotEmpty) {
                                    final enteredYear = int.tryParse(value);
                                    final currentYear = DateTime.now().year;
                                    if (enteredYear != null) {
                                      if (enteredYear > currentYear) {
                                        profileController.yearController.text =
                                            currentYear.toString();
                                        profileController
                                                .yearController
                                                .selection =
                                            TextSelection.fromPosition(
                                              TextPosition(
                                                offset:
                                                    profileController
                                                        .yearController
                                                        .text
                                                        .length,
                                              ),
                                            );
                                      } else if (enteredYear < 1) {
                                        profileController.yearController.text =
                                            '1';
                                        profileController
                                                .yearController
                                                .selection =
                                            TextSelection.fromPosition(
                                              TextPosition(
                                                offset:
                                                    profileController
                                                        .yearController
                                                        .text
                                                        .length,
                                              ),
                                            );
                                      }
                                    }
                                  }
                                  // if (value!.length == 4) {
                                  //   _focusNode3.unfocus();
                                  // }
                                },
                                onSubmitted: (p0) {
                                  if (profileController
                                      .yearController
                                      .text
                                      .isEmpty) {
                                    showToast(message: pleaseEnterYear.tr);
                                    FocusScope.of(
                                      context,
                                    ).requestFocus(_focusNode3);
                                  } else {
                                    _focusNode3.unfocus();
                                  }
                                },
                                textFormatter: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(4),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Obx(
                    () =>
                        controller.isShowLoader.value
                            ? showLoader()
                            : const SizedBox.shrink(),
                  ),
                ],
              ),
        ),
      ),
    );
  }

  pickImageDialog({
    required VoidCallback onCameraTap,
    required VoidCallback onGalleryTap,
  }) {
    return AlertDialog(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
      insetPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onCameraTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),

                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icCamera),
                          SizedBox(height: 10.h),
                          Text(
                            takeAPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.w),
              Expanded(
                child: GestureDetector(
                  onTap: onGalleryTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icGallery),
                          SizedBox(height: 10.h),
                          Text(
                            selectPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      // content: Container(
      //   decoration: BoxDecoration(
      //     borderRadius: BorderRadius.circular(14.r),
      //     color: AppColors.whiteColor,
      //   ),
      //   padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
      //   child: ,
      // ),
    );
  }
}
