import 'package:card_centering/apptheme/app_constants.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/setting_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../../apptheme/app_colors.dart';
import '../../../../../widgets/shimmer_widget.dart';
import 'create_support.dart';

class GetSupportScreen extends StatefulWidget {
  const GetSupportScreen({super.key});

  @override
  State<GetSupportScreen> createState() => _GetSupportScreenState();
}

class _GetSupportScreenState extends State<GetSupportScreen> {
  SettingController controller = Get.find<SettingController>();

  @override
  void initState() {
    controller.getSupportList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (ctrl) {
        return Scaffold(
          appBar: commonAppbar(title: getSupport.tr),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerFloat,
          floatingActionButton: GestureDetector(
            onTap: () {
              Get.to(() => const CreateSupportScreen());
            },
            child: Container(
              height: 50.h,
              width: 200.w,
              decoration: BoxDecoration(
                color: AppColors.primaryPurple,
                borderRadius: BorderRadius.circular(30.r),
              ),
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      supportRequests.tr,
                      style: AppTextStyle.medium18(
                        color:
                            isDarkMode()
                                ? AppColors.whiteColor
                                : AppColors.whiteColor,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Icon(Icons.add, size: 20.sp, color: AppColors.whiteColor),
                  ],
                ),
              ),
            ),
          ),
          body: Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 28.w),
              child: Column(
                children: [
                  SizedBox(height: 20.h),
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            controller.selectedSupportIndex = 0;
                            await controller.getSupportList();
                            controller.update();
                          },
                          child: Container(
                            height: 40.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30.r),
                              color:
                                  (controller.selectedSupportIndex == 0)
                                      ? AppColors.primaryPurple
                                      : isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyEBEBEB,
                            ),
                            child: Center(
                              child: Text(
                                openTickets.tr,
                                style: AppTextStyle.semiBold16(
                                  color:
                                      (controller.selectedSupportIndex == 0)
                                          ? AppColors.whiteColor
                                          : AppColors.grey9B9B9B,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 18.w),
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            controller.selectedSupportIndex = 1;
                            await controller.getSupportList();
                            controller.update();
                          },
                          child: Container(
                            height: 40.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30.r),
                              color:
                                  (controller.selectedSupportIndex == 1)
                                      ? AppColors.primaryPurple
                                      : isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyEBEBEB,
                            ),
                            child: Center(
                              child: Text(
                                closeTickets.tr,
                                style: AppTextStyle.semiBold16(
                                  color:
                                      (controller.selectedSupportIndex == 1)
                                          ? AppColors.whiteColor
                                          : AppColors.grey9B9B9B,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 26.h),
                  Expanded(
                    child: GetBuilder<SettingController>(
                      builder: (ctrl) {
                        if (controller.isSupportLoading.value == true) {
                          return showTickerShimmer();
                        } else if (controller.supportDataList.isEmpty) {
                          return Center(
                            child: SizedBox(
                              height: 200.h,
                              child: Text(
                                noTicket.tr,
                                style: AppTextStyle.semiBold22(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                            ),
                          );
                        } else {
                          return ListView.separated(
                            itemCount: ctrl.supportDataList.length,
                            separatorBuilder:
                                (BuildContext context, int index) =>
                                    SizedBox(height: 10.h),
                            padding: EdgeInsets.only(bottom: 80.h),
                            itemBuilder: (BuildContext context, int index) {
                              final supportData =
                                  controller.supportDataList[index];
                              return Container(
                                padding: EdgeInsets.all(18.sp),
                                decoration: BoxDecoration(border: Border.all(
                                  color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB
                                ),

                                  color:
                                      isDarkMode()
                                          ? AppColors.black1E1E1E
                                          : AppColors.whiteColor,
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      supportData.subject ?? '',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.semiBold18(
                                        color: isDarkMode() ?  AppColors.whiteColor : AppColors.black0D0C0C,
                                      ),
                                    ),
                                    Text(
                                      supportData.description ?? '',
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.medium15(
                                        color: AppColors.grey9B9B9B,
                                      ),
                                    ),
                                    SizedBox(height: 10.h),
                                    supportData.status == 'open'
                                        ? Container(
                                          height: 26.h,
                                          width: 64.w,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryPurple,
                                            borderRadius: BorderRadius.circular(
                                              4.r,
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              open.tr,
                                              style: AppTextStyle.semiBold14(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.whiteColor,
                                              ),
                                            ),
                                          ),
                                        )
                                        : Container(
                                          height: 26.h,
                                          width: 64.w,
                                          decoration: BoxDecoration(
                                            color: AppColors.redColor,
                                            borderRadius: BorderRadius.circular(
                                              4.r,
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              close.tr,
                                              style: AppTextStyle.semiBold14(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.whiteColor,
                                              ),
                                            ),
                                          ),
                                        ),
                                  ],
                                ),
                              );
                            },
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
