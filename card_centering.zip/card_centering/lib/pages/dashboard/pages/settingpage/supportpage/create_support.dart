import 'dart:io';

import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/setting_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/common_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../../apptheme/app_assets.dart';
import '../../../../../apptheme/app_colors.dart';
import '../../../../../apptheme/app_constants.dart';
import '../../../../../widgets/common_button.dart';

class CreateSupportScreen extends StatefulWidget {
  const CreateSupportScreen({super.key});

  @override
  State<CreateSupportScreen> createState() => _CreateSupportScreenState();
}

class _CreateSupportScreenState extends State<CreateSupportScreen> {

  @override
  Widget build(BuildContext context) {
    Get.find<SettingController>();
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        Get.find<SettingController>().sSubjectController.clear();
        Get.find<SettingController>().sEmailController.clear();
        Get.find<SettingController>().sDescriptionController.clear();
        Get.find<SettingController>().sAttachImage = '';
      },
      child: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: GetBuilder<SettingController>(
          builder:
              (controller) => Scaffold(
                appBar: commonAppbar(title: getSupport.tr),
                bottomNavigationBar: Obx(
                      () => Padding(
                  padding: EdgeInsets.all(20.sp),
                  child:
                        controller.isSupportLoading.value
                            ? Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(
                                  color: AppColors.primaryPurple,
                                ),
                              ],
                            )
                            : CommonButton(
                              onPressed: () {
                                controller.onSendRequestTap();
                              },
                              child: Text(
                                sendRequest.tr,
                                style: AppTextStyle.medium20(
                                  color: AppColors.whiteColor,
                                ),
                              ),
                            ),

                ),),
                body: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 15.h),
                        Text(
                          email.tr,
                          style: AppTextStyle.semiBold16(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 12.h),
                        commonTextfield(
                          hintText: enterMail.tr,
                          controller: controller.sEmailController,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        SizedBox(height: 20.h),
                        Text(
                          subject.tr,
                          style: AppTextStyle.semiBold16(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 12.h),
                        commonTextfield(
                          hintText: enterSubject.tr,
                          controller: controller.sSubjectController,
                        ),
                        SizedBox(height: 20.h),
                        Text(
                          description.tr,
                          style: AppTextStyle.semiBold16(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 12.h),
                        commonTextfield(
                          hintText: enterDesc.tr,
                          controller: controller.sDescriptionController,
                          maxLines: 5
                        ),
                        SizedBox(height: 20.h),
                        Text(
                          attachImage.tr,
                          style: AppTextStyle.semiBold16(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        SizedBox(height: 12.h),
                        GetBuilder<SettingController>(
                          builder: (ctrl) {
                            return GestureDetector(
                              onTap: () async {
                                showDialog(
                                  context: context,
                                  builder:
                                      (context) => pickImageDialog(
                                        onCameraTap: () async {
                                          Get.back();
                                          await ctrl.pickBugImage(
                                            source: ImageSource.camera,
                                          );
                                        },
                                        onGalleryTap: () async {
                                          Get.back();
                                          await ctrl.pickBugImage(
                                            source: ImageSource.gallery,
                                          );
                                        },
                                      ),
                                );
                              },
                              child: Container(
                                padding: EdgeInsets.only(
                                  left: 20.sp,
                                  right: 5.sp,
                                ),
                                height: 55.h,
                                width: Get.width,
                                alignment: Alignment.centerLeft,
                                decoration: BoxDecoration(
                                  color:
                                      isDarkMode()
                                          ? AppColors.black1E1E1E
                                          : AppColors.whiteColor,
                                  border: Border.all(
                                    width: 1,
                                    color:
                                        isDarkMode()
                                            ? AppColors.grey2A2A2A
                                            : const Color(0xffD8DDE3),
                                  ),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.r),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.attachment_rounded,
                                      color: isDarkMode() ?  AppColors.whiteColor :  AppColors.black0D0C0C,
                                    ),
                                    SizedBox(width: 10.w),
                                    (controller.sAttachImage == null ||
                                            controller.sAttachImage!.isEmpty)
                                        ? Text(
                                          attachDoc.tr,
                                          style: AppTextStyle.medium16(
                                            color: AppColors.grey9B9B9B,
                                          ),
                                        )
                                        : Padding(
                                          padding: const EdgeInsets.all(3),
                                          child: SizedBox(
                                            width: 80,
                                            child: Image.file(
                                              File(controller.sAttachImage!),
                                            ),
                                          ),
                                        ),

                                    (controller.sAttachImage != null ||
                                            controller.sAttachImage!.isNotEmpty)
                                        ? Padding(
                                          padding: EdgeInsets.only(left: 10.w),
                                          child: InkWell(
                                            onTap: () {
                                              controller.sAttachImage = '';
                                              controller.update();
                                            },
                                            child: Icon(
                                              Icons.cancel,
                                              color: isDarkMode() ?  AppColors.whiteColor : AppColors.black0D0C0C,
                                              size: 20.sp,
                                            ),
                                          ),
                                        )
                                        : const SizedBox.shrink(),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
        ),
      ),
    );
  }

  pickImageDialog({
    required VoidCallback onCameraTap,
    required VoidCallback onGalleryTap,
  }) {
    return AlertDialog(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
      insetPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onCameraTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),

                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icCamera),
                          SizedBox(height: 10.h),
                          Text(
                            takeAPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.w),
              Expanded(
                child: GestureDetector(
                  onTap: onGalleryTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icGallery),
                          SizedBox(height: 10.h),
                          Text(
                            selectPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
