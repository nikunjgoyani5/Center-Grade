import 'dart:io';

import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:card_centering/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../controllers/dashboardcontrollers/setting_controller.dart';
import '../../../../widgets/common_appbar.dart';
import '../../../../widgets/common_textfield.dart';

class ChangePassword extends StatelessWidget {
  const ChangePassword({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: GetBuilder<SettingController>(
        builder: (controller) {
          return Scaffold(
            appBar: commonAppbar(title: changePass.tr),
            bottomNavigationBar: Padding(
              padding: EdgeInsets.only(
                left: 20.w,
                right: 20.w,
                bottom: Platform.isIOS ? 40.h : 20.h,
              ),
              child: CommonButton(
                buttonColor:
                    (controller.oldPassController.text.isEmpty ||
                            controller.newPassController.text.isEmpty ||
                            controller.confirmNewPassController.text.isEmpty)
                        ? AppColors.disableColorDark
                        : AppColors.primaryPurple,
                buttonHeight: 55.h,
                onPressed: () async {
                  await Get.find<SettingController>().changePasswordTapped();
                },
                child: Text(
                  changePass.tr,
                  style: AppTextStyle.medium20(
                    color:
                        (controller.oldPassController.text.isEmpty ||
                                controller.newPassController.text.isEmpty ||
                                controller
                                    .confirmNewPassController
                                    .text
                                    .isEmpty)
                            ? AppColors.disableWhiteColor
                            : AppColors.whiteColor,
                  ),
                ),
              ),
            ),
            body: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 15.h),
                      Text(
                        currentPass.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      GetBuilder<SettingController>(
                        builder:
                            (controller) => commonTextfield(
                              onChanged: (value) {
                                controller.update();
                              },
                              isObscure: !controller.isOldPasswordVisible,
                              suffixWidget: Column(
                                mainAxisAlignment: MainAxisAlignment.center,

                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      controller.oldPasswordVisibility();
                                    },
                                    child: SvgPicture.asset(
                                      controller.isOldPasswordVisible
                                          ? AppAssets.icVisible
                                          : AppAssets.icVisibleOff,
                                    ),
                                  ),
                                ],
                              ),
                              controller: controller.oldPassController,
                              hintText: currentPass.tr,
                            ),
                      ),
                      SizedBox(height: 15.h),
                      Text(
                        newPassword.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      GetBuilder<SettingController>(
                        builder:
                            (controller) => commonTextfield(
                              onChanged: (value) {
                                controller.update();
                              },
                              isObscure: !controller.isNewPasswordVisible,
                              suffixWidget: Column(
                                mainAxisAlignment: MainAxisAlignment.center,

                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      controller.newPasswordVisibility();
                                    },
                                    child: SvgPicture.asset(
                                      controller.isNewPasswordVisible
                                          ? AppAssets.icVisible
                                          : AppAssets.icVisibleOff,
                                    ),
                                  ),
                                ],
                              ),
                              controller: controller.newPassController,
                              hintText: newPassword.tr,
                            ),
                      ),
                      SizedBox(height: 15.h),
                      Text(
                        reTypeNewPass.tr,
                        style: AppTextStyle.medium20(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      GetBuilder<SettingController>(
                        builder:
                            (controller) => commonTextfield(
                              onChanged: (value) {
                                controller.update();
                              },
                              isObscure: !controller.isConfirmPasswordVisible,
                              suffixWidget: Column(
                                mainAxisAlignment: MainAxisAlignment.center,

                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      controller.confirmPasswordVisibility();
                                    },
                                    child: SvgPicture.asset(
                                      controller.isConfirmPasswordVisible
                                          ? AppAssets.icVisible
                                          : AppAssets.icVisibleOff,
                                    ),
                                  ),
                                ],
                              ),
                              controller: controller.confirmNewPassController,
                              hintText: reTypeNewPass.tr,
                            ),
                      ),
                    ],
                  ),
                ),
                Obx(
                  () =>
                      controller.isShowLoader.value
                          ? showLoader()
                          : SizedBox.shrink(),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
