import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(title: "FAQ"),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 0.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              faqWidget(
                question: "What is CenterGrade?",
                answer:
                    "CenterGrade is a smart utility benchmarking and optimization app that helps property owners, managers, and energy consultants monitor, analyze, and reduce utility consumption. It provides insights, analytics, and automated recommendations to improve energy efficiency and sustainability performance.",
              ),
              SizedBox(height: 10.h),
              Divider(color:   isDarkMode()
                  ? AppColors.grey2A2A2A
                  : AppColors.greyEBEBEB),
              SizedBox(height: 10.h),
              // Text("Who is CenterGrade for?",style: AppTextStyle.medium20(color: AppColors.black0D0C0C)),
              // SizedBox(height: 8.h),
              // Text("CenterGrade is ideal for:",style: AppTextStyle.medium16(color: AppColors.grey9B9B9B)),
              faqWidget(
                question: "Who is CenterGrade for?",
                answer:
                    """CenterGrade is ideal for: \n   •  Commercial property managers \n   •  Building owners \n   •  Energy consultants \n   •  Sustainability professionals \n   •  Government agencies and municipalities""",
              ),
              SizedBox(height: 10.h),
              Divider(color:  isDarkMode()
                  ? AppColors.grey2A2A2A
                  :  AppColors.greyEBEBEB),
              SizedBox(height: 10.h),
              faqWidget(
                question: "How does CenterGrade work?",
                answer:
                    "CenterGrade integrates with utility data providers and building systems to collect energy usage data. It then analyzes this data using benchmarking standards (like ENERGY STAR®), offers performance grades, and provides actionable insights to improve energy performance.",
              ),
              SizedBox(height: 10.h),
              Divider(color:  isDarkMode()
                  ? AppColors.grey2A2A2A
                  :  AppColors.greyEBEBEB),
              SizedBox(height: 10.h),
              faqWidget(
                question: "What types of utilities does CenterGrade track?",
                answer:
                    """Currently, CenterGrade supports: \n   •  Electricity \n   •  Natural gas \n   •  Water \n   •  Steam and chilled water (where applicable)""",
              ),
              SizedBox(height: 10.h),
              Divider(color:  isDarkMode()
                  ? AppColors.grey2A2A2A
                  :  AppColors.greyEBEBEB),
              SizedBox(height: 10.h),
              faqWidget(
                question: "Is my data secure with CenterGrade?",
                answer:
                    "Absolutely. We take data privacy and security seriously. All user data is encrypted in transit and at rest, and we comply with industry best practices to ensure your data is protected.",
              ),
              SizedBox(height: 20.h)
            ],
          ),
        ),
      ),
    );
  }

  faqWidget({required String question, required String answer}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question,
          style: AppTextStyle.semiBold20(color: isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C),
        ),
        SizedBox(height: 8.h),
        Text(answer, style: AppTextStyle.medium16(color: AppColors.grey9B9B9B)),
      ],
    );
  }
}
