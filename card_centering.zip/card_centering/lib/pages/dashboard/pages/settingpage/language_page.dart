import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/dashboardcontrollers/setting_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/common_appbar.dart';

class LanguagePage extends StatelessWidget {
  const LanguagePage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(SettingController());
    return Scaffold(
      backgroundColor:   isDarkMode()
          ? AppColors.black121212
          : AppColors.whiteColor,
      appBar: commonAppbar(title: language.tr),
      body: GetBuilder<SettingController>(
        builder: (controller) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
            child: Column(
              children: List.generate(controller.languageList.length, (index) {
                final language = controller.languageList[index];
                return Obx(
                  () => GestureDetector(
                    onTap: () {
                      controller.onLanguageSelect(value: language);
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 15.h),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.r),
                        color:   isDarkMode()
                            ? AppColors.black121212
                            : AppColors.whiteColor,
                        border: Border.all(
                          color:
                              controller.selectedLanguage.value == language['name']
                                  ? AppColors.primaryPurple
                                  :   isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                          width: 1.5,
                        ),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 15.w,
                        vertical: 15.h,
                      ),
                      child: Row(
                        children: [
                          Checkbox(
                            checkColor: AppColors.whiteColor,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            side: BorderSide(color:   isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderD9D9D9),
                            visualDensity: VisualDensity(
                              horizontal: VisualDensity.minimumDensity,
                              vertical: VisualDensity.minimumDensity,
                            ),
                            activeColor: AppColors.primaryPurple,
                            value:
                                controller.selectedLanguage.value == language['name'],
                            onChanged: (value) {
                              controller.onLanguageSelect(value: language);
                            },
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4.r),
                            ),
                          ),
                          SizedBox(width: 10.w),
                          Text(
                            language['name'],
                            style: AppTextStyle.medium20(
                              color:   isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          );
        },
      ),
    );
  }
}
