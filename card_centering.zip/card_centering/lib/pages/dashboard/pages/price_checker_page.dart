import 'dart:async';

import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../apptheme/app_assets.dart';
import '../../../apptheme/app_colors.dart';
import '../../../apptheme/app_constants.dart';
import '../../../apptheme/app_textstyle.dart';
import '../../../controllers/dashboardcontrollers/search_controller.dart';
import '../../../widgets/common_appbar.dart';
import '../../../widgets/common_textfield.dart';
import '../../../widgets/shimmer_widget.dart';
import 'searchcard/card_info_screen.dart';

class PriceCheckerPage extends StatefulWidget {
  const PriceCheckerPage({super.key});

  @override
  State<PriceCheckerPage> createState() => _PriceCheckerPageState();
}

class _PriceCheckerPageState extends State<PriceCheckerPage> {
  Timer? _debounce;

  @override
  Widget build(BuildContext context) {
    Get.put(SearchCardController());
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(title: search.tr),
        body: GetBuilder<SearchCardController>(
          builder:
              (searchController) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Column(
                  children: [
                    GetBuilder<SearchCardController>(
                      builder:
                          (controller) => commonTextfield(
                            controller: controller.searchController,
                            hintText: searchCard.tr,
                            onChanged: (value) async {
                              if (_debounce?.isActive ?? false) {
                                _debounce?.cancel();
                              }
                              _debounce = Timer(500.milliseconds, () async {
                                await controller.searchCard();
                              });
                            },
                            prefixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  AppAssets.icSearch,
                                  height: 22,
                                  width: 22,
                                  colorFilter: ColorFilter.mode(
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                                    BlendMode.srcIn,
                                  ),
                                ),
                              ],
                            ),
                            suffixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Obx(
                                  () =>
                                      controller.isShowClosed.value
                                          ? GestureDetector(
                                            onTap: () {
                                              controller.searchController
                                                  .clear();
                                              controller.searchProducts.clear();
                                              controller.update();
                                            },
                                            child: SvgPicture.asset(
                                              AppAssets.icClose,
                                              colorFilter: ColorFilter.mode(
                                                isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C,
                                                BlendMode.srcIn,
                                              ),
                                              height: 15,
                                              width: 15,
                                            ),
                                          )
                                          : const SizedBox.shrink(),
                                ),
                              ],
                            ),
                          ),
                    ),
                    SizedBox(height: 20.h),
                    Expanded(
                      child: Obx(
                        () =>
                            searchController.isSearchLoader.value
                                ? showSearchShimmer()
                                : searchController.searchProducts.isEmpty
                                ? Center(
                                  child: Text(
                                    noCard.tr,
                                    style: AppTextStyle.semiBold22(
                                      color:
                                          isDarkMode()
                                              ? AppColors.whiteColor
                                              : AppColors.black0D0C0C,
                                    ),
                                  ),
                                )
                                : ListView.separated(
                                  itemCount:
                                      searchController.searchProducts.length,
                                  itemBuilder: (context, index) {
                                    final productData =
                                        searchController.searchProducts[index];
                                    return Container(
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                        ),
                                      ),

                                      child: ListTile(
                                        onTap: () {
                                          Get.to(
                                            () => CardInfoScreen(
                                              cardId: productData.id ?? '',
                                              isPriceCheck: true,
                                            ),
                                            transition:
                                                Transition.rightToLeftWithFade,
                                          );
                                        },
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 15.w,
                                        ),
                                        // leading: Container(
                                        //   height: 50.h,
                                        //   width: 40.w,
                                        //   decoration: BoxDecoration(
                                        //     borderRadius: BorderRadius.circular(12.r),
                                        //     color: AppColors.transparent,
                                        //   ),
                                        //   child: Image.asset(
                                        //     AppAssets.imgPlaceHolder,
                                        //     height: 50.h,
                                        //     width: 40.w,
                                        //   ),
                                        // ),
                                        dense: true,
                                        title: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              productData.productName ?? "",
                                              style: AppTextStyle.medium20(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.black0D0C0C,
                                              ),
                                            ),
                                            Text(
                                              productData.loosePrice
                                                      ?.formatPrice() ??
                                                  '',
                                              style: AppTextStyle.medium17(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.grey9B9B9B
                                                        : AppColors
                                                            .primaryPurple,
                                              ),
                                            ),
                                          ],
                                        ),
                                        // trailing: Icon(
                                        //   Icons.arrow_forward_ios,
                                        //   size: 22.h,
                                        //   color: AppColors.greyCBCBCF,
                                        // ),
                                        // trailing: Text(
                                        //   productData?.loosePrice?.formatPrice() ?? '',
                                        //   style: AppTextStyle.semiBold16(),
                                        // ),
                                      ),
                                    );
                                  },
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10.h);
                                  },
                                ),
                      ),
                    ),
                  ],
                ),
              ),
        ),
      ),
    );
  }
}
