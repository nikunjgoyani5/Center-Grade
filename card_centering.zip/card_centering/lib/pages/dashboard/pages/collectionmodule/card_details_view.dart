import 'package:card_centering/controllers/dashboardcontrollers/collection_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_strings.dart';
import '../../../../apptheme/app_textstyle.dart';

class CardDetailsView extends StatefulWidget {
  final String cardId;

  const CardDetailsView({super.key, required this.cardId});

  @override
  State<CardDetailsView> createState() => _CardDetailsViewState();
}

class _CardDetailsViewState extends State<CardDetailsView> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Get.find<CollectionController>().singleCardDetailsApi(
        cardId: widget.cardId,
      );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Get.find<CollectionController>();
    return Scaffold(
      appBar: commonAppbar(title: cardDetails.tr),
      body: GetBuilder<CollectionController>(
        builder:
            (controller) => Obx(
              () =>
                  controller.isShowLoader.value
                      ? showScanCardShimmer()
                      : Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Column(
                          children: [
                            SizedBox(height: 20.h),
                            Container(
                              height: 400.h,
                              width: 250.w,
                              color: Colors.transparent,
                              child: Image.network(
                                controller.singleCardDetails?.frontImageUrl ??
                                    '',
                                errorBuilder: (context, error, stackTrace) {
                                  return Image.asset(AppAssets.imgPlaceHolder);
                                },
                              ),
                            ),
                            // SizedBox(height: 20.h),
                            Text(
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.name
                                          ?.isEmpty ==
                                      null
                                  ? 'Card 1'
                                  : controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.name ??
                                      'Card 1',
                              style: AppTextStyle.medium24(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                            // SizedBox(height: 12.h),
                            Expanded(child: gradingWidget()),
                          ],
                        ),
                      ),
            ),
      ),
    );
  }

  priceWidget({required String title, required String value}) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
          border: Border.all(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        ),
        padding: EdgeInsets.symmetric(horizontal: 22.w, vertical: 12.h),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: AppTextStyle.semiBold16(color: AppColors.grey9B9B9B),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
              ),
              // SizedBox(height: 5.h), // Optional spacing
              Text(
                value,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  gradingWidget() {
    return GetBuilder<CollectionController>(
      builder:
          (controller) => SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 20.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.whiteColor,
                          border: Border.all(
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyEBEBEB,
                          ),
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 12.w,
                          vertical: 10.h,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              lrText.tr,
                              style: AppTextStyle.medium17(
                                color: AppColors.grey9B9B9B,
                              ),
                            ),
                            Text(
                              controller
                                      .singleCardDetails
                                      ?.frontDetails
                                      ?.leftRight ??
                                  '-',
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.whiteColor,
                          border: Border.all(
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyEBEBEB,
                          ),
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 12.w,
                          vertical: 10.h,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              tbText.tr,
                              style: AppTextStyle.medium17(
                                color: AppColors.grey9B9B9B,
                              ),
                            ),
                            // SizedBox(width: 20.w),
                            Text(
                              controller
                                      .singleCardDetails
                                      ?.frontDetails
                                      ?.bottomTop ??
                                  '-',
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 15.h),
                infoWidget(
                  title: centering.tr,
                  value:
                      controller.singleCardDetails?.frontDetails?.centering?.toString() ??
                      '-',
                ),
                // Divider(
                //   color:
                //       isDarkMode()
                //           ? AppColors.grey2A2A2A
                //           : AppColors.greyEBEBEB,
                // ),
                // infoWidget(title: edges.tr, value: "9.5"),
                // Divider(
                //   color:
                //       isDarkMode()
                //           ? AppColors.grey2A2A2A
                //           : AppColors.greyEBEBEB,
                // ),
                // infoWidget(title: corners.tr, value: "9.5"),
                Divider(
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.greyEBEBEB,
                ),
                infoWidget(
                  title: aiGrade.tr,
                  value:
                      controller.singleCardDetails?.frontDetails?.aiGrade ??
                      '-',
                ),
                Divider(
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.greyEBEBEB,
                ),
                infoWidget(
                  title: cardSide.tr,
                  value:
                      controller.singleCardDetails?.frontDetails?.cardSide ??
                      '-',
                ),
                Divider(
                  color:
                      isDarkMode()
                          ? AppColors.grey2A2A2A
                          : AppColors.greyEBEBEB,
                ),
                infoWidget(
                  title: category.tr,
                  value:
                      controller.singleCardDetails?.frontDetails?.category ??
                      '-',
                ),
                SizedBox(height: 20.h),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        priceWidget(
                          title: ungraded.tr,
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .ungradedPrice!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.ungradedPrice ??
                                      '-',
                        ),
                        SizedBox(width: 12.w),
                        priceWidget(
                          title: "${grade.tr} 7",
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .grade7Price!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.grade7Price ??
                                      '-',
                        ),
                        SizedBox(width: 12.w),

                        priceWidget(
                          title: "${grade.tr} 8",
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .grade8Price!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.grade8Price ??
                                      '-',
                        ),
                      ],
                    ),
                    SizedBox(height: 15.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        priceWidget(
                          title: "${grade.tr} 9",
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .grade95Price!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.grade9Price ??
                                      '-',
                        ),
                        SizedBox(width: 12.w),

                        priceWidget(
                          title: "${grade.tr} 9.5",
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .grade95Price!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.grade95Price ??
                                      '-',
                        ),
                        SizedBox(width: 12.w),

                        priceWidget(
                          title: "PSA 10",
                          value:
                              // controller
                              //         .singleCardDetails!
                              //         .priceCheckerDetails!
                              //         .psa10Price!
                              //         .isEmpty
                              //     ? "-"
                              //     :
                              controller
                                          .singleCardDetails
                                          ?.priceCheckerDetails
                                          ?.psa10Price ??
                                      '-',
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 100.h),
              ],
            ),
          ),
    );
  }

  infoWidget({required String title, required String value}) {
    return Container(
      color: Colors.transparent,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$title:",
            style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
          ),
          Text(
            value,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
        ],
      ),
    );
  }
}
