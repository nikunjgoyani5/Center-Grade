import 'package:card_centering/controllers/dashboardcontrollers/collection_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';
import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_strings.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/shimmer_widget.dart';
import 'card_details_view.dart';

class CollectionView extends StatefulWidget {
  final String collectionName;
  final String collectionId;

  const CollectionView({
    super.key,
    required this.collectionName,
    required this.collectionId,
  });

  @override
  State<CollectionView> createState() => _CollectionViewState();
}

class _CollectionViewState extends State<CollectionView> {
  @override
  void initState() {
    Get.find<CollectionController>().fetchCollectionCardsList(
      collectionId: widget.collectionId,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Get.find<CollectionController>();
    return Scaffold(
      appBar: commonAppbar(title: widget.collectionName),
      body: GetBuilder<CollectionController>(
        builder:
            (controller) => Obx(
              () =>
                  controller.isCardsCollectionLoader.value
                      ? showCardsCollectionShimmer()
                      : controller.collectionCardsList.isEmpty
                      ? Center(
                        child: Text(
                          noCardsAvailable.tr,
                          textAlign: TextAlign.center,
                          style: AppTextStyle.semiBold20(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                      )
                      : GridView.builder(
                        padding: EdgeInsets.only(
                          left: 20.w,
                          right: 20.w,
                          top: 10.h,
                          bottom: 30.h
                        ),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 15,
                          mainAxisSpacing: 15,
                          childAspectRatio: 3 / 3,
                        ),
                        itemCount: controller.collectionCardsList.length,
                        itemBuilder: (context, index) {
                          final collectionCardData =
                              controller.collectionCardsList[index];
                          return GestureDetector(
                            onTap: () {
                              Get.to(
                                () => CardDetailsView(
                                  cardId: collectionCardData.id ?? '',
                                ),
                                transition: Transition.rightToLeftWithFade,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15.r),
                                color:
                                    isDarkMode()
                                        ? AppColors.black1E1E1E
                                        : AppColors.whiteColor,
                                border: Border.all(
                                  color:
                                      isDarkMode()
                                          ? AppColors.grey2A2A2A
                                          : AppColors.greyEBEBEB,
                                ),
                              ),
                              // padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(height: 20.h),
                                  Center(
                                    child: Image.network(
                                      collectionCardData.frontImageUrl ?? '',
                                      height: 100.h,
                                      width: 100.w,
                                      loadingBuilder: (
                                        context,
                                        child,
                                        loadingProgress,
                                      ) {
                                        if (loadingProgress == null) {
                                          return child; // Image is fully loaded
                                        }
                                        return Shimmer.fromColors(
                                          baseColor:
                                              isDarkMode()
                                                  ? AppColors.grey2A2A2A
                                                  : Colors.grey[300]!,
                                          highlightColor:
                                              isDarkMode()
                                                  ? AppColors.grey9B9B9B
                                                  : Colors.grey[100]!,
                                          child: Container(
                                            height: 100.h,
                                            width: 80.w,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10.r),
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.grey2A2A2A
                                                      : AppColors.whiteColor,
                                            ),
                                          ),
                                        );
                                      },
                                      errorBuilder: (
                                        context,
                                        error,
                                        stackTrace,
                                      ) {
                                        return Image.asset(
                                          AppAssets.imgPlaceHolder,
                                          height: 100.h,
                                          width: 100.w,
                                        );
                                      },
                                    ),
                                  ),

                                  // SizedBox(height: 15.h),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 15.w),
                                          child: Text(
                                            collectionCardData
                                                    .priceCheckerDetails!
                                                    .name!
                                                    .isEmpty
                                                ? "Card"
                                                : collectionCardData
                                                        .priceCheckerDetails
                                                        ?.name ??
                                                    'Card',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: AppTextStyle.medium18(
                                              color:
                                                  isDarkMode()
                                                      ? AppColors.whiteColor
                                                      : AppColors.black0D0C0C,
                                            ),
                                          ),
                                        ),
                                      ),
                                      moreMenuWidget(
                                        collectionId: widget.collectionId,
                                        cardId: collectionCardData.id ?? '',
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
            ),
      ),
    );
  }

  moreMenuWidget({required String collectionId, required String cardId}) {
    return PopupMenuButton<int>(
      color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.whiteColor,
      icon: SvgPicture.asset(
        AppAssets.icMore,
        colorFilter: ColorFilter.mode(
          isDarkMode() ? AppColors.greyCCCCCC : AppColors.black,
          BlendMode.srcIn,
        ),
      ),
      padding: EdgeInsets.zero,
      menuPadding: EdgeInsets.zero,
      itemBuilder: (context) {
        return [
          PopupMenuItem(
            onTap: () async {
              await Get.find<CollectionController>().removeCardApi(
                collectionId: collectionId,
                cardId: cardId,
              );
            },
            child: Row(
              children: [
                SvgPicture.asset(
                  AppAssets.icDelete,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  delete.tr,
                  style: AppTextStyle.medium16(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ],
            ),
          ),
        ];
      },
    );
  }
}
