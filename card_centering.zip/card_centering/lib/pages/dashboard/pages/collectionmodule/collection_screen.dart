import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/dashboardcontrollers/collection_controller.dart';
import 'package:card_centering/widgets/common_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/common_appbar.dart';
import '../../../../widgets/common_textfield.dart';
import '../../../../widgets/shimmer_widget.dart';
import 'collection_view.dart';

class CollectionScreen extends StatefulWidget {
  const CollectionScreen({super.key});

  @override
  State<CollectionScreen> createState() => _CollectionScreenState();
}

class _CollectionScreenState extends State<CollectionScreen> {
  final collectionController = Get.put(CollectionController());

  @override
  void initState() {
    collectionController.fetchCollectionList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
      appBar: commonAppbar(title: myCollection.tr, isShowBackButton: false),

      body: GetBuilder<CollectionController>(
        builder:
            (collectionController) => Obx(
              () =>
                  collectionController.isShowLoader.value
                      ? showCollectionShimmer()
                      : collectionController.collectionList.isEmpty
                      ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return addCollectionFieldDialog();
                                  },
                                );
                              },
                              child: SvgPicture.asset(
                                isDarkMode()
                                    ? AppAssets.icEmptyCollectionDark
                                    : AppAssets.icEmptyCollection,
                              ),
                            ),
                            SizedBox(height: 20.h),
                            Text(
                              createNewCollection.tr,
                              style: AppTextStyle.medium24(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                            Text(
                              addCards.tr,
                              textAlign: TextAlign.center,
                              style: AppTextStyle.medium17(
                                color: AppColors.grey9B9B9B,
                              ),
                            ),
                            SizedBox(height: 15.h),
                            CommonButton(
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return addCollectionFieldDialog();
                                  },
                                );
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.w),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset(
                                      AppAssets.icAddWhite,
                                      width: 16,
                                      height: 16,
                                    ),
                                    SizedBox(width: 12.w),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 4.h),
                                      child: Text(
                                        createCollection.tr,
                                        style: AppTextStyle.medium20(
                                          color: AppColors.whiteColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                      : GridView.builder(
                        padding: EdgeInsets.only(
                          left: 20.w,
                          right: 20.w,
                          top: 20.h,
                          bottom: 20.h,
                        ),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          // childAspectRatio: 5 / 4,
                        ),
                        itemCount:
                            collectionController.collectionList.length + 1,
                        itemBuilder: (context, index) {
                          if (collectionController.collectionList.length ==
                              index) {
                            return GestureDetector(
                              onTap: () {
                                collectionController.collectionNameController
                                    .clear();
                                collectionController.isFieldEmpty = true;
                                collectionController.update();
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return addCollectionFieldDialog();
                                  },
                                );
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color:
                                      isDarkMode()
                                          ? AppColors.black1E1E1E
                                          : AppColors.whiteColor,
                                  border: Border.all(
                                    color:
                                        isDarkMode()
                                            ? AppColors.grey2A2A2A
                                            : AppColors.greyEBEBEB,
                                  ),
                                  borderRadius: BorderRadius.circular(15.r),
                                ),
                                padding: EdgeInsets.only(
                                  top: 15.h,
                                  bottom: 15.h,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        showDialog(
                                          context: context,
                                          builder: (context) {
                                            return addCollectionFieldDialog();
                                          },
                                        );
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color:
                                              isDarkMode()
                                                  ? AppColors.black1E1E1E
                                                  : AppColors.whiteFAFAFA,
                                          border: Border.all(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                        ),
                                        padding: EdgeInsets.all(20.r),
                                        child: SvgPicture.asset(
                                          AppAssets.icAddWhite,
                                          colorFilter: ColorFilter.mode(
                                            isDarkMode()
                                                ? AppColors.whiteColor
                                                : AppColors.black0D0C0C,
                                            BlendMode.srcIn,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 12.h),
                                    Text(
                                      addCollection.tr,
                                      style: AppTextStyle.medium20(
                                        color:
                                            isDarkMode()
                                                ? AppColors.whiteColor
                                                : AppColors.black0D0C0C,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }
                          final collectionData =
                              collectionController.collectionList[index];
                          return GestureDetector(
                            onTap: () {
                              Get.to(
                                () => CollectionView(
                                  collectionName: collectionData.name ?? '',
                                  collectionId: collectionData.id ?? '',
                                ),
                                transition: Transition.rightToLeftWithFade,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color:
                                    isDarkMode()
                                        ? AppColors.black1E1E1E
                                        : AppColors.whiteColor,
                                border: Border.all(
                                  color:
                                      isDarkMode()
                                          ? AppColors.grey2A2A2A
                                          : AppColors.greyEBEBEB,
                                ),
                                borderRadius: BorderRadius.circular(15.r),
                              ),
                              padding: EdgeInsets.only(
                                left: 15.w,
                                top: 15.h,
                                bottom: 15.h,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      SvgPicture.asset(AppAssets.icFolder),
                                      moreMenuWidget(
                                        collectionId: collectionData.id ?? '',
                                        collectionName:
                                            collectionData.name ?? '',
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 15.h),
                                  Expanded(
                                    child: Text(
                                      collectionData.name ?? '',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.medium22(
                                        color:
                                            isDarkMode()
                                                ? AppColors.whiteColor
                                                : AppColors.black0D0C0C,
                                      ),
                                    ),
                                  ),
                                  collectionData.itemCount == 0
                                      ? Text(
                                        noCardsYet.tr,
                                        style: AppTextStyle.medium17(
                                          color: AppColors.grey9B9B9B,
                                        ),
                                      )
                                      : Text(
                                        "${collectionData.itemCount} ${items.tr}",
                                        style: AppTextStyle.medium17(
                                          color: AppColors.grey9B9B9B,
                                        ),
                                      ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
            ),
      ),
    );
  }

  addCollectionFieldDialog() {
    return GetBuilder<CollectionController>(
      builder:
          (controller) => Dialog(
            insetPadding: EdgeInsets.symmetric(horizontal: 20.w),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.r),
            ),
            backgroundColor:
                isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
            // contentPadding: EdgeInsets.zero,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(),
                      Text(
                        createCollection.tr,
                        style: AppTextStyle.semiBold24(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),

                      GestureDetector(
                        onTap: () {
                          Get.back();
                          controller.collectionNameController.clear();
                          controller.isFieldEmpty = true;
                          controller.update();
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyF6F6F6,
                          ),
                          padding: EdgeInsets.all(10.r),
                          child: SvgPicture.asset(
                            AppAssets.icClose,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                              BlendMode.srcIn,
                            ),
                            height: 14,
                            width: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.h),
                  Text(
                    nameYourCollection.tr,
                    style: AppTextStyle.medium20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  commonTextfield(
                    onChanged: (value) {
                      controller.onAddFieldChange();
                    },
                    controller: controller.collectionNameController,
                    hintText: "e.g. PSA 10s, Vintage Fire Set",
                  ),
                  Text(
                    youCanChangeThis.tr,
                    style: AppTextStyle.medium18(
                      color:
                          isDarkMode()
                              ? AppColors.blackB3B3B3
                              : AppColors.grey9B9B9B,
                    ),
                  ),

                  SizedBox(height: 20.h),
                  CommonButton(
                    onPressed:
                        controller.isFieldEmpty == true
                            ? () {}
                            : () async {
                              Get.back();
                              await controller.createCollectionApi();
                            },
                    buttonColor:
                        controller.isFieldEmpty
                            ? isDarkMode()
                                ? AppColors.disableColorDark
                                : AppColors.disableColor
                            : AppColors.primaryPurple,
                    buttonWidth: double.infinity,
                    child: Text(
                      continueText.tr,
                      style: AppTextStyle.medium20(
                        color:
                            controller.isFieldEmpty
                                ? AppColors.whiteColor.withValues(alpha: 0.4)
                                : AppColors.whiteColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }

  renameFieldDialog({required String collectionId}) {
    return GetBuilder<CollectionController>(
      builder:
          (controller) => AlertDialog(
            insetPadding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.r),
            ),
            backgroundColor:
                isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
            contentPadding: EdgeInsets.zero,
            content: Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(),
                      Text(
                        renameCollection.tr,
                        style: AppTextStyle.semiBold24(
                          color:
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                        ),
                      ),

                      GestureDetector(
                        onTap: () => Get.back(),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyF6F6F6,
                          ),
                          padding: EdgeInsets.all(10.r),
                          child: SvgPicture.asset(
                            AppAssets.icClose,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.black0D0C0C,
                              BlendMode.srcIn,
                            ),
                            height: 14,
                            width: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.h),
                  Text(
                    renameYourCollection.tr,
                    style: AppTextStyle.medium20(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  commonTextfield(
                    onChanged: (value) {
                      controller.onAddFieldChange();
                    },
                    controller: controller.collectionNameController,
                    hintText: "e.g. PSA 10s, Vintage Fire Set",
                  ),
                  SizedBox(height: 20.h),
                  CommonButton(
                    onPressed:
                        controller.isFieldEmpty == true
                            ? () {}
                            : () async {
                              Get.back();
                              await controller.updateCollection(
                                collectionId: collectionId,
                              );
                            },
                    buttonColor:
                        controller.isFieldEmpty
                            ? isDarkMode()
                                ? AppColors.disableColorDark
                                : AppColors.disableColor
                            : AppColors.primaryPurple,
                    buttonWidth: double.infinity,
                    child: Text(
                      continueText.tr,
                      style: AppTextStyle.medium20(
                        color:
                            controller.isFieldEmpty
                                ? AppColors.whiteColor.withValues(alpha: 0.4)
                                : AppColors.whiteColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }

  moreMenuWidget({
    required String collectionId,
    required String collectionName,
  }) {
    return PopupMenuButton<int>(
      color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.whiteColor,
      icon: SvgPicture.asset(
        AppAssets.icMore,
        colorFilter: ColorFilter.mode(
          isDarkMode() ? AppColors.greyCCCCCC : AppColors.black,
          BlendMode.srcIn,
        ),
      ),
      padding: EdgeInsets.zero,
      menuPadding: EdgeInsets.zero,
      itemBuilder: (context) {
        return [
          PopupMenuItem(
            onTap: () {
              Get.find<CollectionController>().collectionNameController.text =
                  collectionName;
              Get.find<CollectionController>().isFieldEmpty = false;
              showDialog(
                context: context,
                builder: (context) {
                  return renameFieldDialog(collectionId: collectionId);
                },
              );
            },
            child: Row(
              children: [
                SvgPicture.asset(
                  AppAssets.icRename,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  rename.tr,
                  style: AppTextStyle.medium16(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ],
            ),
          ),

          // PopupMenuDivider(),
          // PopupMenuItem(
          //   onTap: () {},
          //   child: Row(
          //     children: [
          //       SvgPicture.asset(
          //         AppAssets.icShare,
          //         colorFilter: ColorFilter.mode(
          //           isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
          //           BlendMode.srcIn,
          //         ),
          //       ),
          //       SizedBox(width: 10.w),
          //       Text(
          //         share.tr,
          //         style: AppTextStyle.medium16(
          //           color:
          //               isDarkMode()
          //                   ? AppColors.whiteColor
          //                   : AppColors.black0D0C0C,
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          PopupMenuDivider(),
          PopupMenuItem(
            onTap: () async {
              Get.find<CollectionController>().deleteCollection(
                collectionId: collectionId,
              );
            },
            child: Row(
              children: [
                SvgPicture.asset(
                  AppAssets.icDelete,
                  colorFilter: ColorFilter.mode(
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                    BlendMode.srcIn,
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  delete.tr,
                  style: AppTextStyle.medium16(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ],
            ),
          ),
        ];
      },
    );
  }
}
