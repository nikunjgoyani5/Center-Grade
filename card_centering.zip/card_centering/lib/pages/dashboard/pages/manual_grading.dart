import 'dart:io';

import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class ManualCardGrading extends StatefulWidget {
  final String image;
  final bool isLocalImage;

  const ManualCardGrading({
    super.key,
    required this.image,
    required this.isLocalImage,
  });

  @override
  State<ManualCardGrading> createState() => _ManualCardGradingState();
}

class _ManualCardGradingState extends State<ManualCardGrading> {
  final GlobalKey _imageKey = GlobalKey();
  double? imageWidth;
  double? imageHeight;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _getImageSize();
    });
  }

  void _getImageSize() {
    final RenderBox? renderBox =
        _imageKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox != null) {
      setState(() {
        imageWidth = renderBox.size.width;
        imageHeight = renderBox.size.height;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(manualGrading, style: AppTextStyle.semiBold26()),
      ),
      body: GetBuilder<HomeController>(
        builder:
            (controller) => Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),

                  // Text(
                  //   imageWidth != null && imageHeight != null
                  //       ? 'Image Size: ${imageWidth!.toInt()} x ${imageHeight!.toInt()}'
                  //       : 'Image Size: Measuring...',
                  //   style: TextStyle(fontSize: 16),
                  // ),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        color: Colors.red,
                        height: 450.h,
                        width: 300.w,
                        child: Stack(
                          children: [
                            widget.isLocalImage
                                ? Image.file(
                                  key: _imageKey,
                                  File(widget.image),
                                  height: 450.h,
                                  width: 300.w,
                                  fit: BoxFit.fill,
                                )
                                : Image.network(
                                  key: _imageKey,
                                  fit: BoxFit.fill,
                                  widget.image,
                                  height: 450.h,
                                  width: 300.w,
                                  loadingBuilder: (
                                    context,
                                    child,
                                    loadingProgress,
                                  ) {
                                    if (loadingProgress == null) return child;
                                    return const Center(
                                      child: CircularProgressIndicator(),
                                    );
                                  },
                                ),
                            // Diagonal Grid (outside boundary)
                            CustomPaint(
                              painter: DiagonalGridPainter(
                                outerLeft: controller.outerLeft,
                                outerRight: controller.outerRight,
                                outerTop: controller.outerTop,
                                outerBottom: controller.outerBottom,
                                innerLeft: controller.left,
                                innerRight: controller.right,
                                innerTop: controller.top,
                                innerBottom: controller.bottom,
                              ),
                              size: Size(300.w, 450.h),
                            ),
                            // Center rectangle between inner boundaries
                            Positioned(
                              left: controller.left,
                              right: controller.right,
                              top: controller.top,
                              bottom: controller.bottom,
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: AppColors.primaryColor,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              left: controller.outerLeft,
                              right: controller.outerRight,
                              top: controller.outerTop,
                              bottom: controller.outerBottom,
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: AppColors.primaryColor,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Inner Arrows
                      Positioned(
                        top: controller.top,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustInnerBorder(
                                top.tr,
                                details.delta.dy,
                              ),
                          child: _overlayButton("⬆️"),
                        ),
                      ),
                      Positioned(
                        bottom: controller.bottom,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustInnerBorder(
                                bottom.tr,
                                details.delta.dy,
                              ),
                          child: _overlayButton("⬇️"),
                        ),
                      ),
                      Positioned(
                        left: controller.left,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustInnerBorder(
                                left.tr,
                                details.delta.dx,
                              ),
                          child: _overlayButton("⬅️"),
                        ),
                      ),
                      Positioned(
                        right: controller.right,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustInnerBorder(
                                right.tr,
                                details.delta.dx,
                              ),
                          child: _overlayButton("➡️"),
                        ),
                      ),
                      // Outer Arrows (10px further from inner)
                      Positioned(
                        top: controller.outerTop - controller.gap,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustOuterBorder(
                                top.tr,
                                details.delta.dy,
                              ),
                          child: _overlayButton("⬆️"),
                        ),
                      ),
                      Positioned(
                        bottom: controller.outerBottom - controller.gap,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustOuterBorder(
                                bottom.tr,
                                details.delta.dy,
                              ),
                          child: _overlayButton("⬇️"),
                        ),
                      ),
                      Positioned(
                        left: controller.outerLeft - controller.gap,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustOuterBorder(
                                left.tr,
                                details.delta.dx,
                              ),
                          child: _overlayButton("⬅️"),
                        ),
                      ),
                      Positioned(
                        right: controller.outerRight - controller.gap,
                        child: GestureDetector(
                          onPanUpdate:
                              (details) => controller.adjustOuterBorder(
                                right.tr,
                                details.delta.dx,
                              ),
                          child: _overlayButton("➡️"),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: "${leftRight.tr}:- ",
                          style: AppTextStyle.semiBold18(),
                        ),
                        TextSpan(
                          text: controller.horizontalCentering,
                          style: AppTextStyle.medium16(),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 15.h),
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: "${topBottom.tr}:- ",
                          style: AppTextStyle.semiBold18(),
                        ),
                        TextSpan(
                          text: controller.verticalCentering,
                          style: AppTextStyle.medium16(),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 15.h),
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: "${grading.tr}:- ",
                          style: AppTextStyle.semiBold18(),
                        ),
                        TextSpan(
                          text: controller.grading,
                          style: AppTextStyle.medium16(),
                        ),
                      ],
                    ),
                  ),

                  // Expanded(
                  //   child: SingleChildScrollView(child: _buildRatioDisplay()),
                  // ),
                ],
              ),
            ),
      ),
    );
  }

  Widget _overlayButton(String emoji) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
        shape: BoxShape.circle,
      ),
      // padding: EdgeInsets.all(5.r),
      child: Text(emoji, style: TextStyle(fontSize: 20.h, color: Colors.white)),
    );
  }

  // Widget _buildRatioDisplay() {
  //   return GetBuilder<controller>(
  //     builder:
  //         (controller) => Column(
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Text(
  //           'Centering Score: ${controller.centeringScore.toStringAsFixed(2)}%',
  //           style: TextStyle(
  //             fontSize: 18,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.green,
  //           ),
  //         ),
  //         SizedBox(height: 20),
  //         Text(
  //           "Inner Boundaries",
  //           style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox("Left: ${controller.left.toStringAsFixed(2)}"),
  //             SizedBox(width: 10),
  //             _infoBox("Right: ${controller.right.toStringAsFixed(2)}"),
  //           ],
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox("Top: ${controller.top.toStringAsFixed(2)}"),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "Bottom: ${controller.bottom.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "L/R Ratio: ${controller.lrRatio.isNaN ? "0.0" : controller.lrRatio.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "T/B Ratio: ${controller.tbRatio.isNaN ? "0.0" : controller.tbRatio.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         Divider(height: 20, thickness: 2),
  //
  //         Text(
  //           "Outer Boundaries",
  //           style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "Left: ${controller.outerLeft.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "Right: ${controller.outerRight.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "Top: ${controller.outerTop.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "Bottom: ${controller.outerBottom.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "L/R Ratio: ${controller.outerLrRatio.isNaN ? "0.0" : controller.outerLrRatio.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "T/B Ratio: ${controller.outerTbRatio.isNaN ? "0.0" : controller.outerTbRatio.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         Divider(height: 20, thickness: 2),
  //
  //         Text(
  //           "Gap Between Inner and Outer",
  //           style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "Left Gap: ${controller.gapLeft.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "Right Gap: ${controller.gapRight.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         SizedBox(height: 5),
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             _infoBox(
  //               "Top Gap: ${controller.gapTop.toStringAsFixed(2)}",
  //             ),
  //             SizedBox(width: 10),
  //             _infoBox(
  //               "Bottom Gap: ${controller.gapBottom.toStringAsFixed(2)}",
  //             ),
  //           ],
  //         ),
  //         SizedBox(height: 20),
  //       ],
  //     ),
  //   );
  // }
}

class DiagonalGridPainter extends CustomPainter {
  final double outerLeft;
  final double outerRight;
  final double outerTop;
  final double outerBottom;

  final double innerLeft;
  final double innerRight;
  final double innerTop;
  final double innerBottom;

  DiagonalGridPainter({
    required this.outerLeft,
    required this.outerRight,
    required this.outerTop,
    required this.outerBottom,
    required this.innerLeft,
    required this.innerRight,
    required this.innerTop,
    required this.innerBottom,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..color = AppColors.primaryColor
          ..strokeWidth = 2;

    double step = 15;

    // Outer rect boundaries
    double leftX = outerLeft;
    double topY = outerTop;
    double rightX = size.width - outerRight;
    double bottomY = size.height - outerBottom;

    // Inner rect boundaries
    double innerLeftX = innerLeft;
    double innerTopY = innerTop;
    double innerRightX = size.width - innerRight;
    double innerBottomY = size.height - innerBottom;

    // Create paths
    Path outerPath =
        Path()..addRect(Rect.fromLTRB(leftX, topY, rightX, bottomY));

    Path innerPath =
        Path()..addRect(
          Rect.fromLTRB(innerLeftX, innerTopY, innerRightX, innerBottomY),
        );

    // Create a path that excludes the inner rectangle
    Path gridPath = Path.combine(
      PathOperation.difference,
      outerPath,
      innerPath,
    );

    // Clip to the ring area (between outer and inner)
    canvas.save();
    canvas.clipPath(gridPath);

    // Draw diagonal lines inside the clipped area
    for (double i = -size.height; i < size.width; i += step) {
      canvas.drawLine(
        Offset(i, size.height),
        Offset(i + size.height, 0),
        paint,
      );
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
