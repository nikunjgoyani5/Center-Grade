import 'package:card_centering/apptheme/app_strings.dart';
import 'package:get/get.dart';

class CardGradingCalculator {
  static Map<String, dynamic> calculateGradingScore({
    required double innerLeft,
    required double innerRight,
    required double innerTop,
    required double innerBottom,
    required double outerLeft,
    required double outerRight,
    required double outerTop,
    required double outerBottom,
  }) {
    // Calculate effective borders using inner and outer values
    double leftBorder = (innerLeft - outerLeft).abs();
    double rightBorder = (outerRight - innerRight).abs();
    double topBorder = (innerTop - outerTop).abs();
    double bottomBorder = (outerBottom - innerBottom).abs();

    // Calculate centering ratios
    String horizontalCentering = formatRatio(leftBorder, rightBorder);
    String verticalCentering = formatRatio(topBorder, bottomBorder);

    // Determine grading based on centering
    String grade = _getGrading(horizontalCentering, verticalCentering);

    return {
      "horizontalCentering": horizontalCentering,
      "verticalCentering": verticalCentering,
      "grading": grade,
    };
  }

  static String formatRatio(double border1, double border2) {
    double total = border1 + border2;

    // Handle case where total is zero (both borders are zero)
    if (total == 0) {
      return "50/50"; // Perfectly centered if both borders are zero
    }

    int ratio1 = ((border1 / total) * 100).round();
    int ratio2 = ((border2 / total) * 100).round();
    return "$ratio1/$ratio2";
  }

  static String _getGrading(String horizontal, String vertical) {
    int worstCentering = _getWorstCentering(horizontal, vertical);

    if (worstCentering <= 55) {
      return "GEM MINT 10";
    } else if (worstCentering <= 60) {
      return "MINT 9";
    } else if (worstCentering <= 65) {
      return "NM-MT 8";
    } else if (worstCentering <= 70) {
      return "NM 7";
    } else {
      return "${lowerThan.tr} NM 7";
    }
  }

  static int _getWorstCentering(String horizontal, String vertical) {
    int hWorst = int.parse(horizontal.split('/')[0]); // Get the smaller value
    int vWorst = int.parse(vertical.split('/')[0]); // Get the smaller value
    return hWorst > vWorst ? hWorst : vWorst; // Return the WORST (higher) value
  }
}