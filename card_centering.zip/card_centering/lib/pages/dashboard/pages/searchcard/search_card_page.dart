import 'dart:async';

import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/dashboard_controller.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/common_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../controllers/dashboardcontrollers/search_controller.dart';
import '../../../../widgets/shimmer_widget.dart';
import 'card_info_screen.dart';

class SearchCardPage extends StatefulWidget {
  const SearchCardPage({super.key});

  @override
  State<SearchCardPage> createState() => _SearchCardPageState();
}

class _SearchCardPageState extends State<SearchCardPage> {
  final searchController = Get.put(SearchCardController());
  Timer? _debounce;

  @override
  void initState() {
    searchController.searchController.clear();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor:
            isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
        appBar: commonAppbar(title: search.tr, isShowBackButton: false),
        body: GetBuilder<SearchCardController>(
          builder:
              (searchController) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Column(
                  children: [
                    GetBuilder<SearchCardController>(
                      builder:
                          (controller) => commonTextfield(
                            controller: controller.searchController,
                            hintText: searchCard.tr,
                            onChanged: (value) async {
                              if (_debounce?.isActive ?? false) {
                                _debounce?.cancel();
                              }
                              _debounce = Timer(500.milliseconds, () async {
                                await controller.allDetectedCardsApi();
                              });
                            },
                            prefixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  AppAssets.icSearch,
                                  height: 22,
                                  width: 22,
                                  colorFilter: ColorFilter.mode(
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                                    BlendMode.srcIn,
                                  ),
                                ),
                              ],
                            ),
                            suffixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Obx(
                                  () =>
                                      controller.isShowClosed.value
                                          ? GestureDetector(
                                            onTap: () async {
                                              controller.searchController
                                                  .clear();
                                              controller.detectedCardsList
                                                  .clear();
                                            },
                                            child: SvgPicture.asset(
                                              AppAssets.icClose,
                                              colorFilter: ColorFilter.mode(
                                                isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C,
                                                BlendMode.srcIn,
                                              ),
                                              height: 15,
                                              width: 15,
                                            ),
                                          )
                                          : const SizedBox.shrink(),
                                ),
                              ],
                            ),
                          ),
                    ),
                    SizedBox(height: 20.h),
                    Expanded(
                      child: Obx(
                        () =>
                            searchController.isSearchLoader.value
                                ? showSearchShimmer()
                                :
                                // ignore: prefer_is_empty
                                searchController.detectedCardsList.isEmpty
                                ? Center(
                                  child: Text(
                                    noCard.tr,
                                    style: AppTextStyle.semiBold22(
                                      color:
                                          isDarkMode()
                                              ? AppColors.whiteColor
                                              : AppColors.black0D0C0C,
                                    ),
                                  ),
                                )
                                : ListView.separated(
                                  itemCount:
                                      searchController.detectedCardsList.length,
                                  itemBuilder: (context, index) {
                                    final productData =
                                        searchController
                                            .detectedCardsList[index];
                                    return Container(
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                        ),
                                      ),

                                      child: ListTile(
                                        onTap: () {
                                          Get.find<DashboardController>()
                                              .searchCount
                                              .value++;
                                          Get.find<DashboardController>()
                                              .setSearchCount();
                                          Get.to(
                                            () => CardInfoScreen(
                                              cardId: productData.id ?? '',
                                            ),
                                            transition:
                                                Transition.rightToLeftWithFade,
                                          );
                                        },
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 15.w,
                                        ),
                                        leading: Container(
                                          height: 50.h,
                                          width: 40.w,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                              12.r,
                                            ),
                                            color: AppColors.transparent,
                                          ),
                                          child: Image.network(
                                            productData.frontImageUrl ?? '',
                                            height: 50.h,
                                            width: 40.w,
                                            errorBuilder: (
                                              context,
                                              error,
                                              stackTrace,
                                            ) {
                                              return Image.asset(
                                                AppAssets.imgPlaceHolder,
                                                height: 50.h,
                                                width: 40.w,
                                              );
                                            },
                                          ),
                                        ),
                                        dense: true,
                                        title: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              productData
                                                      .priceCheckerDetails
                                                      ?.name ??
                                                  "",
                                              style: AppTextStyle.medium20(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.black0D0C0C,
                                              ),
                                            ),
                                            Text(
                                              productData
                                                      .priceCheckerDetails
                                                      ?.ungradedPrice ??
                                                  '',
                                              style: AppTextStyle.medium17(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.grey9B9B9B
                                                        : AppColors
                                                            .primaryPurple,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10.h);
                                  },
                                ),
                      ),
                    ),
                  ],
                ),
              ),
        ),
      ),
    );
  }
}
