import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/widgets/common_appbar.dart';
import 'package:card_centering/widgets/shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../apptheme/app_colors.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_strings.dart';
import '../../../../controllers/dashboardcontrollers/search_controller.dart';

class CardInfoScreen extends StatefulWidget {
  final String cardId;
  final bool? isFromCollection;
  final bool? isPriceCheck;

  const CardInfoScreen({
    super.key,
    required this.cardId,
    this.isFromCollection,
    this.isPriceCheck,
  });

  @override
  State<CardInfoScreen> createState() => _CardInfoScreenState();
}

class _CardInfoScreenState extends State<CardInfoScreen> {
  @override
  void initState() {
    // if (widget.isFromCollection == true) {
    //   Get.find<CollectionController>().singleCardDetailsApi(
    //     cardId: widget.cardId,
    //   );
    // }

    if (SearchCardController().initialized) {
      if (widget.isPriceCheck == true) {
        Get.find<SearchCardController>().cardInfo(cardId: widget.cardId);
      } else {
        Get.find<SearchCardController>().detectedCardDetailsApi(
          cardId: widget.cardId,
        );
      }
    } else {
      if (widget.isPriceCheck == true) {
        Get.put(SearchCardController()).cardInfo(cardId: widget.cardId);
      } else {
        Get.put(
          SearchCardController(),
        ).detectedCardDetailsApi(cardId: widget.cardId);
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SearchCardController>(
      builder:
          (searchCardController) => Scaffold(
            backgroundColor:
                isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
            appBar: commonAppbar(title: cardDetails.tr),
            // bottomNavigationBar:
            //     widget.isFromCollection == true
            //         ? null
            //         : Padding(
            //           padding: EdgeInsets.only(
            //             bottom: 20.h,
            //             right: 20.w,
            //             left: 20.w,
            //           ),
            //           child: CommonButton(
            //             buttonWidth: double.infinity,
            //             onPressed: () {
            //               showDialog(
            //                 context: context,
            //                 builder: (context) {
            //                   return addCollectionDialog(
            //                     onTap: () {
            //                       Get.back();
            //                       showDialog(
            //                         context: context,
            //                         builder: (context) {
            //                           return addCollectionFieldDialog();
            //                         },
            //                       );
            //                     },
            //                   );
            //                 },
            //               );
            //             },
            //             child: Text(
            //               "Add to Collection",
            //               style: AppTextStyle.medium20(
            //                 color: AppColors.whiteColor,
            //               ),
            //             ),
            //           ),
            //         ),
            body: Obx(
              () =>
                  searchCardController.isShowLoader.value
                      ? widget.isPriceCheck == true
                          ? showPriceCheckerShimmer()
                          : showScanCardShimmer()
                      : Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15.w),
                        child: Column(
                          children: [
                            SizedBox(height: 20.h),
                            widget.isPriceCheck == true
                                ? const SizedBox.shrink()
                                : Container(
                                  height: 400.h,
                                  width: 350.h,
                                  color: Colors.transparent,
                                  child: Image.network(
                                    searchCardController
                                            .detectedCardDetails
                                            ?.frontImageUrl ??
                                        '',
                                    errorBuilder: (context, error, stackTrace) {
                                      return Image.asset(
                                        AppAssets.imgPlaceHolder,
                                      );
                                    },
                                  ),
                                ),
                            SizedBox(height: 20.h),
                            Expanded(
                              child: ListView(
                                children: [
                                  Center(
                                    child: Text(
                                      widget.isPriceCheck == true
                                          ? (searchCardController
                                                  .cardInfoData
                                                  ?.productName ??
                                              '')
                                          : searchCardController
                                              .detectedCardDetails!
                                              .priceCheckerDetails!
                                              .name!
                                              .isEmpty
                                          ? "Card 1"
                                          : searchCardController
                                                  .detectedCardDetails
                                                  ?.priceCheckerDetails
                                                  ?.name ??
                                              'Card 1',
                                      style: AppTextStyle.medium24(
                                        color:
                                            isDarkMode()
                                                ? AppColors.whiteColor
                                                : AppColors.black0D0C0C,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20.h),
                                  widget.isPriceCheck == true
                                      ? const SizedBox.shrink()
                                      : Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color:
                                                        isDarkMode()
                                                            ? AppColors
                                                                .grey2A2A2A
                                                            : AppColors
                                                                .whiteColor,
                                                    border: Border.all(
                                                      color:
                                                          isDarkMode()
                                                              ? AppColors
                                                                  .grey2A2A2A
                                                              : AppColors
                                                                  .greyEBEBEB,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          10.r,
                                                        ),
                                                  ),
                                                  padding: EdgeInsets.symmetric(
                                                    horizontal: 12.w,
                                                    vertical: 10.h,
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                        lrText.tr,
                                                        style:
                                                            AppTextStyle.medium17(
                                                              color:
                                                                  AppColors
                                                                      .grey9B9B9B,
                                                            ),
                                                      ),
                                                      Text(
                                                        searchCardController
                                                                .detectedCardDetails
                                                                ?.frontDetails
                                                                ?.leftRight ??
                                                            '-',
                                                        style: AppTextStyle.medium20(
                                                          color:
                                                              isDarkMode()
                                                                  ? AppColors
                                                                      .whiteColor
                                                                  : AppColors
                                                                      .black0D0C0C,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(width: 10.w),
                                              Expanded(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color:
                                                        isDarkMode()
                                                            ? AppColors
                                                                .grey2A2A2A
                                                            : AppColors
                                                                .whiteColor,
                                                    border: Border.all(
                                                      color:
                                                          isDarkMode()
                                                              ? AppColors
                                                                  .grey2A2A2A
                                                              : AppColors
                                                                  .greyEBEBEB,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          10.r,
                                                        ),
                                                  ),
                                                  padding: EdgeInsets.symmetric(
                                                    horizontal: 12.w,
                                                    vertical: 10.h,
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                        tbText.tr,
                                                        style:
                                                            AppTextStyle.medium17(
                                                              color:
                                                                  AppColors
                                                                      .grey9B9B9B,
                                                            ),
                                                      ),
                                                      // SizedBox(width: 20.w),
                                                      Text(
                                                        searchCardController
                                                                .detectedCardDetails
                                                                ?.frontDetails
                                                                ?.bottomTop ??
                                                            '-',
                                                        style: AppTextStyle.medium20(
                                                          color:
                                                              isDarkMode()
                                                                  ? AppColors
                                                                      .whiteColor
                                                                  : AppColors
                                                                      .black0D0C0C,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 15.h),
                                          infoWidget(
                                            title: centering.tr,
                                            value:
                                                searchCardController
                                                    .detectedCardDetails
                                                    ?.frontDetails
                                                    ?.centering?.toString() ??
                                                '-',
                                          ),
                                          // Divider(
                                          //   color:
                                          //   isDarkMode()
                                          //       ? AppColors.grey2A2A2A
                                          //       : AppColors.greyEBEBEB,
                                          // ),
                                          // infoWidget(title: "Edges", value: "9.5"),
                                          // Divider(
                                          //   color:
                                          //   isDarkMode()
                                          //       ? AppColors.grey2A2A2A
                                          //       : AppColors.greyEBEBEB,
                                          // ),
                                          // infoWidget(title: "Corners", value: "9.5"),
                                          Divider(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                          infoWidget(
                                            title: aiGrade.tr,
                                            value:
                                                searchCardController
                                                    .detectedCardDetails
                                                    ?.frontDetails
                                                    ?.aiGrade ??
                                                '-',
                                          ),
                                          Divider(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                          infoWidget(
                                            title: cardSide.tr,
                                            value:
                                                searchCardController
                                                    .detectedCardDetails
                                                    ?.frontDetails
                                                    ?.cardSide ??
                                                '-',
                                          ),
                                          Divider(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                          infoWidget(
                                            title: category.tr,
                                            value:
                                                searchCardController
                                                    .detectedCardDetails
                                                    ?.frontDetails
                                                    ?.category ??
                                                '-',
                                          ),
                                          SizedBox(height: 20.h),
                                        ],
                                      ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      priceWidget(
                                        title: ungraded.tr,
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.loosePrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.ungradedPrice ??
                                                    '-',
                                      ),
                                      SizedBox(width: 12.w),
                                      priceWidget(
                                        title: "${grade.tr} 7",
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.cibPrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.grade7Price ??
                                                    '-',
                                      ),
                                      SizedBox(width: 12.w),

                                      priceWidget(
                                        title: "${grade.tr} 8",
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.newPrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.grade8Price ??
                                                    '-',
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 15.h),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,

                                    children: [
                                      priceWidget(
                                        title: "${grade.tr} 9",
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.gradedPrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.grade9Price ??
                                                    '-',
                                      ),
                                      SizedBox(width: 12.w),

                                      priceWidget(
                                        title: "${grade.tr} 9.5",
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.boxOnlyPrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.grade95Price ??
                                                    "-",
                                      ),
                                      SizedBox(width: 12.w),

                                      priceWidget(
                                        title: "PSA 10",
                                        value:
                                            widget.isPriceCheck == true
                                                ? searchCardController
                                                        .cardInfoData
                                                        ?.manualOnlyPrice
                                                        ?.formatPrice() ??
                                                    '-'
                                                : searchCardController
                                                        .detectedCardDetails
                                                        ?.priceCheckerDetails
                                                        ?.psa10Price ??
                                                    '-',
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            SizedBox(height: 20.h),
                          ],
                        ),
                      ),
            ),
          ),
    );
  }

  priceWidget({required String title, required String value}) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
          border: Border.all(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        ),
        padding: EdgeInsets.symmetric(horizontal: 22.w, vertical: 12.h),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: AppTextStyle.semiBold16(color: AppColors.grey9B9B9B),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
              ),
              // SizedBox(height: 5.h), // Optional spacing
              Text(
                value,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  infoWidget({required String title, required String value}) {
    return Container(
      color: Colors.transparent,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$title:",
            style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
          ),
          Text(
            value,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
        ],
      ),
    );
  }
}
