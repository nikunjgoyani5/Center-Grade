import 'dart:async';
import 'dart:io';

import 'package:card_centering/adhelper/adwidget/banner_ad_widget.dart';
import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_extension.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:percent_indicator/percent_indicator.dart';

import '../../../adhelper/ad_service.dart';
import '../../../apptheme/app_colors.dart';
import '../../../apptheme/app_constants.dart';
import '../../../controllers/dashboardcontrollers/dashboard_controller.dart';
import '../../../model/collectionmodel/collection_list_model.dart';
import '../../../widgets/common_button.dart';
import '../../../widgets/common_textfield.dart';
import '../../../widgets/common_widgets.dart';
import '../../../widgets/shimmer_widget.dart';
import 'drawerscreen/manual_grading_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Timer? _debounce;
  bool isBackDetailsClicked = false;

  final scrollController = ScrollController();

  // final LayerLink _layerLink = LayerLink();
  // OverlayEntry? _overlayEntry;

  // void _showOverlay(LayerLink link) {
  //   _overlayEntry = _createOverlayEntry(link);
  //   Overlay.of(context).insert(_overlayEntry!);
  // }

  // void _hideOverlay() {
  //   _overlayEntry?.remove();
  //   _overlayEntry = null;
  // }

  // OverlayEntry _createOverlayEntry(LayerLink link) {
  //   RenderBox renderBox = context.findRenderObject() as RenderBox;
  //   Size size = renderBox.size;
  //   Offset offset = renderBox.localToGlobal(Offset.zero);

  //   return OverlayEntry(
  //     builder:
  //         (context) => GestureDetector(
  //           behavior: HitTestBehavior.translucent,
  //           onTap: _hideOverlay,
  //           child: Stack(
  //             children: [
  //               Positioned(
  //                 left: offset.dx + 30,
  //                 top: offset.dy - 20,
  //                 child: CompositedTransformFollower(
  //                   link: link,
  //                   showWhenUnlinked: true,
  //                   offset: Offset(20, -20),
  //                   child: Material(
  //                     color: Colors.transparent,
  //                     child: ClipPath(
  //                       // clipper: ArrowClipper(),
  //                       child: Container(
  //                         padding: const EdgeInsets.all(12),
  //                         margin: const EdgeInsets.only(left: 8),
  //                         decoration: BoxDecoration(
  //                           color:
  //                               isDarkMode()
  //                                   ? AppColors.black1E1E1E
  //                                   : AppColors.whiteColor,
  //                           border: Border.all(
  //                             color:
  //                                 isDarkMode()
  //                                     ? AppColors.grey2A2A2A
  //                                     : AppColors.greyEBEBEB,
  //                           ),
  //                           borderRadius: BorderRadius.circular(8),
  //                         ),
  //                         width: Get.width * 0.6,
  //                         child: RichText(
  //                           text: TextSpan(
  //                             text: "${determineStandards.tr} ",
  //                             style: AppTextStyle.regular16(
  //                               color:
  //                                   isDarkMode()
  //                                       ? AppColors.whiteColor
  //                                       : AppColors.black0D0C0C,
  //                             ),
  //                             children: [
  //                               TextSpan(
  //                                 text: tapHere.tr,
  //                                 style: AppTextStyle.semiBold16(
  //                                   color: AppColors.primaryPurple,
  //                                 ).copyWith(
  //                                   decoration: TextDecoration.underline,
  //                                 ),
  //                                 recognizer:
  //                                     TapGestureRecognizer()
  //                                       ..onTap = () {
  //                                         _hideOverlay();
  //                                         Future.delayed(100.milliseconds, () {
  //                                           Get.to(
  //                                             () => StandardScreen(),
  //                                             transition:
  //                                                 Transition
  //                                                     .rightToLeftWithFade,
  //                                           );
  //                                         });
  //                                       },
  //                               ),
  //                             ],
  //                           ),
  //                         ),
  //                       ),
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    Get.put(HomeController(), permanent: true);
    return GetBuilder<HomeController>(
      builder: (controller) {
        return Get.find<DashboardController>().isScanned == true
            ? DefaultTabController(
              length: 2,
              child: Scaffold(
                appBar: AppBar(
                  elevation: 0,
                  toolbarHeight: 80.h,
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return showSavePopup();
                            },
                          );
                        },
                        child: Container(
                          height: 45.h,
                          width: 45.w,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                isDarkMode()
                                    ? AppColors.black1E1E1E
                                    : AppColors.whiteFAFAFA,
                            border: Border.all(
                              color:
                                  isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyEBEBEB,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                isDarkMode()
                                    ? AppAssets.icArrowBackDark
                                    : AppAssets.icArrowBack,
                                width: 18,
                                height: 18,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  actions: [
                    // Container(
                    //   decoration: BoxDecoration(
                    //     border: Border.all(
                    //       color:
                    //           isDarkMode()
                    //               ? AppColors.grey2A2A2A
                    //               : AppColors.greyEBEBEB,
                    //     ),
                    //     borderRadius: BorderRadius.circular(50.r),
                    //     color:
                    //         isDarkMode()
                    //             ? AppColors.black1E1E1E
                    //             : AppColors.whiteColor,
                    //   ),
                    //   padding: EdgeInsets.symmetric(
                    //     horizontal: 12.w,
                    //     vertical: 10.h,
                    //   ),
                    //   child: Text(
                    //     download.tr,
                    //     style: AppTextStyle.medium20(
                    //       color:
                    //           isDarkMode()
                    //               ? AppColors.whiteColor
                    //               : AppColors.black0D0C0C,
                    //     ),
                    //   ),
                    // ),
                    SizedBox(width: 15.w),
                    GetBuilder<HomeController>(
                      builder:
                          (controller) => GestureDetector(
                            onTap: () async {
                              if (controller.isFavLoader.value == false) {
                                await controller.favoriteCardApi();
                              }
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color:
                                    isDarkMode()
                                        ? AppColors.black1E1E1E
                                        : AppColors.whiteFAFAFA,
                                border: Border.all(
                                  color:
                                      isDarkMode()
                                          ? AppColors.grey2A2A2A
                                          : AppColors.greyEBEBEB,
                                ),
                              ),
                              padding: EdgeInsets.all(10.r),
                              child: SvgPicture.asset(
                                controller.favCardData?.isFavorite == true
                                    ? AppAssets.icFavFilled
                                    : AppAssets.icFavorite,
                                height: 20,
                                width: 20,
                                colorFilter: ColorFilter.mode(
                                  controller.favCardData?.isFavorite == true
                                      ? AppColors.primaryPurple
                                      : isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                                  BlendMode.srcIn,
                                ),
                              ),
                            ),
                          ),
                    ),
                    SizedBox(width: 15.w),
                  ],
                ),
                // floatingActionButton:
                //     MediaQuery.of(context).viewInsets.bottom != 0
                //         ? null
                //         : FloatingActionButton(
                //           heroTag: null,
                //           shape: RoundedRectangleBorder(
                //             borderRadius: BorderRadius.circular(50.r),
                //           ),
                //           onPressed: () async {
                //             if (Get.find<HomeController>().userAttempts.value >= 3) {
                //               showModalBottomSheet(
                //                 constraints: BoxConstraints(
                //                   maxHeight: MediaQuery.of(context).size.height * 0.8,
                //                   minHeight: MediaQuery.of(context).size.height * 0.8,
                //                 ),
                //                 isScrollControlled: true,
                //                 context: context,
                //                 builder: (context) {
                //                   return PaywallScreen();
                //                 },
                //               );
                //             } else {
                //               Get.to(() => DemoScanPage());
                //             }
                //
                //             // Get.find<HomeController>().getImageFromCamera(true);
                //           },
                //           backgroundColor: AppColors.primaryPurple,
                //           elevation: 3,
                //           child: SvgPicture.asset(
                //             AppAssets.icScanWhite,
                //             width: 28,
                //             height: 28,
                //           ),
                //         ),
                // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
                // bottomNavigationBar: GetBuilder<DashboardController>(
                //   builder:
                //       (dashboardController) => Container(
                //         decoration: BoxDecoration(
                //           border: Border(
                //             top: BorderSide(
                //               color:
                //                   isDarkMode()
                //                       ? AppColors.grey2A2A2A
                //                       : AppColors.greyEBEBEB,
                //             ),
                //           ),
                //         ),
                //         child: BottomAppBar(
                //           padding: EdgeInsets.only(top: 15.h),
                //           color:
                //               context.isDarkMode
                //                   ? AppColors.black1E1E1E
                //                   : AppColors.whiteColor,
                //           child: Row(
                //             children: [
                //               // Left side icons
                //               Expanded(
                //                 child: GestureDetector(
                //                   onTap: () {
                //                     dashboardController.onBottomNavBarTapped(0);
                //                   },
                //                   child: Column(
                //                     children: [
                //                       dashboardController.currentIndex == 0
                //                           ? SvgPicture.asset(
                //                             AppAssets.icHomeSelected,
                //                             width: 24,
                //                             height: 24,
                //                           )
                //                           : SvgPicture.asset(
                //                             AppAssets.icHome,
                //                             width: 24,
                //                             height: 24,
                //                           ),
                //                       SizedBox(height: 5.h),
                //                       Text(
                //                         home.tr,
                //                         style: AppTextStyle.medium16(
                //                           color:
                //                               dashboardController.currentIndex == 0
                //                                   ? isDarkMode()
                //                                       ? AppColors.whiteColor
                //                                       : AppColors.black0D0C0C
                //                                   : isDarkMode()
                //                                   ? AppColors.grey888888
                //                                   : AppColors.grey9B9B9B,
                //                         ),
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //               ),
                //
                //               Expanded(
                //                 child: GestureDetector(
                //                   onTap: () {
                //                     Get.off(() => const DashboardScreen());
                //                     dashboardController.onBottomNavBarTapped(1);
                //                   },
                //                   child: Column(
                //                     children: [
                //                       dashboardController.currentIndex == 1
                //                           ? SvgPicture.asset(
                //                             AppAssets.icCollectionSelected,
                //                             width: 24,
                //                             height: 24,
                //                           )
                //                           : SvgPicture.asset(
                //                             AppAssets.icCollection,
                //                             width: 24,
                //                             height: 24,
                //                           ),
                //                       SizedBox(height: 5.h),
                //
                //                       Text(
                //                         collection.tr,
                //                         maxLines: 1,
                //                         overflow: TextOverflow.ellipsis,
                //                         style: AppTextStyle.medium16(
                //                           color:
                //                               dashboardController.currentIndex == 1
                //                                   ? isDarkMode()
                //                                       ? AppColors.whiteColor
                //                                       : AppColors.black0D0C0C
                //                                   : isDarkMode()
                //                                   ? AppColors.grey888888
                //                                   : AppColors.grey9B9B9B,
                //                         ),
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //               ),
                //
                //               Expanded(
                //                 child: Visibility(
                //                   visible: false,
                //                   child: GestureDetector(
                //                     onTap: () {
                //                       Get.off(() => const DashboardScreen());
                //                       dashboardController.onBottomNavBarTapped(1);
                //                     },
                //                     child: Column(
                //                       children: [
                //                         dashboardController.currentIndex == 1
                //                             ? SvgPicture.asset(
                //                               AppAssets.icCollectionSelected,
                //                               width: 24,
                //                               height: 24,
                //                             )
                //                             : SvgPicture.asset(
                //                               AppAssets.icCollection,
                //                               width: 24,
                //                               height: 24,
                //                             ),
                //                         SizedBox(height: 5.h),
                //
                //                         Text(
                //                           collection.tr,
                //                           style: AppTextStyle.medium16(
                //                             color:
                //                                 dashboardController.currentIndex == 1
                //                                     ? isDarkMode()
                //                                         ? AppColors.whiteColor
                //                                         : AppColors.black0D0C0C
                //                                     : isDarkMode()
                //                                     ? AppColors.grey888888
                //                                     : AppColors.grey9B9B9B,
                //                           ),
                //                         ),
                //                       ],
                //                     ),
                //                   ),
                //                 ),
                //               ),
                //               // Right side icons
                //               Expanded(
                //                 child: GestureDetector(
                //                   onTap: () {
                //                     Get.off(() => const DashboardScreen());
                //                     dashboardController.onBottomNavBarTapped(2);
                //                   },
                //                   child: Column(
                //                     children: [
                //                       dashboardController.currentIndex == 2
                //                           ? SvgPicture.asset(
                //                             AppAssets.icSearchSelected,
                //                             width: 24,
                //                             height: 24,
                //                           )
                //                           : SvgPicture.asset(
                //                             AppAssets.icSearch,
                //                             width: 24,
                //                             height: 24,
                //                           ),
                //                       SizedBox(height: 5.h),
                //
                //                       Text(
                //                         search.tr,
                //                         style: AppTextStyle.medium16(
                //                           color:
                //                               dashboardController.currentIndex == 2
                //                                   ? isDarkMode()
                //                                       ? AppColors.whiteColor
                //                                       : AppColors.black0D0C0C
                //                                   : isDarkMode()
                //                                   ? AppColors.grey888888
                //                                   : AppColors.grey9B9B9B,
                //                         ),
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //               ),
                //
                //               Expanded(
                //                 child: GestureDetector(
                //                   onTap: () {
                //                     Get.off(() => const DashboardScreen());
                //                     dashboardController.onBottomNavBarTapped(3);
                //                   },
                //                   child: Column(
                //                     children: [
                //                       dashboardController.currentIndex == 3
                //                           ? SvgPicture.asset(
                //                             AppAssets.icSettingSelected,
                //                             width: 24,
                //                             height: 24,
                //                           )
                //                           : SvgPicture.asset(
                //                             AppAssets.icSetting,
                //                             width: 24,
                //                             height: 24,
                //                           ),
                //                       SizedBox(height: 5.h),
                //
                //                       Text(
                //                         setting.tr,
                //                         overflow: TextOverflow.ellipsis,
                //                         maxLines: 1,
                //                         style: AppTextStyle.medium16(
                //                           color:
                //                               dashboardController.currentIndex == 3
                //                                   ? isDarkMode()
                //                                       ? AppColors.whiteColor
                //                                       : AppColors.black0D0C0C
                //                                   : isDarkMode()
                //                                   ? AppColors.grey888888
                //                                   : AppColors.grey9B9B9B,
                //                         ),
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //               ),
                //             ],
                //           ),
                //         ),
                //       ),
                // ),
                body: GetBuilder<HomeController>(
                  builder:
                      (homeController) => Obx(
                        () =>
                            homeController.isApiCompleted.value == false
                                ? /*showScanCardShimmer()*/ Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        height: 100,
                                        width: 100,
                                        child: Obx(
                                          () => CircularPercentIndicator(
                                            radius: 50.r,
                                            center: Text(
                                              "${homeController.percentage.value}%",
                                              style: AppTextStyle.medium20(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.black0D0C0C,
                                              ),
                                            ),
                                            progressColor:
                                                AppColors.primaryPurple,
                                            backgroundColor:
                                                AppColors.grey9B9B9B,
                                            lineWidth: 10,
                                            percent:
                                                (homeController
                                                        .percentage
                                                        .value /
                                                    100),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 15.h),
                                      Text(
                                        "Processing...",
                                        style: AppTextStyle.medium20(
                                          color:
                                              isDarkMode()
                                                  ? AppColors.whiteColor
                                                  : AppColors.black0D0C0C,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                                : Stack(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 20.w,
                                      ),
                                      child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          Column(
                                            children: [
                                              SizedBox(height: 20.h),
                                              Obx(
                                                () => Container(
                                                  height: 400.h,
                                                  width: 250.w,
                                                  decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          8.r,
                                                        ),
                                                  ),
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          8.r,
                                                        ),
                                                    child: Image.file(
                                                      homeController
                                                              .isBack
                                                              .value
                                                          ? homeController
                                                          .backImage != null ? homeController
                                                              .backImage! : homeController.frontImage!
                                                          : homeController
                                                              .frontImage!,
                                                      fit: BoxFit.fill,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(height: 20.h),
                                              Expanded(
                                                child: RawScrollbar(
                                                  thumbVisibility: true,
                                                  controller: scrollController,
                                                  child: SingleChildScrollView(
                                                    controller:
                                                        scrollController,
                                                    child: Column(
                                                      children: [
                                                        Text(
                                                          homeController
                                                              .selectedCard,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppTextStyle.medium20(
                                                            color:
                                                                isDarkMode()
                                                                    ? AppColors
                                                                        .whiteColor
                                                                    : AppColors
                                                                        .black0D0C0C,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height:
                                                              homeController
                                                                      .selectedCard
                                                                      .isEmpty
                                                                  ? 0
                                                                  : 15.h,
                                                        ),
                                                        Container(
                                                          padding:
                                                              EdgeInsets.all(
                                                                5.r,
                                                              ),
                                                          decoration: BoxDecoration(
                                                            color:
                                                                isDarkMode()
                                                                    ? AppColors
                                                                        .black1E1E1E
                                                                    : AppColors
                                                                        .greyF5F5F5,
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                  30,
                                                                ),
                                                          ),
                                                          child: TabBar(
                                                            labelColor:
                                                                isDarkMode()
                                                                    ? AppColors
                                                                        .black0D0C0C
                                                                    : AppColors
                                                                        .whiteColor,
                                                            labelStyle: AppTextStyle.medium20(
                                                              color:
                                                                  isDarkMode()
                                                                      ? AppColors
                                                                          .black0D0C0C
                                                                      : AppColors
                                                                          .whiteColor,
                                                            ),
                                                            splashBorderRadius:
                                                                BorderRadius.circular(
                                                                  30,
                                                                ),
                                                            indicatorWeight:
                                                                0.0,
                                                            dividerHeight: 0.0,
                                                            labelPadding:
                                                                EdgeInsets.zero,
                                                            unselectedLabelColor:
                                                                isDarkMode()
                                                                    ? AppColors
                                                                        .grey9B9B9B
                                                                    : AppColors
                                                                        .black0D0C0C,
                                                            onTap: (
                                                              value,
                                                            ) async {
                                                              if (value == 1) {
                                                                if (!isBackDetailsClicked) {
                                                                  await homeController
                                                                      .getImageFromCamera(
                                                                        false,
                                                                      );

                                                                  isBackDetailsClicked =
                                                                      true;
                                                                }
                                                                homeController
                                                                    .onBackChange(
                                                                      true,
                                                                    );
                                                              } else {
                                                                homeController
                                                                    .onFrontChange(
                                                                      true,
                                                                    );
                                                              }
                                                            },
                                                            indicator: BoxDecoration(
                                                              color:
                                                                  isDarkMode()
                                                                      ? AppColors
                                                                          .whiteColor
                                                                      : AppColors
                                                                          .primaryPurple,
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                    30,
                                                                  ),
                                                            ),
                                                            indicatorSize:
                                                                TabBarIndicatorSize
                                                                    .tab,

                                                            tabs: [
                                                              Tab(
                                                                text:
                                                                    frontDetail
                                                                        .tr,
                                                              ),
                                                              Tab(
                                                                text:
                                                                    backDetail
                                                                        .tr,
                                                              ),
                                                            ],
                                                          ),
                                                        ),

                                                        SizedBox(height: 12.h),
                                                        CommonButton(
                                                          buttonWidth:
                                                              double.infinity,
                                                          buttonHeight: 55.h,
                                                          onPressed: () {
                                                            showModalBottomSheet(
                                                              constraints: BoxConstraints(
                                                                maxHeight:
                                                                    MediaQuery.of(
                                                                      context,
                                                                    ).size.height *
                                                                    0.75,
                                                                minHeight:
                                                                    MediaQuery.of(
                                                                      context,
                                                                    ).size.height *
                                                                    0.75,
                                                              ),
                                                              isScrollControlled:
                                                                  true,
                                                              context: context,
                                                              builder: (
                                                                context,
                                                              ) {
                                                                return priceCheckerSheet();
                                                              },
                                                            );
                                                          },
                                                          child: Text(
                                                            priceChecker.tr,
                                                            style: AppTextStyle.medium20(
                                                              color:
                                                                  AppColors
                                                                      .whiteColor,
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(height: 12.h),
                                                        SizedBox(
                                                          height:
                                                              MediaQuery.of(
                                                                context,
                                                              ).size.height *
                                                              0.6,
                                                          child: TabBarView(
                                                            physics:
                                                                const NeverScrollableScrollPhysics(),
                                                            children: [
                                                              gradingWidget(),
                                                              gradingWidget(),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),

                                          Padding(
                                            padding: EdgeInsets.only(
                                              left: 20.w,
                                              right: 20.w,
                                              bottom:
                                                  Platform.isIOS ? 30.h : 15.h,
                                            ),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: CommonButton(
                                                    buttonColor:
                                                        isDarkMode()
                                                            ? AppColors
                                                                .grey2A2A2A
                                                            : AppColors
                                                                .greyEFEFEF,
                                                    buttonHeight: 60.h,
                                                    onPressed: () {
                                                      AdService.showInterstitialAd(
                                                        afterAd: () {
                                                          homeController
                                                              .onTapAddToCollection(
                                                                context,
                                                              );
                                                        },
                                                        adLabel:
                                                            addToCollectionIntertitalAd,
                                                      );
                                                    },
                                                    child: Text(
                                                      addToCollection.tr,
                                                      style: AppTextStyle.medium20(
                                                        color:
                                                            isDarkMode()
                                                                ? AppColors
                                                                    .whiteColor
                                                                : AppColors
                                                                    .black0D0C0C,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(width: 15.w),
                                                Expanded(
                                                  child: CommonButton(
                                                    buttonColor:
                                                        isDarkMode()
                                                            ? AppColors
                                                                .whiteColor
                                                            : AppColors
                                                                .black0D0C0C,
                                                    buttonHeight: 60.h,

                                                    onPressed: () {
                                                      Get.to(
                                                        () => ManualGradingPage(
                                                          frontImage:
                                                              homeController
                                                                  .frontImage,
                                                          backImage:
                                                              homeController
                                                                  .backImage,
                                                        ),
                                                        transition:
                                                            Transition
                                                                .rightToLeftWithFade,
                                                      );
                                                    },
                                                    child: Text(
                                                      manualGrading.tr,
                                                      style: AppTextStyle.medium20(
                                                        color:
                                                            isDarkMode()
                                                                ? AppColors
                                                                    .black0D0C0C
                                                                : AppColors
                                                                    .whiteColor,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Obx(
                                      () =>
                                          homeController.isPriceLoader.value ||
                                                  homeController
                                                      .isDeleteLoader
                                                      .value ||
                                                  homeController
                                                      .isAddCollectionLoader
                                                      .value
                                              ? showLoader()
                                              : const SizedBox.shrink(),
                                    ),
                                  ],
                                ),
                      ),
                ),
              ),
            )
            : Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const BannerAdsWidget(adLbl: homeBannerAd),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) {
                            return LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                AppColors.primaryPurple,
                                AppColors.purpleE8B4F3,
                                AppColors.primaryPurple,
                              ],
                            ).createShader(bounds);
                          },
                          child: Text(
                            welcomeBack.tr,
                            style: AppTextStyle.bold36(
                              color: AppColors.whiteColor,
                            ).copyWith(height: 1.2),
                          ),
                        ),
                        Text(
                          lets.tr,
                          style: AppTextStyle.bold36(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ).copyWith(height: 1.2),
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          uploadAPhoto.tr,
                          style: AppTextStyle.regular18(
                            color:
                                isDarkMode()
                                    ? AppColors.grey9B9B9B
                                    : AppColors.grey878787,
                          ).copyWith(height: 1.2),
                        ),
                        SizedBox(height: 20.h),
                        GestureDetector(
                          onTap: () async {
                            await controller.getImageFromCamera(true);
                            // Get.to(
                            //   () => DemoScanPage(),
                            //   transition: Transition.rightToLeftWithFade,
                            // );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color:
                                  isDarkMode()
                                      ? AppColors.black1E1E1E
                                      : AppColors.purpleFAF5FF,
                              borderRadius: BorderRadius.circular(15.r),
                              border: Border.all(
                                color:
                                    isDarkMode()
                                        ? AppColors.grey2A2A2A
                                        : AppColors.borderF4E7FF,
                              ),
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 20.w,
                              vertical: 20.h,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color:
                                            isDarkMode()
                                                ? AppColors.black121212
                                                : AppColors.whiteColor,
                                      ),
                                      padding: EdgeInsets.all(10.r),
                                      child: SvgPicture.asset(
                                        AppAssets.icScanPurple,
                                      ),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: AppColors.primaryPurple,
                                        borderRadius: BorderRadius.circular(
                                          60.r,
                                        ),
                                      ),
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 15.w,
                                        vertical: 10.h,
                                      ),
                                      child: Obx(
                                        () => Text(
                                          controller.userAttempts.value == 3
                                              ? "Free Scans Completed"
                                              : "${controller.userAttempts.value}/${threeFreeScan.tr}",
                                          style: AppTextStyle.medium17(
                                            color: AppColors.whiteColor,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 25.h),
                                Text(
                                  scanMyCard.tr,
                                  style: AppTextStyle.medium22(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ),
                                ),
                                Text(
                                  scanYourCardIn.tr,
                                  style: AppTextStyle.medium18(
                                    color: AppColors.grey9B9B9B,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(),
                ],
              ),
            );
      },
    );
  }

  priceWidget({required String title, required String value}) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
          border: Border.all(
            color: isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
          ),
          color: isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        ),
        padding: EdgeInsets.symmetric(horizontal: 22.w, vertical: 12.h),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: AppTextStyle.semiBold16(color: AppColors.grey9B9B9B),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
              ),
              // SizedBox(height: 5.h), // Optional spacing
              Text(
                value,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  showSavePopup() {
    return AlertDialog(
      insetPadding: EdgeInsets.symmetric(horizontal: 20.w),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      contentPadding: EdgeInsets.zero,
      content: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.back();
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.transparent,
                    ),
                    padding: EdgeInsets.all(8.r),
                    child: SvgPicture.asset(
                      AppAssets.icClose,
                      colorFilter: ColorFilter.mode(
                        AppColors.transparent,
                        BlendMode.srcIn,
                      ),
                      height: 12,
                      width: 12,
                    ),
                  ),
                ),
                Text(
                  saveCardDetail.tr,
                  style: AppTextStyle.medium24(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Get.back();
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          isDarkMode()
                              ? AppColors.grey2A2A2A
                              : AppColors.greyF6F6F6,
                    ),
                    padding: EdgeInsets.all(8.r),
                    child: SvgPicture.asset(
                      AppAssets.icClose,
                      colorFilter: ColorFilter.mode(
                        isDarkMode() ? AppColors.whiteColor : AppColors.black,
                        BlendMode.srcIn,
                      ),
                      height: 12,
                      width: 12,
                    ),
                  ),
                ),
              ],
            ),
            Text(
              doYouWantTo.tr,
              textAlign: TextAlign.center,
              style: AppTextStyle.medium17(color: AppColors.grey9B9B9B),
            ),
            SizedBox(height: 20.h),
            Row(
              children: [
                Expanded(
                  child: CommonButton(
                    buttonColor:
                        isDarkMode()
                            ? AppColors.grey2A2A2A
                            : AppColors.greyEFEFEF,
                    onPressed: () {
                      Get.back();
                      Future.delayed(500.milliseconds, () async {
                        Get.find<HomeController>().deleteCardApi();
                      });
                    },
                    child: Text(
                      no.tr,
                      style: AppTextStyle.medium20(
                        color:
                            isDarkMode()
                                ? AppColors.whiteColor
                                : AppColors.black0D0C0C,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 15.w),
                Expanded(
                  child: CommonButton(
                    buttonColor: AppColors.primaryPurple,
                    onPressed: () {
                      Get.back();
                      Future.delayed(500.milliseconds, () {
                        Get.find<DashboardController>().setScanStatus(false);
                        Get.find<HomeController>().onFrontChange(false);
                        Get.find<HomeController>().onBackChange(false);
                      });
                    },
                    child: Text(
                      yes.tr,
                      style: AppTextStyle.medium20(color: AppColors.whiteColor),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  gradingWidget() {
    return GetBuilder<HomeController>(
      builder:
          (controller) => Column(
            children: [
              SizedBox(height: 20.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.whiteColor,
                        border: Border.all(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 12.w,
                        vertical: 10.h,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            lrText,
                            style: AppTextStyle.medium17(
                              color: AppColors.grey9B9B9B,
                            ),
                          ),
                          Obx(
                            () => Text(
                              controller.isBack.value
                                  ? controller
                                          .backCardGradingData
                                          ?.records
                                          ?.first
                                          .card
                                          ?.first
                                          .centering
                                          ?.leftRight
                                          .toString() ??
                                      ''
                                  : controller
                                          .cardGradingData
                                          ?.records
                                          ?.first
                                          .card
                                          ?.first
                                          .centering
                                          ?.leftRight
                                          .toString() ??
                                      '',
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 10.w),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.whiteColor,
                        border: Border.all(
                          color:
                              isDarkMode()
                                  ? AppColors.grey2A2A2A
                                  : AppColors.greyEBEBEB,
                        ),
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 12.w,
                        vertical: 10.h,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            tbText,
                            style: AppTextStyle.medium17(
                              color: AppColors.grey9B9B9B,
                            ),
                          ),
                          // SizedBox(width: 20.w),
                          Obx(
                            () => Text(
                              controller.isBack.value
                                  ? controller
                                          .backCardGradingData
                                          ?.records
                                          ?.first
                                          .card
                                          ?.first
                                          .centering
                                          ?.topBottom
                                          .toString() ??
                                      ''
                                  : controller
                                          .cardGradingData
                                          ?.records
                                          ?.first
                                          .card
                                          ?.first
                                          .centering
                                          ?.topBottom
                                          .toString() ??
                                      '',
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15.h),
              Obx(
                () => infoWidget(
                  title: centering.tr,
                  value:
                      controller.isBack.value
                          ? controller
                                  .backCardGradingData
                                  ?.records
                                  ?.first
                                  .grades
                                  ?.centering
                                  .toString() ??
                              ''
                          : controller
                                  .cardGradingData
                                  ?.records
                                  ?.first
                                  .grades
                                  ?.centering
                                  .toString() ??
                              '',
                ),
              ),
              // Divider(
              //   color:
              //   isDarkMode()
              //       ? AppColors.grey2A2A2A
              //       : AppColors.greyEBEBEB,
              // ),
              // infoWidget(title: "Edges", value: "9.5"),
              // Divider(
              //   color:
              //   isDarkMode()
              //       ? AppColors.grey2A2A2A
              //       : AppColors.greyEBEBEB,
              // ),
              // infoWidget(title: "Corners", value: "9.5"),
              Divider(
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
              ),
              Obx(
                () => infoWidget(
                  title: aiGrade.tr,
                  value:
                      controller.isBack.value
                          ? controller
                                      .backCardGradingData
                                      ?.records
                                      ?.first
                                      .grades
                                      ?.gradesFinal ==
                                  null
                              ? ''
                              : "${controller.backCardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${controller.backCardGradingData?.records?.first.grades?.condition ?? ''}"
                          : controller
                                  .cardGradingData
                                  ?.records
                                  ?.first
                                  .grades
                                  ?.gradesFinal ==
                              null
                          ? ''
                          : "${controller.cardGradingData?.records?.first.grades?.gradesFinal?.toString() ?? ''} ${controller.cardGradingData?.records?.first.grades?.condition ?? ''}",
                ),
              ),
              Divider(
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
              ),
              Obx(
                () => infoWidget(
                  title: cardSide.tr,
                  value:
                      controller.isBack.value
                          ? controller
                                  .backCardGradingData
                                  ?.records
                                  ?.first
                                  .card
                                  ?.first
                                  .tags
                                  ?.side
                                  ?.first
                                  .name ??
                              ''
                          : controller
                                  .cardGradingData
                                  ?.records
                                  ?.first
                                  .card
                                  ?.first
                                  .tags
                                  ?.side
                                  ?.first
                                  .name ??
                              '',
                ),
              ),
              Divider(
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEBEBEB,
              ),
              Obx(
                () => infoWidget(
                  title: category.tr,
                  value:
                      controller.isBack.value
                          ? controller
                                  .backCardGradingData
                                  ?.records
                                  ?.first
                                  .card
                                  ?.first
                                  .tags
                                  ?.category
                                  ?.first
                                  .name ??
                              ''
                          : controller
                                  .cardGradingData
                                  ?.records
                                  ?.first
                                  .card
                                  ?.first
                                  .tags
                                  ?.category
                                  ?.first
                                  .name ??
                              '',
                ),
              ),
              SizedBox(height: 20.h),
              controller.selectedCard.isEmpty
                  ? const SizedBox.shrink()
                  : Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          priceWidget(
                            title: ungraded.tr,
                            value:
                                controller.cardInfoData?.loosePrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                          SizedBox(width: 12.w),
                          priceWidget(
                            title: "${grade.tr} 7",
                            value:
                                controller.cardInfoData?.cibPrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                          SizedBox(width: 12.w),

                          priceWidget(
                            title: "${grade.tr} 8",
                            value:
                                controller.cardInfoData?.newPrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                        ],
                      ),
                      SizedBox(height: 15.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,

                        children: [
                          priceWidget(
                            title: "${grade.tr} 9",
                            value:
                                controller.cardInfoData?.gradedPrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                          SizedBox(width: 12.w),

                          priceWidget(
                            title: "${grade.tr} 9.5",
                            value:
                                controller.cardInfoData?.boxOnlyPrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                          SizedBox(width: 12.w),

                          priceWidget(
                            title: "PSA 10",
                            value:
                                controller.cardInfoData?.manualOnlyPrice
                                    ?.formatPrice() ??
                                '-',
                          ),
                        ],
                      ),
                    ],
                  ),
              SizedBox(height: 100.h),
            ],
          ),
    );
  }

  infoWidget({required String title, required String value}) {
    return Container(
      color: Colors.transparent,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // if (title != centering.tr)
          Text(
            "$title:",
            style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
          ),

          // if (title == centering.tr)
          //   Row(
          //     children: [
          //       Text(
          //         "$title:",
          //         style: AppTextStyle.medium20(color: AppColors.grey9B9B9B),
          //       ),
          //       SizedBox(width: 5.w),
          //       CompositedTransformTarget(
          //         link: _layerLink,
          //         child: GestureDetector(
          //           onTap: () {
          //             Future.delayed(Duration(milliseconds: 10), () {
          //               if (_overlayEntry == null) {
          //                 _showOverlay(_layerLink);
          //               } else {
          //                 _hideOverlay();
          //               }
          //             });
          //           },
          //           child: SvgPicture.asset(AppAssets.icInfo),
          //         ),
          //       ),
          //     ],
          //   ),
          Text(
            value,
            style: AppTextStyle.medium20(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
        ],
      ),
    );
  }

  Widget priceCheckerSheet() {
    return GetBuilder<HomeController>(
      builder:
          (controller) => Stack(
            alignment: Alignment.bottomCenter,
            children: [
              Container(
                decoration: BoxDecoration(
                  color:
                      isDarkMode()
                          ? AppColors.black1E1E1E
                          : AppColors.whiteColor,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(20.r),
                    topLeft: Radius.circular(20.r),
                  ),
                ),
                padding: EdgeInsets.only(
                  left: 20.w,
                  right: 20.w,
                  top: 15.h,
                  bottom: 20.h,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.transparent,
                          ),
                          padding: EdgeInsets.all(8.r),
                          child: SvgPicture.asset(
                            AppAssets.icClose,
                            colorFilter: ColorFilter.mode(
                              AppColors.transparent,
                              BlendMode.srcIn,
                            ),
                            height: 12,
                            width: 12,
                          ),
                        ),
                        Text(
                          priceChecker.tr,
                          style: AppTextStyle.semiBold24(
                            color:
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black0D0C0C,
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.back();
                            controller.selectedCard = '';
                            controller.searchController.clear();
                            Future.delayed(
                              1.5.seconds,
                              () => controller.searchCardData = null,
                            );
                            controller.update();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  isDarkMode()
                                      ? AppColors.grey2A2A2A
                                      : AppColors.greyF6F6F6,
                            ),
                            padding: EdgeInsets.all(8.r),
                            child: SvgPicture.asset(
                              AppAssets.icClose,
                              colorFilter: ColorFilter.mode(
                                isDarkMode()
                                    ? AppColors.whiteColor
                                    : AppColors.black,
                                BlendMode.srcIn,
                              ),
                              height: 12,
                              width: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    GetBuilder<HomeController>(
                      builder:
                          (controller) => commonTextfield(
                            controller: controller.searchController,
                            hintText: searchCard.tr,
                            onChanged: (value) async {
                              if (_debounce?.isActive ?? false) {
                                _debounce?.cancel();
                              }
                              _debounce = Timer(500.milliseconds, () async {
                                await controller.searchCard();
                              });
                            },
                            prefixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  AppAssets.icSearch,
                                  height: 22,
                                  width: 22,
                                  colorFilter: ColorFilter.mode(
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                                    BlendMode.srcIn,
                                  ),
                                ),
                              ],
                            ),
                            suffixWidget: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Obx(
                                  () =>
                                      controller.isShowClosed.value
                                          ? GestureDetector(
                                            onTap: () {
                                              controller.searchController
                                                  .clear();
                                              controller.searchCardData = null;
                                              controller.update();
                                            },
                                            child: SvgPicture.asset(
                                              AppAssets.icClose,
                                              colorFilter: ColorFilter.mode(
                                                isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C,
                                                BlendMode.srcIn,
                                              ),
                                              height: 15,
                                              width: 15,
                                            ),
                                          )
                                          : const SizedBox.shrink(),
                                ),
                              ],
                            ),
                          ),
                    ),
                    SizedBox(height: 20.h),
                    Expanded(
                      child: Obx(
                        () =>
                            controller.isSearchLoader.value
                                ? showSearchShimmer()
                                // ignore: prefer_is_empty
                                : controller.searchCardData?.products?.length ==
                                    0
                                ? Align(
                                  alignment: Alignment.topCenter,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 50.h),
                                    child: Text(
                                      noCard.tr,
                                      style: AppTextStyle.semiBold22(
                                        color:
                                            isDarkMode()
                                                ? AppColors.whiteColor
                                                : AppColors.black0D0C0C,
                                      ),
                                    ),
                                  ),
                                )
                                : ListView.separated(
                                  itemCount:
                                      controller
                                          .searchCardData
                                          ?.products
                                          ?.length ??
                                      0,
                                  itemBuilder: (context, index) {
                                    final productData =
                                        controller
                                            .searchCardData
                                            ?.products?[index];
                                    return Container(
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.greyEBEBEB,
                                          ),
                                        ),
                                      ),

                                      child: ListTile(
                                        onTap: () {
                                          controller.onCardSelect(
                                            value:
                                                productData?.productName ?? '',
                                            cardID: productData?.id ?? '',
                                          );
                                        },
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 15.w,
                                        ),
                                        // leading: Container(
                                        //   height: 50.h,
                                        //   width: 40.w,
                                        //   decoration: BoxDecoration(
                                        //     borderRadius: BorderRadius.circular(12.r),
                                        //     color: AppColors.transparent,
                                        //   ),
                                        //   child: Image.asset(
                                        //     AppAssets.imgPlaceHolder,
                                        //     height: 50.h,
                                        //     width: 40.w,
                                        //   ),
                                        // ),
                                        leading: Checkbox(
                                          materialTapTargetSize:
                                              MaterialTapTargetSize.shrinkWrap,
                                          checkColor: AppColors.whiteColor,

                                          side: BorderSide(
                                            color:
                                                isDarkMode()
                                                    ? AppColors.grey3E3E3E
                                                    : AppColors.borderD9D9D9,
                                          ),
                                          visualDensity: VisualDensity(
                                            horizontal:
                                                VisualDensity.minimumDensity,
                                            vertical:
                                                VisualDensity.minimumDensity,
                                          ),
                                          value:
                                              controller.selectedCard ==
                                              (productData?.productName ?? ''),
                                          activeColor: AppColors.primaryPurple,
                                          onChanged: (value) {
                                            controller.onCardSelect(
                                              value:
                                                  productData?.productName ??
                                                  '',
                                              cardID: productData?.id ?? '',
                                            );
                                          },
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              4.r,
                                            ),
                                          ),
                                        ),
                                        dense: true,
                                        title: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              productData?.productName ?? "",
                                              style: AppTextStyle.medium20(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.whiteColor
                                                        : AppColors.black0D0C0C,
                                              ),
                                            ),
                                            Text(
                                              productData?.loosePrice
                                                      ?.formatPrice() ??
                                                  '',
                                              style: AppTextStyle.medium17(
                                                color:
                                                    isDarkMode()
                                                        ? AppColors.grey9B9B9B
                                                        : AppColors
                                                            .primaryPurple,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10.h);
                                  },
                                ),
                      ),
                    ),
                  ],
                ),
              ),
              (controller.searchCardData?.products != null &&
                      controller.searchCardData!.products!.isNotEmpty)
                  ? Padding(
                    padding: EdgeInsets.only(
                      left: 20.w,
                      right: 20.w,
                      bottom: 20.h,
                    ),
                    child: CommonButton(
                      buttonWidth: double.infinity,
                      buttonColor:
                          controller.selectedCard.isEmpty
                              ? isDarkMode()
                                  ? AppColors.disableColorDark
                                  : AppColors.disableColor
                              : AppColors.primaryPurple,
                      onPressed: () {
                        controller.searchController.clear();
                        Future.delayed(
                          1.5.seconds,
                          () => controller.searchCardData = null,
                        );
                        controller.update();
                        controller.cardInfoApi();
                        Get.back();
                      },
                      child: Text(
                        done.tr,
                        style: AppTextStyle.medium20(
                          color:
                              controller.selectedCard.isEmpty
                                  ? AppColors.whiteColor.withValues(alpha: 0.4)
                                  : AppColors.whiteColor,
                        ),
                      ),
                    ),
                  )
                  : SizedBox(),
            ],
          ),
    );
  }
}

createCollectionDialog(BuildContext context) {
  return GetBuilder<HomeController>(
    builder: (controller) {
      return AlertDialog(
        insetPadding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        backgroundColor:
            isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        contentPadding: EdgeInsets.zero,
        content: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(),
                  Text(
                    createCollection.tr,
                    style: AppTextStyle.semiBold24(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),

                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.greyF6F6F6,
                      ),
                      padding: EdgeInsets.all(5.r),
                      child: SvgPicture.asset(
                        AppAssets.icClose,
                        colorFilter: ColorFilter.mode(
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                          BlendMode.srcIn,
                        ),
                        height: 14,
                        width: 14,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15.h),
              Text(
                collectionName.tr,
                textAlign: TextAlign.center,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.whiteColor
                          : AppColors.black0D0C0C,
                ),
              ),
              SizedBox(height: 10.h),
              commonTextfield(
                onChanged: (value) {
                  controller.update();
                },
                controller: controller.collectionNameController,
                hintText: enterYourCollectionName.tr,
              ),
              SizedBox(height: 20.h),
              CommonButton(
                onPressed: () {
                  controller.createCollectionApi(context);
                  // Navigator.pop(Get.context!);
                  Get.back();
                },
                buttonColor:
                    controller.collectionNameController.text.isEmpty
                        ? isDarkMode()
                            ? AppColors.disableColorDark
                            : AppColors.disableColor
                        : AppColors.primaryPurple,
                buttonWidth: double.infinity,
                child: Text(
                  continueText.tr,
                  style: AppTextStyle.medium20(
                    color: AppColors.whiteColor.withValues(alpha: 0.4),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

addCollectionDialog(BuildContext context) {
  return GetBuilder<HomeController>(
    builder: (controller) {
      return AlertDialog(
        insetPadding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        backgroundColor:
            isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        contentPadding: EdgeInsets.zero,
        content: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(),
                  Text(
                    createNewCollection.tr,
                    style: AppTextStyle.medium22(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),

                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.greyF6F6F6,
                      ),
                      padding: EdgeInsets.all(8.r),
                      child: SvgPicture.asset(
                        AppAssets.icClose,
                        colorFilter: ColorFilter.mode(
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                          BlendMode.srcIn,
                        ),
                        height: 12,
                        width: 12,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.h),
              Text(
                addCards.tr,
                textAlign: TextAlign.center,
                style: AppTextStyle.medium17(color: AppColors.grey9B9B9B),
              ),
              SizedBox(height: 10.h),
              CommonButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return createCollectionDialog(context);
                    },
                  );
                },
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15.w),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset(
                        AppAssets.icAddWhite,
                        width: 16,
                        height: 16,
                      ),
                      SizedBox(width: 12.w),
                      Padding(
                        padding: EdgeInsets.only(bottom: 4.h),
                        child: Text(
                          createCollection.tr,
                          style: AppTextStyle.medium20(
                            color: AppColors.whiteColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

collectionListDialog(BuildContext context) {
  return GetBuilder<HomeController>(
    builder: (controller) {
      return AlertDialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 10.w),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        backgroundColor:
            isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
        contentPadding: EdgeInsets.zero,
        content: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(),
                  Text(
                    addToCollection.tr,
                    style: AppTextStyle.semiBold24(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),

                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.greyF6F6F6,
                      ),
                      padding: EdgeInsets.all(8.r),
                      child: SvgPicture.asset(
                        AppAssets.icClose,
                        colorFilter: ColorFilter.mode(
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                          BlendMode.srcIn,
                        ),
                        height: 12,
                        width: 12,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.h),
              SizedBox(
                height: 200.h,
                width: Get.width,
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: controller.collectionList.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return SizedBox(height: 10.h);
                  },
                  itemBuilder: (BuildContext context, int index) {
                    CollectionListData data = controller.collectionList[index];
                    return InkWell(
                      onTap: () {
                        controller.selectedCollectionID = data.id;
                        controller.selectedCollectionItems = data.itemCount;
                        controller.update();
                      },
                      child: Row(
                        children: [
                          Icon(
                            controller.selectedCollectionID == data.id
                                ? Icons.check_box
                                : Icons.check_box_outline_blank_rounded,
                            color:
                                controller.selectedCollectionID == data.id
                                    ? AppColors.primaryPurple
                                    : AppColors.blackB3B3B3,
                          ),
                          SizedBox(width: 10.w),
                          SvgPicture.asset(AppAssets.icCollectionIcon),
                          SizedBox(width: 10.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  data.name ?? '',
                                  style: AppTextStyle.medium20(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ),
                                ),

                                Text(
                                  '${data.itemCount.toString()} ${items.tr}',
                                  style: AppTextStyle.medium17(
                                    color: AppColors.grey9B9B9B,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SvgPicture.asset(AppAssets.icArrowRightDark),
                        ],
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 10.h),
              CommonButton(
                buttonWidth: double.infinity,
                onPressed: () {
                  // if ((controller.selectedCollectionItems ?? 0) >= 10) {
                  //   showModalBottomSheet(
                  //     constraints: BoxConstraints(
                  //       maxHeight: MediaQuery.of(context).size.height * 0.8,
                  //       minHeight: MediaQuery.of(context).size.height * 0.8,
                  //     ),
                  //     isScrollControlled: true,
                  //     context: context,
                  //     builder: (context) {
                  //       return PaywallScreen();
                  //     },
                  //   );
                  // } else {
                  controller.onTapContinue();
                  // }
                },
                child: Text(
                  continueText.tr,
                  style: AppTextStyle.medium20(color: AppColors.whiteColor),
                ),
              ),

              SizedBox(height: 10.h),

              TextButton.icon(
                onPressed: () {
                  Get.back();
                  showDialog(
                    context: context,
                    builder: (context) {
                      return createCollectionDialog(context);
                    },
                  );
                },
                label: Text(
                  createCollection.tr,
                  style: AppTextStyle.medium20(color: AppColors.whiteColor),
                ),
                icon: Icon(Icons.add, color: AppColors.whiteColor, size: 26),
              ),
            ],
          ),
        ),
      );
    },
  );
}
