import 'dart:async';
import 'dart:io';

import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/controllers/profilecontroller/profile_controller.dart';
import 'package:card_centering/pages/dashboard/dashboard_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../apptheme/app_assets.dart';
import '../../../../apptheme/app_constants.dart';
import '../../../../apptheme/app_textstyle.dart';
import '../../../../widgets/common_button.dart';
import '../../../../widgets/common_textfield.dart';
import '../../../../widgets/common_widgets.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FocusNode _focusNode1 = FocusNode();
  final FocusNode _focusNode2 = FocusNode();
  final FocusNode _focusNode3 = FocusNode();

  Timer? _debounce;

  @override
  void dispose() {
    _focusNode1.dispose();
    _focusNode2.dispose();
    _focusNode3.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Get.put(ProfileController(), permanent: true);
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: GetBuilder<ProfileController>(
        builder: (profileController) {
          return Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: true,
            backgroundColor:
                isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
            bottomNavigationBar: Padding(
              padding: EdgeInsets.only(
                left: 20.w,
                right: 20.w,
                bottom: Platform.isIOS ? 40.h : 20.h,
              ),
              child: CommonButton(
                buttonColor:
                    (profileController.nameController.text.isEmpty ||
                            profileController.dayController.text.isEmpty ||
                            profileController.monthController.text.isEmpty ||
                            profileController.yearController.text.isEmpty)
                        ? AppColors.disableColorDark
                        : AppColors.primaryPurple,

                buttonWidth: double.infinity,
                buttonHeight: 55.h,
                radius: 12.r,
                onPressed: () async {
                  await Get.find<ProfileController>().updateProfile(
                    isEdit: false,
                  );
                },
                child: Text(
                  saveProfile.tr,
                  style: AppTextStyle.medium20(
                    color:
                        (profileController.nameController.text.isEmpty ||
                                profileController.dayController.text.isEmpty ||
                                profileController
                                    .monthController
                                    .text
                                    .isEmpty ||
                                profileController.yearController.text.isEmpty)
                            ? AppColors.disableWhiteColor
                            : AppColors.whiteColor,
                  ),
                ),
              ),
            ),
            body: Stack(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 65.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          // GestureDetector(
                          //   onTap: () {
                          //     Get.back();
                          //   },
                          //   child: Container(
                          //     decoration: BoxDecoration(
                          //       shape: BoxShape.circle,
                          //       color: Colors.transparent,
                          //     ),
                          //     margin: EdgeInsets.all(12.r),
                          //     child: Center(
                          //       child: SvgPicture.asset(
                          //         isDarkMode()
                          //             ? AppAssets.icArrowBackDark
                          //             : AppAssets.icArrowBack,
                          //         width: 18,
                          //         height: 18,
                          //       ),
                          //     ),
                          //   ),
                          // ),
                          GestureDetector(
                            onTap: () async {
                              Get.to(
                                () => DashboardScreen(),
                                transition: Transition.rightToLeftWithFade,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color:
                                    isDarkMode()
                                        ? AppColors.black1E1E1E
                                        : AppColors.whiteColor,
                                borderRadius: BorderRadius.circular(30.r),
                                border: Border.all(
                                  color:
                                      isDarkMode()
                                          ? AppColors.grey2A2A2A
                                          : AppColors.greyEBEBEB,
                                ),
                              ),
                              padding: EdgeInsets.symmetric(
                                horizontal: 12.w,
                                vertical: 6.h,
                              ),
                              child: Text(
                                skipForNow.tr,
                                style: AppTextStyle.medium20(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20.h),
                      Expanded(
                        child: ListView(
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: Stack(
                                alignment: Alignment.bottomRight,
                                clipBehavior: Clip.none,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      showDialog(
                                        context: context,
                                        builder:
                                            (context) => pickImageDialog(
                                              onCameraTap: () async {
                                                Get.back();
                                                await profileController
                                                    .pickUserProfile(
                                                      source:
                                                          ImageSource.camera,
                                                    );
                                              },
                                              onGalleryTap: () async {
                                                Get.back();
                                                await profileController
                                                    .pickUserProfile(
                                                      source:
                                                          ImageSource.gallery,
                                                    );
                                              },
                                            ),
                                      );
                                    },
                                    child:
                                        profileController
                                                    .userProfileImage
                                                    .isNotEmpty &&
                                                profileController
                                                        .profileImage ==
                                                    null
                                            ? ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(50.r),
                                              child: CircleAvatar(
                                                radius: 50.r,
                                                backgroundColor:
                                                    isDarkMode()
                                                        ? AppColors.grey2A2A2A
                                                        : AppColors.greyEBEBEB,

                                                backgroundImage:
                                                    Image.network(
                                                      profileController
                                                          .userProfileImage,
                                                      loadingBuilder: (
                                                        context,
                                                        child,
                                                        loadingProgress,
                                                      ) {
                                                        return Shimmer.fromColors(
                                                          baseColor:
                                                              AppColors
                                                                  .grey2A2A2A,
                                                          highlightColor:
                                                              AppColors
                                                                  .grey9B9B9B,
                                                          child: Container(
                                                            height: 70,
                                                            width: 70,
                                                            decoration:
                                                                BoxDecoration(
                                                                  shape:
                                                                      BoxShape
                                                                          .circle,
                                                                  color:
                                                                      Colors
                                                                          .grey,
                                                                ),
                                                          ),
                                                        );
                                                      },
                                                      errorBuilder: (
                                                        context,
                                                        error,
                                                        stackTrace,
                                                      ) {
                                                        return SvgPicture.asset(
                                                          AppAssets.icProfile,
                                                        );
                                                      },
                                                    ).image,
                                              ),
                                            )
                                            : profileController.profileImage !=
                                                null
                                            ? Container(
                                              height: 90.h,
                                              width: 90.w,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                              ),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(50.r),
                                                child: Image.file(
                                                  profileController
                                                      .profileImage!,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            )
                                            : Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                // color: AppColors.purpleF1D5F9,
                                                gradient: LinearGradient(
                                                  begin: Alignment.topCenter,
                                                  end: Alignment.bottomLeft,
                                                  colors: [
                                                    isDarkMode()
                                                        ? AppColors.black1E1E1E
                                                        : AppColors
                                                            .purpleF4E7FF,
                                                    isDarkMode()
                                                        ? AppColors.grey2A2A2A
                                                        : AppColors
                                                            .purpleF1D5F9,
                                                  ],
                                                ),
                                                // border: Border.all(color: AppColors.orangeF16E31),
                                              ),
                                              padding: EdgeInsets.all(25.r),
                                              child: SvgPicture.asset(
                                                AppAssets.icProfile,
                                                width: 35,
                                                height: 35,
                                              ),
                                            ),
                                  ),
                                  Positioned(
                                    right: -6.w,
                                    bottom: -2.h,
                                    child: GestureDetector(
                                      onTap: () {
                                        showDialog(
                                          context: context,
                                          builder:
                                              (context) => pickImageDialog(
                                                onCameraTap: () async {
                                                  Get.back();
                                                  await profileController
                                                      .pickUserProfile(
                                                        source:
                                                            ImageSource.camera,
                                                      );
                                                },
                                                onGalleryTap: () async {
                                                  Get.back();
                                                  await profileController
                                                      .pickUserProfile(
                                                        source:
                                                            ImageSource.gallery,
                                                      );
                                                },
                                              ),
                                        );
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          // gradient: LinearGradient(
                                          //   begin: Alignment.topCenter,
                                          //   end: Alignment.bottomCenter,
                                          //   colors: [
                                          //     AppColors.purpleF1D5F9,
                                          //     AppColors.purpleF1D5F9,
                                          //     AppColors.purpleF1D5F9,
                                          //   ],
                                          // ),
                                          shape: BoxShape.circle,
                                        ),
                                        padding: EdgeInsets.all(4.r),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: AppColors.black121212,
                                              width: 2,
                                            ),
                                            shape: BoxShape.circle,
                                            // color:
                                            //     isDarkMode()
                                            //         ? AppColors.black1E1E1E
                                            //         : AppColors.grey2A2A2A,
                                            gradient: LinearGradient(
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomLeft,
                                              colors: [
                                                isDarkMode()
                                                    ? AppColors.black1E1E1E
                                                    : AppColors.purpleF4E7FF,
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : AppColors.purpleF1D5F9,
                                              ],
                                            ),
                                          ),
                                          padding: EdgeInsets.all(5.r),
                                          child: SvgPicture.asset(
                                            AppAssets.icAdd,
                                            height: 14,
                                            width: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20.h),
                            Text(
                              yourProfile.tr,
                              style: AppTextStyle.semiBold32(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                            Text(
                              setUpYour.tr,
                              style: AppTextStyle.regular20(
                                color:
                                    isDarkMode()
                                        ? AppColors.grey9B9B9B
                                        : AppColors.grey878787,
                              ),
                            ),
                            SizedBox(height: 20.h),
                            Text(
                              name.tr,
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                            SizedBox(height: 10.h),
                            commonTextfield(
                              controller: profileController.nameController,
                              hintText: enterYourName.tr,
                              onChanged: (val) {
                                profileController.update();
                              },
                            ),
                            SizedBox(height: 20.h),
                            Text(
                              birthDay.tr,
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.whiteColor
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                            SizedBox(height: 10.h),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: commonTextfield(
                                    focusNode: _focusNode1,
                                    controller: profileController.dayController,
                                    keyboardType: TextInputType.number,
                                    onSubmitted: (p0) {
                                      if (profileController
                                          .dayController
                                          .text
                                          .isEmpty) {
                                        showToast(message: pleaseEnterDate.tr);
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode1);
                                      } else {
                                        if (int.parse(p0) == 0) {
                                          showToast(
                                            message: enterValidNumber.tr,
                                          );
                                          FocusScope.of(
                                            context,
                                          ).requestFocus(_focusNode1);
                                        } else {
                                          if (int.parse(p0) <= 9) {
                                            profileController
                                                .dayController
                                                .text = '0$p0';
                                          }
                                          _focusNode1.unfocus();
                                          FocusScope.of(
                                            context,
                                          ).requestFocus(_focusNode2);
                                        }
                                      }
                                    },
                                    onChanged: (value) {
                                      if (value != null && value.isNotEmpty) {
                                        final dayValue = int.parse(value);
                                        if (dayValue > 31) {
                                          profileController.dayController.text =
                                              '31';
                                        }
                                        /*else if (dayValue < 1) {
                                          profileController.dayController.text =
                                              '1';
                                        }*/
                                        if (_debounce?.isActive ?? false) {
                                          _debounce?.cancel();
                                        }
                                        _debounce = Timer(300.milliseconds, () {
                                          if (value.length == 2) {
                                            if (int.parse(value) != 0) {
                                              FocusScope.of(
                                                context,
                                              ).requestFocus(_focusNode2);
                                            } else {
                                              showToast(
                                                message: enterValidNumber.tr,
                                              );
                                            }
                                          }
                                        });
                                        profileController.update();
                                      }
                                    },
                                    hintText: "dd",
                                    textFormatter: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(2),
                                    ],
                                  ),
                                ),

                                SizedBox(width: 12.w),
                                Expanded(
                                  child: commonTextfield(
                                    focusNode: _focusNode2,
                                    controller:
                                        profileController.monthController,
                                    keyboardType: TextInputType.number,
                                    onChanged: (value) {
                                      if (value != null && value.isNotEmpty) {
                                        final dayValue = int.parse(value);
                                        if (dayValue > 12) {
                                          profileController
                                              .monthController
                                              .text = '12';
                                        }
                                        /*else if (dayValue < 1) {
                                          profileController
                                              .monthController
                                              .text = '1';
                                        }*/
                                        if (_debounce?.isActive ?? false) {
                                          _debounce?.cancel();
                                        }
                                        _debounce = Timer(300.milliseconds, () {
                                          if (value.length == 2) {
                                            if (int.parse(value) != 0) {
                                              FocusScope.of(
                                                context,
                                              ).requestFocus(_focusNode3);
                                            } else {
                                              showToast(
                                                message: enterValidNumber.tr,
                                              );
                                            }
                                          }
                                        });
                                        profileController.update();
                                      }
                                    },
                                    hintText: "mm",
                                    onSubmitted: (p0) {
                                      if (profileController
                                          .monthController
                                          .text
                                          .isEmpty) {
                                        showToast(message: pleaseEnterMonth.tr);
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode2);
                                      }
                                      if (int.parse(p0) == 0) {
                                        showToast(message: enterValidNumber.tr);
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode2);
                                      } else {
                                        if (int.parse(p0) <= 9) {
                                          profileController
                                              .monthController
                                              .text = '0$p0';
                                        }
                                        _focusNode2.unfocus();
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode3);
                                      }
                                    },
                                    textFormatter: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(2),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Expanded(
                                  child: commonTextfield(
                                    focusNode: _focusNode3,
                                    controller:
                                        profileController.yearController,
                                    keyboardType: TextInputType.number,
                                    hintText: "yyyy",
                                    onChanged: (value) {
                                      if (value != null && value.isNotEmpty) {
                                        final enteredYear = int.tryParse(value);
                                        final currentYear = DateTime.now().year;
                                        if (enteredYear != null) {
                                          if (enteredYear > currentYear) {
                                            profileController
                                                .yearController
                                                .text = currentYear.toString();
                                            profileController
                                                    .yearController
                                                    .selection =
                                                TextSelection.fromPosition(
                                                  TextPosition(
                                                    offset:
                                                        profileController
                                                            .yearController
                                                            .text
                                                            .length,
                                                  ),
                                                );
                                          } else if (enteredYear < 1) {
                                            profileController
                                                .yearController
                                                .text = '1';
                                            profileController
                                                    .yearController
                                                    .selection =
                                                TextSelection.fromPosition(
                                                  TextPosition(
                                                    offset:
                                                        profileController
                                                            .yearController
                                                            .text
                                                            .length,
                                                  ),
                                                );
                                          }
                                        }
                                      }
                                      profileController.update();
                                    },
                                    onSubmitted: (p0) {
                                      if (profileController
                                          .yearController
                                          .text
                                          .isEmpty) {
                                        showToast(message: pleaseEnterYear.tr);
                                        FocusScope.of(
                                          context,
                                        ).requestFocus(_focusNode3);
                                      } else {
                                        _focusNode3.unfocus();
                                      }
                                    },
                                    textFormatter: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(4),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 20.h),
                    ],
                  ),
                ),

                Obx(
                  () =>
                      profileController.isShowLoader.value
                          ? showLoader()
                          : const SizedBox.shrink(),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  pickImageDialog({
    required VoidCallback onCameraTap,
    required VoidCallback onGalleryTap,
  }) {
    return AlertDialog(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
      insetPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onCameraTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),

                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icCamera),
                          SizedBox(height: 10.h),
                          Text(
                            takeAPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.w),
              Expanded(
                child: GestureDetector(
                  onTap: onGalleryTap,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: 20.h,
                      horizontal: 15.w,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset(AppAssets.icGallery),
                          SizedBox(height: 10.h),
                          Text(
                            selectPhoto.tr,
                            textAlign: TextAlign.center,
                            style: AppTextStyle.medium20(
                              color:
                                  isDarkMode()
                                      ? AppColors.whiteColor
                                      : AppColors.black0D0C0C,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      // content: Container(
      //   decoration: BoxDecoration(
      //     borderRadius: BorderRadius.circular(14.r),
      //     color: AppColors.whiteColor,
      //   ),
      //   padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
      //   child: ,
      // ),
    );
  }
}
