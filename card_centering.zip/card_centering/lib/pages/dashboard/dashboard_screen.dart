import 'dart:io';

import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/apptheme/app_colors.dart';
import 'package:card_centering/apptheme/app_strings.dart';
import 'package:card_centering/apptheme/app_textstyle.dart';
import 'package:card_centering/controllers/dashboardcontrollers/home_controller.dart';
import 'package:card_centering/pages/authscreens/auth_screen.dart';
import 'package:card_centering/pages/dashboard/pages/collectionmodule/collection_screen.dart';
import 'package:card_centering/pages/dashboard/pages/home_page.dart';
import 'package:card_centering/pages/dashboard/pages/paywallscreen/paywall_screen.dart';
import 'package:card_centering/pages/dashboard/pages/setting_screen.dart';
import 'package:card_centering/pages/dashboard/pages/settingpage/edit_profile.dart';
import 'package:card_centering/pages/dashboard/pages/settingpage/faq_screen.dart';
import 'package:card_centering/pages/dashboard/pages/settingpage/language_page.dart';
import 'package:card_centering/prefmanage/pref_manage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shimmer/shimmer.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../apptheme/app_constants.dart';
import '../../controllers/dashboardcontrollers/dashboard_controller.dart';
import '../../controllers/dashboardcontrollers/setting_controller.dart';
import '../../controllers/profilecontroller/profile_controller.dart';
import '../../widgets/common_button.dart';
import 'pages/drawerscreen/favorite_screen.dart';
import 'pages/drawerscreen/manual_grading_page.dart';
import 'pages/price_checker_page.dart';
import 'pages/searchcard/search_card_page.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Widget> pages = [
    const HomePage(),
    const CollectionScreen(),
    const SearchCardPage(),
    const SettingScreen(),
  ];

  final scaffoldKey = GlobalKey<ScaffoldState>();

  List<TargetFocus> targets = [];
  List<TargetFocus> manualTargets = [];
  GlobalKey keyAutoScan = GlobalKey();
  GlobalKey keyCollection = GlobalKey();
  GlobalKey keyDrawer = GlobalKey();
  GlobalKey keyManualGrading = GlobalKey();

  TutorialCoachMark? tutorialCoachMark;
  TutorialCoachMark? manualGradingTutorialCoachMark;

  bool isShow = false;

  void showTutorial() {
    initTargets();

    tutorialCoachMark = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.white,
      textSkip: "SKIP",
      textStyleSkip: AppTextStyle.medium20(color: AppColors.black0D0C0C),
      paddingFocus: 10,
      opacityShadow: 0.8,
      onFinish: () async {
        PrefManager().setBoolData(key: homeAppTutorial, value: true);
        // isShow = await PrefManager().getBoolData(key: homeAppTutorial);
        // setState(() {});
        //
        // Future.delayed()

        // scaffoldKey.currentState!.openDrawer();
        // WidgetsBinding.instance.addPostFrameCallback((_) async {
        //   bool isManualShow = await PrefManager().getBoolData(
        //     key: manualTutorial,
        //   );
        //   setState(() {});
        //
        //   if (isManualShow == false) {
        //     showManualGradingTutorial();
        //   }
        // });
        debugPrint("Tutorial finished");
      },
      onSkip: () {
        PrefManager().setBoolData(key: homeAppTutorial, value: true);
        debugPrint("Tutorial skipped");
        return true;
      },
    )..show(context: context);
  }

  void initTargets() {
    targets.add(
      TargetFocus(

        alignSkip: Alignment.topRight,
        keyTarget: keyAutoScan,
        contents: [
          TargetContent(
            align: ContentAlign.top,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  'Scan Card',
                  style: AppTextStyle.medium24(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
                Text(
                  'Tap Here to Scan your card and get Card\'s Info',
                  style: AppTextStyle.medium18(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    targets.add(
      TargetFocus(
        keyTarget: keyCollection,
        alignSkip: Alignment.topRight,
        contents: [
          TargetContent(
            align: ContentAlign.top,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Collections',
                  style: AppTextStyle.medium24(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
                Text(
                  'Create Your Card\'s Collection to get easy access of your cards',
                  style: AppTextStyle.medium18(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
    targets.add(
      TargetFocus(
        // identify: 'Swipe Left!',
        keyTarget: keyDrawer,
        alignSkip: Alignment.topRight,
        contents: [
          TargetContent(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Lottie.asset('assets/animation/left_swipe.json',
                //     height: 70, width: 70, fit: BoxFit.cover),
                Text(
                  'Menu',
                  style: AppTextStyle.medium24(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
                // Text(
                //   'Create Your Card\'s Collection to get easy access of your cards',
                //    style: AppTextStyle.medium18(color: isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C ),
                // )
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool isManualShow = false;

  isShowTutorial() async {
    bool isShow = await PrefManager().getBoolData(key: homeAppTutorial);
    isManualShow = await PrefManager().getBoolData(key: manualTutorial);
    setState(() {});
    if (isShow == false) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showTutorial();
      });
    }
    // if (isManualShow == false) {
    //   showManualGradingTutorial();
    // }

    debugPrint("isShowTutorial ==== $isShow ======== $isManualShow");
  }

  initManualTutorial() {
    manualTargets.add(
      TargetFocus(
        shape: ShapeLightFocus.RRect,
        radius: 8,
        paddingFocus: 30,
        // targetPosition: TargetPosition(Size(200, 200), Offset(-100, 100)),
        alignSkip: Alignment.topRight,
        keyTarget: keyManualGrading,
        contents: [
          TargetContent(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Manual Card Grading',
                  style: AppTextStyle.medium24(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
                Text(
                  'Grade Your Card Manually',
                  style: AppTextStyle.medium18(
                    color:
                        isDarkMode()
                            ? AppColors.black0D0C0C
                            : AppColors.whiteColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  showManualGradingTutorial() {
    initManualTutorial();
    manualGradingTutorialCoachMark = TutorialCoachMark(
      targets: manualTargets,
      colorShadow: Colors.white,
      textSkip: "SKIP",
      textStyleSkip: AppTextStyle.medium20(color: AppColors.black0D0C0C),
      paddingFocus: 10,
      opacityShadow: 0.8,
      onFinish: () {
        PrefManager().setBoolData(key: manualTutorial, value: true);
        debugPrint("Tutorial finished");
      },
      onSkip: () {
        PrefManager().setBoolData(key: manualTutorial, value: true);
        debugPrint("Tutorial skipped");
        return true;
      },
    )..show(context: context);
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Future.delayed(1.seconds, () {
        isShowTutorial();
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Get.put(DashboardController());
    Get.put(ProfileController());
    Get.put(SettingController());
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (Get.find<DashboardController>().currentIndex == 0) {
          showDialog(
            context: context,
            builder: (context) {
              return exitSheet();
            },
          );
        } else {
          Get.find<DashboardController>().currentIndex = 0;
          Get.find<DashboardController>().update();
        }
      },
      child: GetBuilder<DashboardController>(
        builder:
            (controller) => Scaffold(
              key: scaffoldKey,
              backgroundColor:
                  isDarkMode() ? AppColors.black121212 : AppColors.whiteColor,
              drawer: drawerWidget(),
              appBar:
                  controller.currentIndex != 0
                      ? null
                      : controller.isScanned == true
                      ? null
                      : AppBar(
                        toolbarHeight: 80.h,
                        leading: Column(
                          key: keyDrawer,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: () async {
                                // bool isShow = await PrefManager().getBoolData(
                                //   key: manualTutorial,
                                // );
                                scaffoldKey.currentState!.openDrawer();
                                // WidgetsBinding.instance.addPostFrameCallback((
                                //   _,
                                // ) {
                                //   if (isShow == false) {
                                //     showManualGradingTutorial();
                                //   }
                                // });
                              },
                              child: Container(
                                height: 45.h,
                                width: 45.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color:
                                      isDarkMode()
                                          ? AppColors.black121212
                                          : AppColors.whiteFAFAFA,
                                  border: Border.all(
                                    color:
                                        isDarkMode()
                                            ? AppColors.grey2A2A2A
                                            : AppColors.greyEBEBEB,
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SvgPicture.asset(
                                      AppAssets.icDrawer,
                                      colorFilter: ColorFilter.mode(
                                        isDarkMode()
                                            ? AppColors.greyCCCCCC
                                            : AppColors.black0D0C0C,
                                        BlendMode.srcIn,
                                      ),
                                      width: 16,
                                      height: 16,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        elevation: 0,
                        backgroundColor: Colors.transparent,
                        systemOverlayStyle: SystemUiOverlayStyle(
                          statusBarIconBrightness:
                              isDarkMode() ? Brightness.light : Brightness.dark,
                        ),
                        actions: [
                          GestureDetector(
                            onTap: () {
                              showModalBottomSheet(
                                constraints: BoxConstraints(
                                  maxHeight:
                                      MediaQuery.of(context).size.height * 0.8,
                                  minHeight:
                                      MediaQuery.of(context).size.height * 0.8,
                                ),
                                isScrollControlled: true,
                                context: context,
                                builder: (context) {
                                  return PaywallScreen();
                                },
                              );
                            },
                            child: SvgPicture.asset(
                              AppAssets.imgPremium,
                              width: 45.h,
                              height: 45.h,
                            ),
                          ),
                          SizedBox(width: 20.w),
                        ],
                      ),
              body: GetBuilder<DashboardController>(
                builder:
                    (dashboardController) => Center(
                      child: pages.elementAt(dashboardController.currentIndex),
                    ),
              ),
              floatingActionButton:
                  MediaQuery.of(context).viewInsets.bottom != 0
                      ? null
                      : FloatingActionButton(
                        key: keyAutoScan,
                        heroTag: null,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50.r),
                        ),
                        onPressed: () async {
                          // if (Get.find<HomeController>().userAttempts.value >=
                          //     3) {
                          //   showModalBottomSheet(
                          //     constraints: BoxConstraints(
                          //       maxHeight:
                          //           MediaQuery.of(context).size.height * 0.8,
                          //       minHeight:
                          //           MediaQuery.of(context).size.height * 0.8,
                          //     ),
                          //     isScrollControlled: true,
                          //     context: context,
                          //     builder: (context) {
                          //       return PaywallScreen();
                          //     },
                          //   );
                          // } else {
                          Get.find<HomeController>().getImageFromCamera(true);
                          // Get.to(
                          //   () => DemoScanPage(),
                          //   transition: Transition.rightToLeftWithFade,
                          // );
                          // }
                        },
                        backgroundColor: AppColors.primaryPurple,
                        elevation: 3,
                        child: SvgPicture.asset(
                          AppAssets.icScanWhite,
                          width: 28,
                          height: 28,
                        ),
                      ),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerDocked,
              bottomNavigationBar: GetBuilder<DashboardController>(
                builder:
                    (dashboardController) => Container(
                      decoration: BoxDecoration(
                        border: Border(
                          top: BorderSide(
                            color:
                                isDarkMode()
                                    ? AppColors.grey2A2A2A
                                    : AppColors.greyEBEBEB,
                          ),
                        ),
                      ),
                      child: BottomAppBar(
                        padding: EdgeInsets.only(top: 15.h),
                        color:
                            context.isDarkMode
                                ? AppColors.black1E1E1E
                                : AppColors.whiteColor,
                        child: Row(
                          children: [
                            // Left side icons
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  dashboardController.onBottomNavBarTapped(0);
                                },
                                child: Column(
                                  children: [
                                    dashboardController.currentIndex == 0
                                        ? SvgPicture.asset(
                                          AppAssets.icHomeSelected,
                                          width: 24,
                                          height: 24,
                                        )
                                        : SvgPicture.asset(
                                          AppAssets.icHome,
                                          width: 24,
                                          height: 24,
                                        ),
                                    SizedBox(height: 5.h),
                                    Text(
                                      home.tr,
                                      style: AppTextStyle.medium16(
                                        color:
                                            dashboardController.currentIndex ==
                                                    0
                                                ? isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C
                                                : isDarkMode()
                                                ? AppColors.grey888888
                                                : AppColors.grey9B9B9B,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            Expanded(
                              child: GestureDetector(
                                key: keyCollection,
                                onTap: () {
                                  dashboardController.onBottomNavBarTapped(1);
                                },
                                child: Column(
                                  children: [
                                    dashboardController.currentIndex == 1
                                        ? SvgPicture.asset(
                                          AppAssets.icCollectionSelected,
                                          width: 24,
                                          height: 24,
                                        )
                                        : SvgPicture.asset(
                                          AppAssets.icCollection,
                                          width: 24,
                                          height: 24,
                                        ),
                                    SizedBox(height: 5.h),

                                    Text(
                                      collection.tr,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.medium16(
                                        color:
                                            dashboardController.currentIndex ==
                                                    1
                                                ? isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C
                                                : isDarkMode()
                                                ? AppColors.grey888888
                                                : AppColors.grey9B9B9B,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            Expanded(
                              child: Visibility(
                                visible: false,
                                child: GestureDetector(
                                  onTap: () {
                                    dashboardController.onBottomNavBarTapped(1);
                                  },
                                  child: Column(
                                    children: [
                                      dashboardController.currentIndex == 1
                                          ? SvgPicture.asset(
                                            AppAssets.icCollectionSelected,
                                            width: 24,
                                            height: 24,
                                          )
                                          : SvgPicture.asset(
                                            AppAssets.icCollection,
                                            width: 24,
                                            height: 24,
                                          ),
                                      SizedBox(height: 5.h),

                                      Text(
                                        collection.tr,
                                        style: AppTextStyle.medium16(
                                          color:
                                              dashboardController
                                                          .currentIndex ==
                                                      1
                                                  ? isDarkMode()
                                                      ? AppColors.whiteColor
                                                      : AppColors.black0D0C0C
                                                  : isDarkMode()
                                                  ? AppColors.grey888888
                                                  : AppColors.grey9B9B9B,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            // Right side icons
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  // if (dashboardController.searchCount.value >=
                                  //     10) {
                                  //   showModalBottomSheet(
                                  //     constraints: BoxConstraints(
                                  //       maxHeight:
                                  //           MediaQuery.of(context).size.height *
                                  //           0.8,
                                  //       minHeight:
                                  //           MediaQuery.of(context).size.height *
                                  //           0.8,
                                  //     ),
                                  //     isScrollControlled: true,
                                  //     context: context,
                                  //     builder: (context) {
                                  //       return PaywallScreen();
                                  //     },
                                  //   );
                                  // } else {
                                  dashboardController.onBottomNavBarTapped(2);
                                  // }
                                },
                                child: Column(
                                  children: [
                                    dashboardController.currentIndex == 2
                                        ? SvgPicture.asset(
                                          AppAssets.icSearchSelected,
                                          width: 24,
                                          height: 24,
                                        )
                                        : SvgPicture.asset(
                                          AppAssets.icSearch,
                                          width: 24,
                                          height: 24,
                                        ),
                                    SizedBox(height: 5.h),

                                    Text(
                                      search.tr,
                                      style: AppTextStyle.medium16(
                                        color:
                                            dashboardController.currentIndex ==
                                                    2
                                                ? isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C
                                                : isDarkMode()
                                                ? AppColors.grey888888
                                                : AppColors.grey9B9B9B,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  dashboardController.onBottomNavBarTapped(3);
                                },
                                child: Column(
                                  children: [
                                    dashboardController.currentIndex == 3
                                        ? SvgPicture.asset(
                                          AppAssets.icSettingSelected,
                                          width: 24,
                                          height: 24,
                                        )
                                        : SvgPicture.asset(
                                          AppAssets.icSetting,
                                          width: 24,
                                          height: 24,
                                        ),
                                    SizedBox(height: 5.h),

                                    Text(
                                      setting.tr,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: AppTextStyle.medium16(
                                        color:
                                            dashboardController.currentIndex ==
                                                    3
                                                ? isDarkMode()
                                                    ? AppColors.whiteColor
                                                    : AppColors.black0D0C0C
                                                : isDarkMode()
                                                ? AppColors.grey888888
                                                : AppColors.grey9B9B9B,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
              ),
            ),
      ),
    );
  }

  drawerWidget() {
    return Drawer(
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      shape: RoundedRectangleBorder(),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  SizedBox(height: 50.h),
                  Row(
                    children: [
                      Image.asset(
                        // isDarkMode() ? AppAssets.icLogoDark : AppAssets.icLogo,
                        isDarkMode()
                            ? AppAssets.imgWhiteLogo
                            : AppAssets.imgLogo,
                        height: 50,
                        width: 50,
                      ),
                      SizedBox(width: 15.w),
                      Expanded(
                        child: Text.rich(
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          TextSpan(
                            children: [
                              TextSpan(
                                text: center.tr,
                                style: AppTextStyle.bold36(
                                  color: AppColors.primaryPurple,
                                ),
                              ),
                              TextSpan(
                                text: grade.tr,
                                style: AppTextStyle.medium30(
                                  color:
                                      isDarkMode()
                                          ? AppColors.whiteColor
                                          : AppColors.black0D0C0C,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 25.h),
                  Text(
                    general.tr.toUpperCase(),
                    style: AppTextStyle.medium18(color: AppColors.grey9B9B9B),
                  ),
                  SizedBox(height: 30.h),
                  GestureDetector(
                    // key: keyManualGrading,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      Future.delayed(200.milliseconds, () {
                        Get.to(
                          () => ManualGradingPage(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      });
                    },

                    behavior: HitTestBehavior.opaque,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            AppAssets.icManualGrade,
                            colorFilter: ColorFilter.mode(
                              isDarkMode()
                                  ? AppColors.whiteColor
                                  : AppColors.primaryPurple,
                              BlendMode.srcIn,
                            ),
                          ),
                          SizedBox(width: 12.w),
                          Expanded(
                            child: Text(
                              manualCentering.tr,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTextStyle.medium20(
                                color:
                                    isDarkMode()
                                        ? AppColors.grey9B9B9B
                                        : AppColors.black0D0C0C,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icFavorite,
                    title: favorites.tr,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      Future.delayed(200.milliseconds, () {
                        Get.to(
                          () => FavoriteScreen(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      });
                    },
                  ),
                  // SizedBox(height: 30.h),
                  // drawerTile(
                  //   icon: AppAssets.icTutorial,
                  //   title: appTutorial.tr,
                  //   onTap: () {
                  //     scaffoldKey.currentState!.closeDrawer();
                  //     Future.delayed(200.milliseconds, () {
                  //       if (isShow == false) {
                  //         showTutorial();
                  //       }
                  //     });
                  //   },
                  // ),
                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icLanguage,
                    title: language.tr,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      Future.delayed(200.milliseconds, () {
                        Get.to(
                          () => LanguagePage(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      });
                    },
                  ),
                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icPriceChecker,
                    title: priceChecker.tr,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      Future.delayed(200.milliseconds, () {
                        Get.to(
                          () => PriceCheckerPage(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      });
                    },
                  ),
                  SizedBox(height: 25.h),
                  Text(
                    aboutUs.tr.toUpperCase(),
                    style: AppTextStyle.medium18(color: AppColors.grey9B9B9B),
                  ),

                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icPrivacy,
                    title: privacyPolicy.tr,
                    onTap: () async {
                      scaffoldKey.currentState!.closeDrawer();
                      await launchUrl(
                        Uri.parse(
                          'https://center-grade.blogspot.com/2025/05/privacy-policy.html',
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icFaq,
                    title: faq.tr,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      Future.delayed(200.milliseconds, () {
                        Get.to(
                          () => FaqScreen(),
                          transition: Transition.rightToLeftWithFade,
                        );
                      });
                    },
                  ),
                  SizedBox(height: 30.h),
                  drawerTile(
                    icon: AppAssets.icLogout,
                    title: logout.tr,
                    onTap: () {
                      scaffoldKey.currentState!.closeDrawer();
                      showDialog(
                        context: context,
                        builder: (context) {
                          return showLogOutDialog(
                            onLogoutTap: () async {
                              Get.back();
                              if (await GoogleSignIn().isSignedIn()) {
                                await GoogleSignIn().signOut();
                                await FirebaseAuth.instance.signOut();
                              }
                              final appleUser =
                                  FirebaseAuth.instance.currentUser;
                              if (appleUser != null &&
                                  appleUser.providerData.any(
                                    (provider) =>
                                        provider.providerId == 'apple.com',
                                  )) {
                                await FirebaseAuth.instance.signOut();
                              }
                              PrefManager().setBoolData(
                                key: isLoginKey,
                                value: false,
                              );
                              PrefManager().setBoolData(
                                key: isFirst,
                                value: true,
                              );
                              await PrefManager().clearPref();
                              Get.offAll(() => AuthScreen());
                              Get.find<DashboardController>().update();
                            },
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),

            GetBuilder<ProfileController>(
              builder:
                  (controller) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          controller.userProfileImage.isNotEmpty
                              ? ClipRRect(
                                borderRadius: BorderRadius.circular(25.r),
                                child: CircleAvatar(
                                  radius: 25.r,
                                  backgroundColor:
                                      isDarkMode()
                                          ? AppColors.grey2A2A2A
                                          : AppColors.greyEBEBEB,
                                  child: ClipOval(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(color:  AppColors.greyEBEBEB )
                                      ),
                                      child: Image.network(
                                        controller.userProfileImage,
                                        fit: BoxFit.cover,
                                        height: 50.r,
                                        width: 50.r,
                                        loadingBuilder: (
                                          context,
                                          child,
                                          loadingProgress,
                                        ) {
                                          if (loadingProgress == null) {
                                            return child;
                                          }
                                          return Shimmer.fromColors(
                                            baseColor:
                                                isDarkMode()
                                                    ? AppColors.grey2A2A2A
                                                    : Colors.grey[300]!,
                                            highlightColor:
                                                isDarkMode()
                                                    ? AppColors.grey9B9B9B
                                                    : Colors.grey[100]!,
                                            child: Container(
                                              height: 50.r,
                                              width: 50.r,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.grey,
                                              ),
                                            ),
                                          );
                                        },
                                        errorBuilder: (
                                          context,
                                          error,
                                          stackTrace,
                                        ) {
                                          return SvgPicture.asset(
                                            AppAssets.icProfile,
                                            height: 50.r,
                                            width: 50.r,
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              )
                              : CircleAvatar(
                                radius: 25.r,
                                backgroundColor: AppColors.grey9B9B9B,
                                child: SvgPicture.asset(
                                  AppAssets.icProfile,
                                  height: 25,
                                  width: 25,
                                ),
                              ),
                          SizedBox(width: 10.w),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 180.w,
                                child: Text(
                                  controller.userFullName.isEmpty
                                      ? user.tr
                                      : controller.userFullName,
                                  style: AppTextStyle.medium20(
                                    color:
                                        isDarkMode()
                                            ? AppColors.whiteColor
                                            : AppColors.black0D0C0C,
                                  ),
                                ),
                              ),
                              controller.userEmailId.isEmpty
                                  ? const SizedBox.shrink()
                                  : SizedBox(
                                    width: 180.w,
                                    child: Text(
                                      controller.userEmailId,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 2,
                                      style: AppTextStyle.medium16(
                                        color: AppColors.grey9B9B9B,
                                      ),
                                    ),
                                  ),
                            ],
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: () {
                          scaffoldKey.currentState!.closeDrawer();
                          Future.delayed(200.milliseconds, () {
                            Get.to(
                              () => EditProfile(
                                userImage: controller.userProfileImage,
                                userName: controller.userFullName,
                                userBirthday:
                                    controller.userProfile?.dateOfBirth ??
                                    DateTime.now(),
                              ),
                              transition: Transition.rightToLeftWithFade,
                            );
                          });
                        },
                        child: SvgPicture.asset(AppAssets.icEdit),
                      ),
                    ],
                  ),
            ),
            SizedBox(height: Platform.isIOS ? 40.h : 25.h),
          ],
        ),
      ),
    );
  }

  showLogOutDialog({required VoidCallback onLogoutTap}) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.r)),
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            logoutText.tr,
            style: AppTextStyle.bold24(
              color:
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
            ),
          ),
          GestureDetector(
            onTap: () => Get.back(),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyF6F6F6,
              ),
              padding: EdgeInsets.all(8.r),
              child: SvgPicture.asset(
                AppAssets.icClose,
                colorFilter: ColorFilter.mode(
                  isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
                  BlendMode.srcIn,
                ),
                height: 12,
                width: 12,
              ),
            ),
          ),
        ],
      ),
      content: Text(
        logOutWarning.tr,
        style: AppTextStyle.medium20(
          color: isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
        ),
      ),
      actions: [
        Row(
          children: [
            Expanded(
              child: CommonButton(
                buttonColor:
                    isDarkMode() ? AppColors.grey2A2A2A : AppColors.greyEFEFEF,
                onPressed: () {
                  Get.back();
                },
                child: Text(
                  cancel.tr,
                  style: AppTextStyle.medium20(
                    color:
                        isDarkMode()
                            ? AppColors.whiteColor
                            : AppColors.black0D0C0C,
                  ),
                ),
              ),
            ),
            SizedBox(width: 15.w),
            Expanded(
              child: CommonButton(
                buttonColor: AppColors.primaryPurple,
                onPressed: onLogoutTap,
                child: Text(
                  logout.tr,
                  style: AppTextStyle.medium20(color: AppColors.whiteColor),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  drawerTile({
    required String icon,
    required String title,
    Key? key,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        child: Row(
          key: key,
          children: [
            SvgPicture.asset(
              icon,
              colorFilter: ColorFilter.mode(
                isDarkMode() ? AppColors.whiteColor : AppColors.primaryPurple,
                BlendMode.srcIn,
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyle.medium20(
                  color:
                      isDarkMode()
                          ? AppColors.grey9B9B9B
                          : AppColors.black0D0C0C,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  exitSheet() {
    return AlertDialog(
      contentPadding: EdgeInsets.zero,
      insetPadding: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      backgroundColor:
          isDarkMode() ? AppColors.black1E1E1E : AppColors.whiteColor,
      content: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    exitText.tr,
                    style: AppTextStyle.semiBold24(
                      color:
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isDarkMode()
                                ? AppColors.grey2A2A2A
                                : AppColors.greyF6F6F6,
                      ),
                      padding: EdgeInsets.all(8.r),
                      child: SvgPicture.asset(
                        AppAssets.icClose,
                        colorFilter: ColorFilter.mode(
                          isDarkMode()
                              ? AppColors.whiteColor
                              : AppColors.black0D0C0C,
                          BlendMode.srcIn,
                        ),
                        height: 12,
                        width: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 15.h),
            Text(
              doYouReally.tr,
              style: AppTextStyle.semiBold22(
                color:
                    isDarkMode() ? AppColors.whiteColor : AppColors.black0D0C0C,
              ),
            ),
            // SizedBox(height: 5.h),
            // Text(exitWarning.tr, style: AppTextStyle.regular18()),
            SizedBox(height: 15.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CommonButton(
                  buttonWidth: Get.width / 2.5,
                  buttonHeight: 55.h,
                  buttonColor: AppColors.primaryPurple,
                  onPressed: () {
                    SystemNavigator.pop();
                  },
                  child: Text(
                    yes.tr,
                    style: AppTextStyle.medium20(color: AppColors.whiteColor),
                  ),
                ),
                SizedBox(width: 15.w),
                CommonButton(
                  buttonWidth: Get.width / 2.5,
                  buttonHeight: 55.h,
                  buttonColor: AppColors.greyCBCBCF,
                  onPressed: () {
                    Get.back();
                  },
                  child: Text(
                    no.tr,
                    style: AppTextStyle.medium20(color: AppColors.blackColor),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
