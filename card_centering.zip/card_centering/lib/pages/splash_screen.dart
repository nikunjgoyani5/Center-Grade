import 'package:card_centering/apptheme/app_assets.dart';
import 'package:card_centering/pages/authscreens/auth_screen.dart';
import 'package:card_centering/pages/dashboard/dashboard_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';

import '../apptheme/app_colors.dart';
import '../apptheme/app_strings.dart';
import '../apptheme/app_textstyle.dart';

class SplashScreen extends StatefulWidget {
  final bool isLogin;
  const SplashScreen({super.key, required this.isLogin});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Future.delayed(3.seconds, () {
      Get.to(
        () => widget.isLogin ? const DashboardScreen() : const AuthScreen(),
        transition: Transition.rightToLeftWithFade,
      );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.whiteColor,
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: Size(double.infinity, 0),
        child: AppBar(
          elevation: 0,
          systemOverlayStyle: SystemUiOverlayStyle.light,
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(AppAssets.imgLogo, height: 150, width: 150),
            Text.rich(
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              TextSpan(
                children: [
                  TextSpan(
                    text: center.tr,
                    style: AppTextStyle.bold36(color: AppColors.primaryPurple),
                  ),
                  TextSpan(
                    text: grade.tr,
                    style: AppTextStyle.medium30(color: AppColors.black0D0C0C),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
