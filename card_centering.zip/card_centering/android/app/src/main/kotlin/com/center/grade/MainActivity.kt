package com.center.grade

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
